function R = rotation_synch(Z)
% R = rotation_synch_EIG(G,W)
% The absolute rotations of the cameras are computed by using Eigenvalue
% Decomposition (rotation averagning in SO(3))
%
% OUTPUT
% R = absolute rotation matrices of the cameras
%
% INPUT
% Z = block-matrix containing the relative rotations

% Reference: "Global Motion Estimation from Point Matches", 2012
% Author: Federica Arrigoni and Andrea Fusiello, 2016

n = size(Z,1)/3;

% get the adjacency matrix A (n x n) by collapsing 3x3 blocks of Z
P = repelem(speye(n),1,3);
A = spones((P*Z*P'));

iD = diag(1./sum(A,2)); % inverse degree matrix
[M,~]=eigs( kron(iD,eye(3))*Z, 3); % top 3 eigenvectors

% fix a permutation of columns
for I = perms(1:3)'
    M = M(:, I);
    if det( M(1:3,1:3) ) > 0 break
    end
end

R=cell(1,n);
% Projection onto SO(3)
for i=1:n
    [U,~,V] = svd(M(3*i-2:3*i,:));
    R{i} = U*diag([1,1,det(U*V')])*V';
end

end

