function X = forward_intersection(P, x)
%F_INTERSECTION  Forwars intersection
%  Return 3D coordinates given corresponding points in two images

for j=1:length(x)
    x{j} = [x{j}; ones(1, size(x{j},2))];
end


X=[];
for i = 1:size(x{1},2)
    % intersection for the i-th point
    L=[];
    % stack equations for every camera
    for j=1:length(P)
        L = [L; star(x{j}(:,i))*P{j} ]  ;
    end
    
    [~,~,V] = svd(L);
    X = [X, V(:,end)./V(end,end)];
end

X = X(1:3, :);

end

