function [R,t,X] = relative_orientation(x1, x2, K1, K2)

x1 = inv(K1) * [x1; ones(1, size(x1,2))];
x2 = inv(K2) * [x2; ones(1, size(x2,2))];
% now x1 and x2 are homogeneous NIC

E = eight_points_algo(x1, x2) ;

mean(diag(x2' * E * x1)) % should be small

[U,~,V] = svd(E);

S1 = [0 -1 0;  1 0 0; 0 0 0];
R1 = [0  1 0; -1 0 0; 0 0 1];

%  left perspective projection matrix
P1 = [eye(3), zeros(3,1)];

for j = 1:4
    
    %  skew symmetric matrix
    S = (-1)^j * U*S1*U';
    
    %  rotation matrix
    if j<=2
        R = det(U*V') * U*R1*V';
    end
    
    if j>2
        R = det(U*V') * U*R1'*V';
    end
    
    %  translation vector
    t=[S(3,2) S(1,3) S(2,1)]';
    
    P2 = [R t];
    
    X = f_intersection(P1, P2, x1, x2);
    
    Xt = htx([R t; 0 0 0 1],X);
    
    % 3D points must be in front of both cameras
    if (min(X(3,:)>=0) && min(Xt(3,:))>=0)
        break
    end
    
end
end

function E = eight_points_algo(x1, x2)
% assume x1 and x2 are homogeneous NIC here

L = [];
for i = 1: size(x1,2)
    L = [L; kron( x1(:,i)' , x2(:,i)' )  ];
end

[~,~,V] = svd(L);
E = reshape(V(:,end),3,3);

end
