function P = camera( K, look, cop, up )
%UNTITLED8 Summary of this function goes here
%   Detailed explanation goes here

R(3,:) = ((look - cop)/norm(look - cop))'; % Z axis
R(1,:) = cross(up',R(3,:));    % X axis orthogonal to Z and up
R(1,:) = R(1,:)/norm(R(1,:));  
R(2,:) = cross(R(3,:),R(1,:)); % Y axis orthogonal to ZX plane


P = K*[R, -R*cop ];


end

