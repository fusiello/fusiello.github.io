clear
close all

n=25; % # of frames
density = 0.5;

% ground truth rotations
for i = 1:n
    Rgt{i} = kan(rand(1,3));
end

% transpose rotations and stack in a matrix
X = cell2mat(cellfun(@transpose,Rgt(:),'UniformOutput',false));

Z = X * X';

% make holes
A = spones(n) - (sprand(n,n,density) > 0);
A = triu(A,1) + triu(A,1)';
Z = Z.*kron(A,ones(3));

spy(Z)

R=rotation_synch(Z);

% transpose rotations
R = cellfun(@transpose,R(:),'UniformOutput',false);

% global rotation to align results
glob = Rgt{1} * R{1}';

% calcolo errore angolare (radianti)
sum =0;
for i = 1:n
   sum = sum + norm(glob*R{i} - Rgt{i}, 'fro') ;
end

fprintf('average error: %0.5g \n',sum/n);

