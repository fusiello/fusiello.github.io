function [Pb,Xb] = easy_bundleadj(x,K,G)
% BUNDLEADJ  bundle adjustment with alternation.
%
%   Bundle adjustment with alternation, no derivatives.
%   assumes constant internal parameters (K) and full visibility


numI = length(G); % # of images
p = 3*(numI-1);   % p is where traslations end

% normalize such that first camera is = [K|0] 
G1 = [G{1}; 0 0 0 1];
for i = 1:numI
    G{i} =  G{i}/G1;
    P{i} =  K * G{i};
end

% put everithing in vectors (lsqnonlin wants vectors)
Mot = zeros(6*(numI-1) ,1);
% the first [RotsM|Tras] is [I|0] by default
for i = 1:(numI-1)
    Mot(p+3*i-2:p+3*i) = ikan(G{i+1}(1:3,1:3));
    Mot(3*i-2:3*i) =  G{i+1}(1:3,4);
end

% initialize structure
X = forward_intersection(P,x);
Str=X(:);

maxiter=100;
options.Algorithm = 'levenberg-marquardt';
options.Display = 'off';
dof =  2*size(x{1},2)*numI - 3*numI - 3*size(x{1},2) ; % #eq - #unk

for iter=1:maxiter
    
    % Solve with fixed motion: structure is changed
    [Str,res_S] = lsqnonlin(@(y) bundle_cost(y,Mot,x,K),Str,[],[],options);
    
    % Solve with fixed structure: motion is changed
    [Mot,res_M] = lsqnonlin(@(y) bundle_cost(Str,y,x,K),Mot,[],[],options);
    
    disp(res_M/sqrt(dof));  % reference std dev 
    
    if abs(res_S-res_M)<1e-6  break; end
end

Pb = cell(size(P));
% re-build matrices from the argument vector
% the first PPM is [K|0]...
Pb{1} = K * [eye(3), [0 0 0]'] * G1;
% ... now build the others
for i = 1:(numI-1)
    Pb{i+1} = K * [kan(Mot(p+3*i-2:p+3*i)), Mot(3*i-2:3*i)] *G1;
end
% Now the structure
Xb = reshape(Str,3,[]);
Xb = htx(inv(G1),Xb);

end

function r = bundle_cost(Str,Mot,x,K)
% compute cost function: distance in the image plane btw measures point and
% projected one according to current Str and Mot

% Str is the structure
% Mot is the motion  (without the first camera, which is always [K|0])

numI = length(x); % # of images
p = 3*(numI-1); % p is where traslations end

% re-build matrices from the argument vector
% the first PPM is [K|0]...
P{1} = K * [eye(3), [0 0 0]'];
% ... now build the others
for i = 1:(numI-1)
    P{i+1} = K * [kan(Mot(p+3*i-2:p+3*i)), Mot(3*i-2:3*i)];
end
% Now the structure
X = reshape(Str,3,[]);

% compute residual vector (distances of image points)
r=[];
for i = 1:length(x)
    xp = htx(P{i},X);
    r = [r;  sqrt(sum((x{i}-xp).^2,1))'];
    
end

end

