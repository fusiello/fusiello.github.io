function [R,t,z] = eopa(A,B)
% EOPA  Solves an extended othogonal procrustes (EOPA) problem
%
%   [R,t,z] = eopa(A,B)  computes the similarity transformation between two
%   3D point sets A and B (points are rows) s.t. B = z*A*R + ones(p,1)*t' 
%   where p = # of points
%
%   [R,t] = eopa(A,B)  computes a rigid transform (i.e. scale=1)
%


% A and B are p x 3, where p  = # of points
p = size(A,1);
j = ones(p,1);
CM  = eye(p)-j*j'/p ; % centering matrix

% solve for rotation
[U,~,V] = svd(A'*CM*B);
R = U*diag([1,1,det(U*V')])*V';

% solve for scale (if any)
if nargout == 2  % no scale
    z = 1;
else   % with scale
    z = trace(R'*A'*CM*B) / trace(A'*CM*A);
end

% solve for translation
t =(B - z*A*R)'*j/p;
