
A =  rand(50,3)-0.5;
j = ones(50,1);

R = expm(star(rand(3,1)));
t = rand(3,1);
z = 1.3;

B = z*A*R + j*t';

[R,t,z] = eopa(A,B);

Bx = z*A*R + j*t';

norm(B-Bx)
