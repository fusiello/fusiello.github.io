clear
close all

% all the files needed are in the same directory with script

%--------------------------------------------------------------------------
% Prepare ground truth

X = rand(3, 25); % 3D points

K = [500 0 200
    0  500 200
    0    0   1]; % internal parameters

% left and right cameras
P1 = camera(K,[0 0 0]' , [-1,-1,-0.5]',   [0 1 0]');
P2 = camera(K,[0 .1 0]', [-1.5,-1,-0.5]', [0 1 0]');

% image points
x1 = htx(P1,X);
x2 = htx(P2,X);

% some plots
subplot(1,2,1); scatter(x1(1,:), x1(2,:),[],lines(size(x1,2)),'filled');
title('Right image'), axis([0 400 0 400]), axis square
subplot(1,2,2); scatter(x2(1,:), x2(2,:),[],lines(size(x1,2)),'filled');
title('Left image'),  axis([0 400 0 400]), axis square

%--------------------------------------------------------------------------
% resection

P_est = resection(x1, X);
svd([P1(:), P_est(:)])  % second singular value should be small

x_est = htx(P_est,X);  % project with estimated camera
norm(x1-x_est) % this shold be small

%--------------------------------------------------------------------------
% forward intersection

X_est = f_intersection(P1, P2, x1, x2);
norm(X-X_est)  % this shold be small

%--------------------------------------------------------------------------
% relative orientation + absolute orientation

[R12,t12,X_model] = relative_orientation(x1, x2, K, K);
norm(R12 - K\P2(:,1:3) * (K\P1(:,1:3))')

% align to GT - assume the first 6 points are GCP
[R,t,z] = eopa(X_model(:,1:6)',X(:,1:6)');

X_obj = (z*X_model'*R + ones(size(X,2),1)*t')';
norm(X-X_obj)

figure
plot3(X(1,:), X(2,:), X(3,:), 'or'); hold on
plot3(X_obj(1,:), X_obj(2,:), X_obj(3,:),'+b');
title('Relativo o.')

%%-------------------------------------------------------------------------
% separate exterior orientation

[R1,t1] = exterior_orientation(x1,X,K);
norm([R1,t1] -  K\P1)

[R2,t2] = exterior_orientation(x2,X,K);
norm([R2,t2] -  K\P2)

X_obj = f_intersection(K*[R1,t1], K*[R2,t2], x1, x2);
norm(X-X_obj)  % this shold be small

figure
plot3(X(1,:), X(2,:), X(3,:), 'or'); hold on
plot3(X_obj(1,:), X_obj(2,:), X_obj(3,:),'+b');
title('Separate exterior o.')

%%-------------------------------------------------------------------------
% simultaneous (bundle)

% Initilization w/ noise
G1_0 = [R1*kan(randn(3,1)/50),t1+randn(3,1)/10] ;
G2_0 = [R2*kan(randn(3,1)/50),t2+randn(3,1)/10] ;

% do the BA
[PPMb,X_model] = easy_bundleadj({x1,x2},K,{G1_0,G2_0});

% align model with GT and validate
[R,t,z] = eopa(X_model(:,1:6)',X(:,1:6)');
X_obj = (z*X_model'*R + ones(size(X,2),1)*t')';
norm(X-X_obj)

figure
plot3(X(1,:), X(2,:), X(3,:), 'or'); hold on
plot3(X_obj(1,:), X_obj(2,:), X_obj(3,:),'+b');
title('Bundle adjustment')