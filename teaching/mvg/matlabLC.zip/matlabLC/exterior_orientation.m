function [R,t] = exterior_orientation(x,X,K)

P = (K\[x; ones(1, size(x,2))])';
% now P are homogeneous NIC in rows
S = X';

p = size(P,1);
j = ones(p,1);
CM  = eye(p)-j*j'/p ; % centering matrix

err = +Inf; E_old = 1000*ones(p,3);
Z = diag(j); O = [0 0 0]';

while err>1e-12
    
    % solve for rotation
    [U,~,V] = svd(P'*Z*CM*S);
    R = U*diag([1,1,det(U*V')])*V';
    
    % solve for scale 
    tY = R*(S-j*O')'; % this the transpose of Y
    
    z = kr(eye(p),P')\tY(:);
    z(z<0)=0;
    Z = diag(z);
    
    % solve for translation 
    O = (S-Z*P*R)'*j/p;
    
    % compute error
    E = tY'-Z*P;
    err = norm(E-E_old);
    E_old = E;
end

t = -R*O;

end