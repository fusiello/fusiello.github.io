/***********************************************************************

concatframes

         usage: concatframes filehips1 filehips2 filehips3 ... 

         MVL -  T. Tommasini 1998 (tommasin@dimi.uniud.it)

************************************************************************/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <hipspub.h> 	/* hipspub library */

#define byte unsigned char

static void merr(char msg[80])
  {
    fprintf(stderr,"%s\n", msg);
    fflush(stderr);
    exit(0);
  }

void main(short argc, char **argv)
  {
    byte   i;
    char   *basename, s[80];
    int    format, nrow, ncol, numframes, colors;
    byte   *data;
    FILE   *fp;
  

    if (argc < 2)
      merr("usage: concatframes <files>");   
        
    if ((fp= fopen(argv[1],"r")) == NULL)
       merr("Error in opening file");        
    hpub_frdhdr(fp, &format, &nrow, &ncol, &numframes, &colors);
    if (format != PFBYTE)
      merr("Pixel format should be PFBYTE");
    if (numframes != 1)
      merr("Only 1 frame per file");
    data= (byte *) calloc(ncol*nrow, sizeof(char));
    fprintf(stderr, "No\n");
     if (fread(data, ncol*nrow, 1, fp) != 1)
      merr("Error while reading frame");
    hpub_fwrthdr(stdout, PFBYTE, nrow, ncol, argc-1, colors);
    if (fwrite(data, ncol*nrow, 1, stdout) != 1) 
      merr("Error while writing frame"); 
    for (i= 2; i < argc; i++)
       {
	 fprintf(stderr, "%d\n",i);
	 
	 fp= fopen(argv[i],"r");
	 hpub_frdhdr(fp, &format, &nrow, &ncol, &numframes, &colors);
	 if (format != PFBYTE)
	   merr("Pixel format should be PFBYTE");
	 if (numframes != 1)
	   merr("Only 1 frame per file");
	 if (fread(data, ncol*nrow, 1, fp) != 1)
	   merr("Error while reading frame");
	 if (fwrite(data, ncol*nrow, 1, stdout) != 1) 
	   merr("Error while writing frame"); 
       }      
    fflush(stderr);   
  }








