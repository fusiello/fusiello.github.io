/***********************************************************************

ROBUST FEATURE TRACKER

         usage: rtrack treshold<real> size<integer>
                       [-monitor] imagefile


         MVL -  T. Tommasini 1998 (tommasin@dimi.uniud.it)

	 http://www-iapr-ic.dimi.uniud.it:80/Udine/Respro/Tracker/
************************************************************************/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <hipspub.h> 	/* hipspub library */
#include <nr.h>      	/* numerical recipes library */

#include "array2.h"
#include "matrix.h" 	/* meshach library */

#define MAXITER 25 
#define MAXFEAT 1000
#define GATE 0.01
#define MAXAFF 30
#define MULT -0.5
#define LOWER 10E-6
#define boole int
#define byte unsigned char
#define COEFX84 5.2

#undef RESIDUALS
#define EIGENVALUES

typedef struct tp
{
  double    	row, col;
  double  	good, goodw;
  double	dx, dy;
  struct tp 	*next;
} TPunto;

TPunto **listafeat; /* Pointers to the features */

struct t_ff 
 {
   int num;
   float row, col;
   float cf;
 };

float indx[MAXFEAT]; 	/* Used for sorting features */
float coef[MAXFEAT]; 	/* Used for sorting features */
int point[MAXFEAT]; 	/* Used for sorting features */

struct t_ff ff[MAXFEAT]; 

int	totfeatures; 	/* num. of features to track */
int 	numfeatures; 	/* num. of effective features to track */
int 	finalfeatures; 	/* num. of features in final frame */
int	numframes; 	/* num. of frames of the input sequence */
int 	wsize; 		/* size of the feature window */
int 	nrow, ncol; 	/* size (rowXcoloumn) of each frame */
int 	currinterval;
int 	fdim2, format, colors;

byte 	*ifr_base, **ifr, *ofr_base, **ofr, *first_base, **first, *last_base, **last;
byte 	*eig_base, **eig;
float 	*wgaus_base, **wgaus;
float	*xg_base, **xg, *yg_base, **yg;

FILE	*fptr, *fp, *faffine, *falltracks, *feigen, *foutliers;

double 	soglia, sigma;
boole 	monitor; 		/* if TRUE -> prints X-84 outliers */

char	*filename;
char 	eigen[80];	   		/* file with min eigenvalues */	
char	affine[80]; 			/* file affine residual in XGRAPH format */
char 	alltracks[80];  		/* file with all tracks */
char 	outliers[80];			/* file with outliers */


/* Matrix and Vectors declaration */
VEC *h, *h2, *grad, *aux, *fact1, *svdvals;
MAT *M, *U, *V, *MD, *MF;		

MAT *MM2, *MD2, *MF2, *U2, *V2, *A2;
VEC *a2, *z2, *vp2, *xv2, *svdvals2;

MAT *A2, *PATCH;
VEC *d2;

MAT *dxx, *dyy;


static void merr(char msg[80])
{
  fprintf(stderr,"%s\n", msg);
  fflush(stderr);
  exit(0);
}

/* ## Functions Declarations ## */
int FExtr(byte **img_in, byte **ofr, double soglia, int wsize, double sigma);
void FTracking(byte *ifr_base, byte **ifr, FILE *fp, int numframes, int totfeatures, int numfeatures);
void InitListaFeat(TPunto **listafeat);
void CopyFrame(byte **in, byte **out);
int SortFeat(struct t_ff *ff, int totfeatures, float *indx, int wmid);
void WGauss(float **wgaus, int wsize, double sigma);
double ExpungeBadFeatures(TPunto **listafeat, int numfeatures, int *point);
void PrintNum(byte **img, int num, int row, int col, byte color);
double CalcWarp(byte **first, double row1, double col1, byte **last, double row2, double col2, int wsize, int sss);



/*### MAIN begin ###*/
void main(short argc, char **argv)
{
  byte 	i;
  char 	*basename, s[80];
  
  if ((argc != 5) && (argc != 4))
    merr("usage: rtrack treshold<0.1>  window_size<15> [monitor] sequence_file");   
  if (argc == 4)
     {
       soglia= atof(argv[1]);
       wsize= atoi(argv[2]);
       filename= argv[3];
       monitor= FALSE;
     }
  else
     {
       soglia= atof(argv[1]);
       wsize= atoi(argv[2]);
       if (strcmp(argv[3],"-monitor") != 0)
	 merr("usage: rtrack treshold<0.1>  window_size<15> [monitor] sequence_file");    
       filename= argv[4];
       monitor= TRUE;
     }
      
  fp = fopen(filename,"r");
  hpub_frdhdr(fp, &format, &nrow, &ncol, &numframes, &colors);
  
  if (wsize < 3 || !(wsize % 2) || wsize > ncol || wsize > nrow)
    merr("Size of the window's neighborhood must be odd and >= 3\n");
  
  /*  computed sigma -> mask contains 99% of the Gaussian */

  sigma = ((double)wsize+1)/6;

  if (format != PFBYTE)
    merr("Pixel format should be PFBYTE");

  /* Frames memory allocation (halloc is safe) */
  fdim2 = ncol*nrow;	/* Frame dimension squared */
  fprintf(stderr, "\nInput image is %dx%d pixels, %d frames\n", nrow, ncol, numframes);
              
  ifr_base= (byte *) calloc(fdim2, sizeof(char));
  ofr_base= (byte *) calloc(fdim2, sizeof(char));
  first_base= (byte *) calloc(fdim2, sizeof(char));
  last_base= (byte *) calloc(fdim2, sizeof(char));
  eig_base= (byte *) calloc(fdim2, sizeof(char));

  ifr= (byte **) barray(ifr_base, nrow, ncol);
  ofr= (byte **) barray(ofr_base, nrow, ncol);
  first= (byte **) barray(first_base, nrow, ncol);
  last= (byte **) barray(last_base, nrow, ncol);
  eig= (byte **) barray(eig_base, nrow, ncol);

  /* Creazione della matrice contenente la gaussiana */
  wgaus_base= 	(float *) calloc(wsize*wsize, sizeof(float));
  wgaus= 	(float **) farray(wgaus_base, wsize, wsize);
  WGauss(wgaus, wsize, sigma);
 
  /* Read first frame */
  if (fread(ifr_base, fdim2, 1, fp) != 1)
    merr("Error while reading frame");

  CopyFrame(ifr, ofr); 
  CopyFrame(ifr, first); 
  
  /* Feature extraction from 1st frame */
  totfeatures= FExtr(ifr, ofr, soglia, wsize, sigma);
  /* fprintf(stderr,"Extracted %d features\n", totfeatures); */

  /* Prepare name's strings of output files */
  strcpy(s, filename);
  basename= strrchr(s, 47);  
  if (basename != NULL)
    basename++; 
  else
    basename= s;    
  i= strlen(basename);
  basename[i-3]= '\0';
  strcpy(outliers, basename);
  strcat(outliers, "outl.tra");
  strcpy(alltracks, basename);
  strcat(alltracks, "tra");
  strcpy(affine, basename);
  strcat(affine, "xg");
  strcpy(eigen, basename);
  strcat(eigen, "eigen.hps");

#ifdef EIGENVALUES
  /* Storing image of min eigenvalue */
  if ((feigen = fopen(eigen, "w")) == NULL)
    merr("Error in opening file to save min eigenvalues\n");
  hpub_fwrthdr(feigen, PFBYTE, nrow, ncol, 1, colors);
  if (fwrite(eig_base, fdim2, 1, feigen) != 1) 
    merr("Error while writing min eigenvalues"); 
/*  fprintf(stderr, "Min eigenvalues saved in file \042%s\042\n", eigen); */
  fclose(feigen);
#endif
   
  /* open file of outliers */
  if (monitor == TRUE)
    {
      if ((foutliers = fopen(outliers, "w")) == NULL)
	merr("Error in opening file to save outliers data\n");
      fprintf(foutliers, "\042Frame # %d\n", numframes-1);	    
    }
  
  /* open file for tracks */
  if ((falltracks = fopen(alltracks, "w")) == NULL)
    merr("Error in opening file to save tracks data\n");

  numfeatures= SortFeat(ff, totfeatures, indx, (wsize-1)/2);
  /* fprintf(stderr,"There are %d good features\n", numfeatures); */	 
  fprintf(stderr, "%d features in first frame\n", numfeatures);

#ifdef RESIDUALS
  /* open file of residuals */
  if ((faffine = fopen(affine, "w")) == NULL)
    merr("Error in opening file to save features\n"); 
#endif

  dxx= m_get(nrow,ncol);
  dyy= m_get(nrow,ncol);
 
  listafeat= (TPunto **) calloc(MAXFEAT, sizeof(TPunto));
  InitListaFeat(listafeat);
  
  FTracking(ifr_base, ifr, fp, numframes, totfeatures, numfeatures);
 
  fprintf(stderr, "%d features in last frame\n", finalfeatures);   
  fclose(fptr);
  fclose(fp);
  fclose(falltracks);
  if (monitor == TRUE)
    fclose(foutliers);
#ifdef RESIDUALS
  fclose(faffine);
#endif
  fflush(stderr);   
}
/*### MAIN end ###*/


double ParabMin(int x, int y1, int y2, int y3)
/* compute parameters a,b,c of the interpolating parabola */
{
  double a, b, c, p;
  double sub=0.0;
  
  a= (y1-2.0*y2+y3)/2.0;
  p= (y1-y3)/2.0;
  b= -(2.0*a*x+p);
  c= a*x*x+p*x+y2;
  if (a != 0)
    sub= p/(2.0*a);  /* abscissa of the parabola maximum */ 
  return sub; /* in (-1,1) range */
}


void CopyFrame(byte **in, byte **out)
{	
  int i, j;	
   
  for (i= 0; i < nrow; i++)
    for (j= 0; j < ncol; j++)
      out[i][j]= in[i][j];  
}		
 

void XYGradGauss(byte **ifr, float **xgrad, float **ygrad)
{
  int i,j;

  for (i= 0; i < nrow; i++)
    for (j= 0; j < ncol; j++) 
      {	 
	if ( (j < 3) || (i < 3) || (j >= ncol-3) || (i >= nrow-3))
	  xgrad[i][j]=0.0;
	else	
	  xgrad[i][j]= ( 2047.0*(ifr[i][j+1] - ifr[i][j-1]) 
			 +913.0 *(ifr[i][j+2] - ifr[i][j-2])
			 +112.0 *(ifr[i][j+3] - ifr[i][j-3]))/8418.0;
      }
  for (i= 0; i < nrow; i++)
    for (j= 0; j < ncol; j++) 
      {
	if ( (j < 3) || (i < 3) || (j >= ncol-3) || (i >= nrow-3))
	  ygrad[i][j]=0.0;
	else	
	  ygrad[i][j]= ( 2047.0*(ifr[i+1][j] - ifr[i-1][j]) 
			 +913.0 *(ifr[i+2][j] - ifr[i-2][j])
			 +112.0 *(ifr[i+3][j] - ifr[i-3][j]))/8418.0;
      }
}


void WGauss(float **wgaus, int wsize, double sigma)
{
  double coef = 1/(sqrt(2*M_PI)*sigma);
  int i, j;
  int wmid = (wsize-1)/2;

  for (i= -wmid; i <= wmid; i++)
    for (j= -wmid; j <= wmid; j++)
      wgaus[wmid+i][wmid+j]= (float) coef*exp(-(i*i+j*j)/(2*sigma*sigma));
}

    
void DrawFeaturesInFrame(TPunto **listafeat, int numfeatures, int numframes)
/* plots feature coordinates */
{
  int 	i;
  double cut;
  TPunto *last;
 
  cut= ExpungeBadFeatures(listafeat, numfeatures, point);
  fprintf(stderr, "Features above X-84 threshold:\n");

  for (i= 1; i <= finalfeatures; i++)
    {
      for (last= listafeat[point[i]]; (last->next != NULL); last= last->next)
	 {}
      if (last->goodw > cut)
	{
	  fprintf(stderr, "[#%d] ", point[i]+1);
	  if (monitor == TRUE)
	    fprintf(foutliers, "%d %lf %lf\n", point[i]+1, last->col+last->dx, last->row+last->dy);	  
	}
    } 
  fprintf(stderr, "\n");
}

void FillDataFile(TPunto **listafeat, int numfeatures, int numframes)
{
  int i, j;
  TPunto *auxp, *last;
    
  finalfeatures= 0;
  for (i= 1; i <= numfeatures; i++)
    {
      auxp= listafeat[i-1];
      if (auxp != NULL)
	{ 	 
	  last= auxp;
	  for (j= 1; ((last->next != NULL) && (j < numframes)); last= last->next)
	    j++;
	  if (j == numframes-1) /* feature appears in frame "numframe" */
	    {	
#ifdef RESIDUALS	      
	      j= 1;
	      fprintf(faffine, "\042%d\042\n", i);
	      for (auxp= listafeat[i-1]; auxp != NULL; auxp= auxp->next, j++)
		fprintf(faffine, "%d %lf\n", j, auxp->goodw);
	      fprintf(faffine, "\n");
#endif
	      finalfeatures++;
	    }
	}
    }
}

double ExpungeBadFeatures(TPunto **listafeat, int numfeatures, int *point)
{
  int i, j, k= 1;
  float  res_arr[MAXFEAT], aff_arr[MAXFEAT];
  double median, mad;
  TPunto *auxp, *last;	
   
  for (i= 1; i <= numfeatures; i++)
    {
      auxp= listafeat[i-1];
      if (auxp != NULL)
	{ 	 
	  last= auxp;
	  for (j= 1; ((last->next != NULL)); last= last->next)
	    j++;
	  if (j == numframes-1) /* feature appears in final frame */
	    {	
	      indx[k]= k; /* keeps progressive enumeration */
	      coef[k]= last->good; 
	      aff_arr[k]= last->goodw;
	      point[k]= i-1; /* keeps the pointer to the feature in listafeat */
	      k++;	   
	    }
	}
    }

  median= select((finalfeatures%2 ? finalfeatures/2+1 : finalfeatures/2), finalfeatures, aff_arr);
  for (i= 1;  i <= finalfeatures; i++)  
    res_arr[i]= fabs(aff_arr[i]-median);
  mad= select((finalfeatures%2 ? finalfeatures/2+1 : finalfeatures/2), finalfeatures, res_arr);
  fprintf(stderr, "X-84 threshold=%lf\n", median+COEFX84*mad);

#ifdef RESIDUALS
  fprintf(faffine, "\042X-84\042\n");
  for (i= 1; i < numframes; i++)
    fprintf(faffine, "%d %lf\n", i, median+COEFX84*mad);
#endif

/*  fprintf(stderr, "final=%d\n", finalfeatures);   */
  return median+COEFX84*mad;
} 
    

int SortFeat(struct t_ff *ff, int totfeatures, float *indx, int wmid)
/* Sorts features estracted from 1st frame */
{
  int i, k, scarti= 1;
  float coef[MAXFEAT]; 
    
  for (i= 1; i <= totfeatures; i++)
    {
      indx[i]= i;
      coef[i]= ff[i].cf;
    }
  sort2(totfeatures, coef, indx);
  for (i= totfeatures-1; i >= scarti; )
    {
      for (k= totfeatures; ((k > i) && ((abs(ff[(int)indx[i]].row-ff[(int)indx[k]].row) > 2*wmid) || (abs(ff[(int)indx[i]].col-ff[(int)indx[k]].col) > 2*wmid))); k--)
	{}
      if (k != i)
	{
	  for (k=i; k > scarti; k--)
	    indx[k]= indx[k-1];
	  scarti++;
	}
      else
	i--;
    }
  numfeatures= totfeatures-scarti+1;

  fprintf(falltracks, "\042Frame # 0\n");	    
  for (i= totfeatures; i > totfeatures-numfeatures; i--)
    fprintf(falltracks, "%d %f %f\n", totfeatures-i+1, ff[(int)indx[i]].col, ff[(int)indx[i]].row);
  /* 'indx' keeps the index of the features crescent order */
  return numfeatures;
}


double FD(byte **fr, double r, double c)
/* Bilinear interpolation to achieve subpixel precision */
 {
   int ir= floor(r);
   int ic= floor(c);   
   double dr= r-ir;
   double dc= c-ic;
   
   return (fr[ir][ic]+dr*(fr[ir+1][ic]-fr[ir][ic])+dc*(fr[ir][ic+1]-fr[ir][ic])+dr*dc*(fr[ir][ic]-fr[ir+1][ic]-fr[ir][ic+1]+fr[ir+1][ic+1]));
 }

double DerivXF(byte **fr, double r, double c)
{
  if ( ((int) floor(c) < 3) || ((int) floor(r) < 3) || ((int) floor(c) >= ncol-4) || ((int) floor(r) >= nrow-4))
    return 0.0;
  else	
    return ( 2047.0*(FD(fr,r,c+1) - FD(fr,r,c-1)) 
	     +913.0 *(FD(fr,r,c+2) - FD(fr,r,c-2))
	     +112.0 *(FD(fr,r,c+3) - FD(fr,r,c-3)))/8418.0;
}

double DerivYF(byte **fr, double r, double c)
{
  if ( ((int) floor(c) < 3) || ((int) floor(r) < 3) || ((int) floor(c) >= ncol-4) || ((int) floor(r) >= nrow-4))
    return 0.0;  
  else	
    return ( 2047.0*(FD(fr,r+1,c) - FD(fr,r-1,c)) 
	     +913.0 *(FD(fr,r+2,c) - FD(fr,r-2,c))
	     +112.0 *(FD(fr,r+3,c) - FD(fr,r-3,c)))/8418.0;
}


void InitListaFeat(TPunto **listafeat)
{
  int i;

  for (i= 0; i < MAXFEAT; i++)
    listafeat[i]= NULL;
}


void ParzTreshold(TPunto **listafeat, int numfeatures, int curr)
/* Computes X84 for current frame */
{
  int i, j, k= 1;
  float arr[MAXFEAT], res_arr[MAXFEAT];
  double median, mad;
  TPunto *auxp, *last;

  for (i= 1; i <= numfeatures; i++)
    {
      auxp= listafeat[i-1];
      if (auxp != NULL)
	{ 	 
	  last= auxp;
	  for (j= 1; (last->next != NULL); last= last->next)
	    j++;
	  if (j == curr)
	    {	 
	      arr[k]= last->goodw;
	      k++;
	    }
	}       
    }
  k--;
  median= select((k%2 ? k/2+1 : k/2), k, arr);
  for (i= 1;  i <= k; i++)
    res_arr[i]= fabs(arr[i]-median);

  mad= select((k%2 ? k/2+1 : k/2), k, res_arr);
}

void defT(byte **J, double r, double c)
/* r,c refers to second image J */
{ 
  int wmid, csi, eta;
  double xi, yi, z11, z12,z21, z22, dx, dy;
   
  m_zero(PATCH);
  wmid=wsize/2;
   
  for (csi= -wmid; csi <= wmid; csi++)
    for (eta= -wmid; eta <= wmid; eta++)
      {
	xi= A2->me[0][0]*eta+A2->me[0][1]*csi+d2->ve[0];
	yi= A2->me[1][0]*eta+A2->me[1][1]*csi+d2->ve[1];
	if ((floor(xi+r) >= 0) && (floor(yi+c) >= 0) && (floor(xi+1+r) < nrow) && (floor(yi+1+c) < ncol))
	  {
	    z11= J[(int)floor(xi+r)][(int)floor(yi+c)];
	    z12= J[(int)floor(xi+r)][(int)floor(yi+1+c)];
	    z21= J[(int)floor(xi+1+r)][(int)floor(yi+c)];
	    z22= J[(int)floor(xi+1+r)][(int)floor(yi+1+c)];
	    dx= xi+r-floor(xi+r);
	    dy= yi+c-floor(yi+c);	    
	    PATCH->me[eta+wmid][csi+wmid]= (z11+dx*(z21-z11)+dy*(z12-z11)+dx*dy*(z11-z12-z21+z22));
	  }
      }
} 


boole CalcDisplacement(byte **img1, byte **img2, int wmid, double row, double col, VEC *h, int i)
/* Computes the displacement for a single feature between 2 frames */
{  
  int 		k, l, numiter= 0;
  double 	kk, ll, g2;

  if (((int) floor(col-wmid) < 0) ||
      ((int) floor(row-wmid) < 0) ||
      ((int) floor(col+wmid) >= ncol-1) ||
      ((int) floor(row+wmid) >= nrow-1))
    return FALSE;

  v_zero(h);  
  do
    {
      if (((int) floor(col-wmid+ h->ve[0]) < 0) ||
	  ((int) floor(row-wmid+ h->ve[1]) < 0) ||
	  ((int) floor(col+wmid+ h->ve[0]) >= ncol-1) || 
	  ((int) floor(row+wmid+ h->ve[1]) >= nrow-1))
	return FALSE; 

      v_zero(h2);
      v_zero(fact1);
      m_zero(M);
      if (numiter == 0)
	{
	  for (k= -wmid; k <= wmid; k++)
	    for (l= -wmid; l <= +wmid; l++)
	      {
                xg[k+wmid][l+wmid]= DerivXF(img1, row+(double)k, col+(double)l);
		yg[k+wmid][l+wmid]= DerivYF(img1, row+(double)k, col+(double)l);
	      }
	}
      for (k= -wmid; k <= wmid; k++)
	for (l= -wmid; l <= +wmid; l++)
	  {
	    kk= row + (double)k + h->ve[1];
	    ll= col + (double)l + h->ve[0];
	    g2= (double)(wgaus[k+wmid][l+wmid]*wgaus[k+wmid][l+wmid]);
	    if (numiter == 0)
	      { 
		M->me[0][0]+= g2*xg[k+wmid][l+wmid]*xg[k+wmid][l+wmid];
		M->me[0][1]+= g2*xg[k+wmid][l+wmid]*yg[k+wmid][l+wmid];
	        M->me[1][0]= M->me[0][1];
		M->me[1][1]+= g2*yg[k+wmid][l+wmid]*yg[k+wmid][l+wmid];
	      }
	    aux->ve[0]=g2*(FD(img2, kk, ll)-FD(img1, row+k, col+l))*xg[k+wmid][l+wmid];
	    aux->ve[1]=g2*(FD(img2, kk, ll)-FD(img1, row+k, col+l))*yg[k+wmid][l+wmid];
	    v_add(fact1, aux, fact1);
	  }
      
      if (numiter == 0)
	{
	  svd(M, U, V, svdvals);
	  MD->me[0][0]= (svdvals->ve[0] < LOWER) ? 0.0 : 1.0 / svdvals->ve[0];
	  MD->me[1][1]= (svdvals->ve[1] < LOWER) ? 0.0 : 1.0 / svdvals->ve[1];
	  MD->me[0][1]= 0.0;
	  MD->me[1][0]= 0.0; 
	  m_transp(V, V);
	  m_mlt(V, MD, MF);       
	  m_mlt(MF, U, V);
	}
      mv_mlt(V, fact1, h2);
      sv_mlt(MULT, h2, h2);
      v_add(h, h2, h);
      numiter++;
    }

  while ((v_norm2(h2) > GATE) && (numiter <= MAXITER));
  if (((int) floor(col-wmid+h->ve[0]) < 0) ||
      ((int) floor(row-wmid+h->ve[1]) < 0) ||
      ((int) floor(col+wmid+h->ve[0]) >= ncol-1) || 
      ((int) floor(row+wmid+h->ve[1]) >= nrow-1))
    return FALSE; 

  if (numiter <= MAXITER)
    return TRUE;
  else
    return FALSE;
}


void FTrack2Frames(int zzz, TPunto **listafeat, byte **img1, byte **img2, struct t_ff *ff, int totfeatures, int numfeatures, int currinterval)
/* Tracks between 2 frames */
{
  int	i, wmid;
  TPunto *last, *newf;
  int 	k;

  fprintf(falltracks, "\042Frame # %d\n", currinterval);	          
  wmid = (wsize-1)/2; 
  for (i= 1; i <= numfeatures; i++)
    {
      switch (currinterval)
	{
	case 1:
	  {
	    if (CalcDisplacement(img1, img2, wmid, (double)ff[(int)indx[totfeatures+1-i]].row, (double)ff[(int)indx[totfeatures+1-i]].col, h, i) == TRUE)
	      {
		newf= (TPunto *) calloc(1, sizeof(TPunto));
		newf->row= (double) ff[(int)indx[totfeatures+1-i]].row;
		newf->col= (double) ff[(int)indx[totfeatures+1-i]].col;
		newf->dx= h->ve[0];
		newf->dy= h->ve[1];
		fprintf(falltracks, "%d %lf %lf\n", i, newf->col+newf->dx, newf->row+newf->dy);

#ifdef RESIDUALS
		newf->goodw= CalcWarp(first, (double) ff[(int)indx[totfeatures+1-i]].row, (double) ff[(int)indx[totfeatures+1-i]].col, img2, newf->row+newf->dy, newf->col+newf->dx, wsize, totfeatures+1-i);
#endif
#ifndef RESIDUALS
		if (currinterval == numframes-1)                      
		  newf->goodw= CalcWarp(first, (double) ff[(int)indx[totfeatures+1-i]].row, (double) ff[(int)indx[totfeatures+1-i]].col, img2, newf->row+newf->dy, newf->col+newf->dx, wsize, totfeatures+1-i);
		else
		  newf->goodw=0.0;
#endif
		newf->next= NULL;
		listafeat[i-1]= newf;
	      }
	    break;
	  }
	default: 
	  {
	    if (listafeat[i-1] != NULL)
	      { 
		last= listafeat[i-1];
		for (k= 1; last->next != NULL; last= last->next)
		  k++;
		if (currinterval == k+1)
		  /* verifies if the feature is still alive */
		  if (CalcDisplacement(img1, img2, wmid, last->row+last->dy, last->col+last->dx, h,i) == TRUE)
		    { 
		      newf= (TPunto *) calloc(1, sizeof(TPunto));
		      newf->row= last->row+last->dy;
		      newf->col= last->col+last->dx;
		      newf->dx= h->ve[0];
		      newf->dy= h->ve[1];
		      fprintf(falltracks, "%d %lf %lf\n", i, newf->col+newf->dx, newf->row+newf->dy);
#ifdef RESIDUALS
		      newf->goodw= CalcWarp(first, (double) ff[(int)indx[totfeatures+1-i]].row, (double) ff[(int)indx[totfeatures+1-i]].col, img2, newf->row+newf->dy, newf->col+newf->dx, wsize, totfeatures+1-i);
#endif
#ifndef RESIDUALS
		      if (currinterval == numframes-1)                      
			newf->goodw= CalcWarp(first, (double) ff[(int)indx[totfeatures+1-i]].row, (double) ff[(int)indx[totfeatures+1-i]].col, img2, newf->row+newf->dy, newf->col+newf->dx, wsize, totfeatures+1-i);
		      else
			newf->goodw=0.0;
#endif
		      newf->next= NULL;
		      last->next= newf;
		    }	
	      }
	  }
	}
    }
}

void FTracking(byte *ifr_base, byte **ifr, FILE *fp, int numframes, int totfeatures, int numfeatures)
  {
    byte *img2_base, **img2;

    img2_base= (byte *) calloc(fdim2, sizeof(char));
    img2= (byte **) barray(img2_base, nrow, ncol);

    xg_base= 	(float *) calloc(wsize*wsize, sizeof(float));
    xg= 		(float **) farray(xg_base, wsize, wsize);  

    yg_base= 	(float *) calloc(wsize*wsize, sizeof(float));
    yg= 		(float **) farray(yg_base, wsize, wsize);  
    
    /* Matrix & Vector allocations */
    h= 	   v_get(2);
    svdvals= v_get(2);
    fact1= v_get(2);
    h2=    v_get(2);
    aux=   v_get(2);
    grad=  v_get(2);

    M=	 m_get(2,2);
    U= 	 m_get(2,2);
    V= 	 m_get(2,2);
    MD=    m_get(2,2);  
    MF=    m_get(2,2);

    a2= v_get(6);
    z2= v_get(6);
    vp2= v_get(2);
    xv2= v_get(2);
    svdvals2= v_get(6);	

    MM2= m_get(6,6);
    U2= 	m_get(6,6);
    V2= 	m_get(6,6);
    MD2= 	m_get(6,6);  
    MF2= 	m_get(6,6);

    /* Matrix & Vector allocations used for warping*/
    A2= m_get(2,2);
    PATCH= m_get(wsize, wsize);
    d2= v_get(2);

    fprintf(stderr, "TRACKING\n");
    /* fprintf(stderr, "#FRAMES= %d\nCurrent is\n", numframes); */
    for (currinterval= 1; currinterval < numframes; currinterval++)
       { 
	 fprintf(stderr, ".");
	 if (currinterval % 2 == 1)
	    {
	      if (fread(img2_base, fdim2, 1, fp) != 1)
		merr("Error while reading frame"); 
	      CopyFrame(img2, last); 
	      FTrack2Frames(currinterval, listafeat, ifr, img2, ff, totfeatures, numfeatures, currinterval);
	    }
	 else
	    {
	      if (fread(ifr_base, fdim2, 1, fp) != 1)
		merr("Error while reading frame");
	      CopyFrame(ifr, last);  
	      FTrack2Frames(currinterval, listafeat, img2, ifr, ff, totfeatures, numfeatures, currinterval);
	    }
	 ParzTreshold(listafeat, numfeatures, currinterval);
       }

    /* Matrix & Vector deallocations */
    V_FREE(h);
    V_FREE(svdvals);
    V_FREE(h2);
    V_FREE(grad);
    V_FREE(aux);
    V_FREE(fact1);

    M_FREE(M);
    M_FREE(MD);
    M_FREE(MF);	
    M_FREE(U);
    M_FREE(V);

    M_FREE(MM2);
    V_FREE(a2);
    V_FREE(z2);
    V_FREE(vp2);
    V_FREE(xv2);
    V_FREE(svdvals2);
    
    M_FREE(U2);
    M_FREE(V2);
    M_FREE(MD2);  
    M_FREE(MF2);

    /* Matrix & Vector allocations used 4 warping*/
    M_FREE(A2);
    M_FREE(PATCH);
    V_FREE(d2);

    currinterval--;
    fprintf(stderr, "\n");
    FillDataFile(listafeat, numfeatures, numframes);
    DrawFeaturesInFrame(listafeat, numfeatures, numframes); 
  }


double CalcEigVal(double x11, double x12, double x22)
{
  double val1, val2;
  double b= x11+x22;
  double delta= b*b-4.0*(x11*x22-x12*x12);

  val1= (b+sqrt(delta))/2.0;
  val2= (b-sqrt(delta))/2.0;
  return (val1 < val2) ? val1 : val2;
}

    
int FExtr(byte **ifr, byte **ofr, double soglia, int wsize, double sigma)
/* Performs the extraction of the features from 1st frame*/
{
  double 	rmax = 0.0;
  double 	x11,x12,x22;
  float 	*xgrad_base, **xgrad, *ygrad_base, **ygrad;
  float 	*feat_base, **feat;
  int 	r, c, i, j, wmid;
  int	nfeat= 1;
  boole	max;	   
  
  xgrad_base= 	(float *) calloc(fdim2, sizeof(float));
  xgrad= 	(float **) farray(xgrad_base, nrow, ncol);

  ygrad_base= 	(float *) calloc(fdim2, sizeof(float));
  ygrad= 	(float **) farray(ygrad_base, nrow, ncol);  

  feat_base= 	(float *) calloc(fdim2, sizeof(float));  
  feat= 	(float **) farray(feat_base, nrow, ncol);

  fprintf(stderr,"EXTRACTION\n");
  XYGradGauss(ifr, xgrad, ygrad);
  
  wmid = (wsize-1)/2;	
  /* fprintf(stderr,"#TOT of rows= %d\nCurrent is\n", nrow);*/
  for (r= wmid; r < nrow-wmid; r++)       
    {       
      for (c= wmid; c < ncol-wmid; c++)
	{
	  x11= x12= x22= 0;
	  for (i= -wmid; i <= wmid; i++)	      
	    for (j= -wmid; j <= wmid; j++)
	      {
		x11+= xgrad[r+i][c+j] * xgrad[r+i][c+j] * wgaus[wmid+i][wmid+j];
		x22+= ygrad[r+i][c+j] * ygrad[r+i][c+j] * wgaus[wmid+i][wmid+j];
		x12+= xgrad[r+i][c+j] * ygrad[r+i][c+j] * wgaus[wmid+i][wmid+j];
	      }
	  feat[r][c]= CalcEigVal(x11, x12, x22);

	  /* Searching for maximums */   
	  if (feat[r][c] > rmax) rmax= feat[r][c]; 
	}
      fprintf(stderr, "."); 
    }
  fprintf(stderr,"\n");
  
  /* Cleans non local maximums */
  for (r= wmid; r < nrow-wmid; r++)
    for (c= wmid; c < ncol-wmid; c++)
      {
	eig[r][c]= (int)((feat[r][c]/rmax)*255);
	max= TRUE;
	for (i= -1; i < 2; i++)
	  for (j= -1; j < 2; j++)
	    {
	      if (feat[r][c] > 0.0)
		{
		  if (feat[r][c] < feat[r+i][c+j])
		    {
		      max= FALSE;
		      i = 2;
		      j = 2;;
		    }
		}  
	      else 
		max= FALSE;  
	    }

  	if (max == TRUE)
	  if (feat[r][c] >= soglia*rmax)
	    {  
	      ff[nfeat].num= nfeat;
	      ff[nfeat].row= (float)r + (float)ParabMin(r, feat[r-1][c],feat[r][c],feat[r+1][c]);
	      ff[nfeat].col= (float)c + (float)ParabMin(c, feat[r][c-1],feat[r][c],feat[r][c+1]);
	      ff[nfeat].cf= feat[r][c]/rmax;
	      nfeat++;
	      if (nfeat > MAXFEAT)
		merr("ERROR: Too many features extracted\n");    
	    } 
      }
  return nfeat-1;	 
}


double CalcWarp(byte **first, double row1, double col1, byte **last, double row2, double col2, int wsize, int sss)
/* x=k=rows
   y=l=coloumns */
{
  int k, l, i;
  int wmid= wsize/2;
  double x, y, x2, y2, xy, DX, DY, xg2, yg2, xyg, g2, diff, resid; 
  double avg_i, avg_f;
  double std_i, std_f;
  
  m_ident(A2);
  v_zero(d2);
  m_zero(MM2);

  for (k= -wmid; k <= wmid; k++)
    for (l= -wmid; l <= +wmid; l++)
      {
	g2= wgaus[k+wmid][l+wmid];
	x= k;
	y= l;
	x2= x*x;
	y2= y*y;
	xy= x*y;

        DX= DerivYF(first, row1+k, col1+l)*10;
        DY= DerivXF(first, row1+k, col1+l)*10;
 
	xg2= DX*DX;
	yg2= DY*DY;
	xyg= DX*DY;

	MM2->me[0][0]+= x2*xg2*g2;
	MM2->me[0][1]+= x2*xyg*g2;
	MM2->me[0][2]+= xy*xg2*g2;
	MM2->me[0][3]+= xy*xyg*g2;
	MM2->me[0][4]+= x*xg2*g2;
	MM2->me[0][5]+= x*xyg*g2;
	
	MM2->me[1][1]+= x2*yg2*g2;
	MM2->me[1][2]+= xy*xyg*g2;
	MM2->me[1][3]+= xy*yg2*g2;
	MM2->me[1][4]+= x*xyg*g2;
	MM2->me[1][5]+= x*yg2*g2;
	
	MM2->me[2][2]+= y2*xg2*g2;
	MM2->me[2][3]+= y2*xyg*g2;
	MM2->me[2][4]+= y*xg2*g2;
	MM2->me[2][5]+= y*xyg*g2;
	
	MM2->me[3][3]+= y2*yg2*g2;
	MM2->me[3][4]+= y*xyg*g2;
	MM2->me[3][5]+= y*yg2*g2;
	
	MM2->me[4][4]+= xg2*g2;
	MM2->me[4][5]+= xyg*g2;
	
	MM2->me[5][5]+= yg2*g2;
      }

  MM2->me[1][0]= MM2->me[0][1];
  MM2->me[2][0]= MM2->me[0][2];
  MM2->me[3][0]= MM2->me[0][3];
  MM2->me[4][0]= MM2->me[0][4];
  MM2->me[5][0]= MM2->me[0][5];
  MM2->me[2][1]= MM2->me[1][2];
  MM2->me[3][1]= MM2->me[1][3];
  MM2->me[4][1]= MM2->me[1][4];
  MM2->me[5][1]= MM2->me[1][5];
  MM2->me[3][2]= MM2->me[2][3];
  MM2->me[4][2]= MM2->me[2][4];
  MM2->me[5][2]= MM2->me[2][5];
  MM2->me[4][3]= MM2->me[3][4];
  MM2->me[5][3]= MM2->me[3][5];
  MM2->me[5][4]= MM2->me[4][5];
 
  svd(MM2, U2, V2, svdvals2);
  m_zero(MD2);
  
  MD2->me[0][0]= (svdvals2->ve[0] < LOWER) ? 0.0 : 1.0 / svdvals2->ve[0];
  MD2->me[1][1]= (svdvals2->ve[1] < LOWER) ? 0.0 : 1.0 / svdvals2->ve[1];
  MD2->me[2][2]= (svdvals2->ve[2] < LOWER) ? 0.0 : 1.0 / svdvals2->ve[2];
  MD2->me[3][3]= (svdvals2->ve[3] < LOWER) ? 0.0 : 1.0 / svdvals2->ve[3];
  MD2->me[4][4]= (svdvals2->ve[4] < LOWER) ? 0.0 : 1.0 / svdvals2->ve[4];
  MD2->me[5][5]= (svdvals2->ve[5] < LOWER) ? 0.0 : 1.0 / svdvals2->ve[5];  	 
  m_transp(V2, V2);
  m_mlt(V2, MD2, MF2);
  m_mlt(MF2, U2, V2);

  for (i= 0; i <= MAXAFF; i++)
    {
      v_zero(a2);
      defT(last, row2, col2); 

      for (k= -wmid; k <= wmid; k++)
	for (l= -wmid; l <= +wmid; l++)
	  {
	    g2= wgaus[k+wmid][l+wmid];
	    x= k;
	    y= l;
	    diff= FD(first, row1+x, col1+y)-PATCH->me[k+wmid][l+wmid];

            DX= DerivYF(first, row1+k, col1+l)*10;
            DY= DerivXF(first, row1+k, col1+l)*10;
	    
	    a2->ve[0]+= diff*x*DX*g2;
	    a2->ve[1]+= diff*x*DY*g2;
	    a2->ve[2]+= diff*y*DX*g2;
	    a2->ve[3]+= diff*y*DY*g2;
	    a2->ve[4]+= diff*DX*g2;
	    a2->ve[5]+= diff*DY*g2;
	  } 
      mv_mlt(V2, a2, z2);
  
      A2->me[0][0]+= z2->ve[0]*2;
      A2->me[1][0]+= z2->ve[1]*2;
      A2->me[0][1]+= z2->ve[2]*2;
      A2->me[1][1]+= z2->ve[3]*2;      
      d2->ve[0]+= z2->ve[4];
      d2->ve[1]+= z2->ve[5];	     
    }

/* Mean */
  avg_i= 0.0;
  avg_f= 0.0;
  for (k= -wmid; k <= wmid; k++)
    for (l= -wmid; l <= +wmid; l++)
      {
	avg_i+= FD(first, row1+k, col1+l);
	avg_f+= PATCH->me[k+wmid][l+wmid];
      }
  avg_i/= wsize*wsize;
  avg_f/= wsize*wsize;

/* Standard Deviation */
  std_i= 0.0;
  std_f= 0.0;
  for (k= -wmid; k <= wmid; k++)
    for (l= -wmid; l <= +wmid; l++)
      {
	std_i+= (FD(first, row1+k, col1+l)-avg_i)*(FD(first, row1+k, col1+l)-avg_i);
	std_f+= (PATCH->me[k+wmid][l+wmid]-avg_f)*(PATCH->me[k+wmid][l+wmid]-avg_f);
      }
  std_i= sqrt(std_i/(wsize*wsize));
  std_f= sqrt(std_f/(wsize*wsize));

  resid= 0.0;
  for (k= -wmid; k <= wmid; k++)
    for (l= -wmid; l <= +wmid; l++)
      resid+= ((FD(first, row1+k, col1+l)-avg_i)/std_i-(PATCH->me[k+wmid][l+wmid]-avg_f)/std_f)*((FD(first,row1+k,col1+l)-avg_i)/std_i-(PATCH->me[k+wmid][l+wmid]-avg_f)/std_f)*wgaus[k+wmid][l+wmid]*wgaus[k+wmid][l+wmid];

  return (resid/(wsize*wsize));
}	















