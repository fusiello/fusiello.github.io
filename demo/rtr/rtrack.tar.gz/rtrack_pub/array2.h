#ifndef MEMORY_H
#define MEMORY_H

#ifndef EXTERN
#define EXTERN extern
#endif

#ifndef byte
#define byte unsigned char
#endif

/**************************** exported constants  ***************************************/


/************************** exported GLOBAL variables  **********************************/


/************************* exported functions ********************************************/

EXTERN  byte  **barray(byte * image, int rows, int cols);
EXTERN  int   **iarray(int  * image, int rows, int cols);
EXTERN  float **farray(float * image, int rows, int cols);

#endif
