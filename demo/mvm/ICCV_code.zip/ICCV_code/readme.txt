*** This package is a simple demonstration of the multi-view matching algorithm (MatchEIG) presented in the paper:
Maset E., Arrigoni F. and Fusiello A.: Practical and Efficient Multi-view Matching, ICCV'17

Run test.m for a simple example of how to use the code.
The core routine is MatchEIG.m, which implements the method described in the reference paper below.