function Y = sampler( X, opts)
%SAMPLER
%When using the code in your research work, please cite the paper:
%L. Magri, A. Fusiello. Reconstruction of interior walls from point cloud data with min-hashed J-linkage. 
%3D Vision Conference, 2018.
%Please contact Luca Magri (magri[Dot]luca[Dot]l[At] gmail [Dot] com) for questions or suggestions about the code.

if(~isfield(opts,'sampling'))
    opts.sampling = 'uniform';
    disp('uniform sampling is adopted');
end
if(~isfield(opts,'robust') )
    opts.robust = 'off';
    disp('robust refitting is turned off')
end

epsi      = opts.epsi;
model     = opts.model;
sampling  = opts.sampling;
m         = opts.m;
robust    = opts.robust;


n = size(X,2);

switch sampling
    case 'localized'
        D = squareform(pdist(X','euclidean'));
        sigma = max(D(:))/4;
    case 'uniform'
    case 'nearest'
        tree = KDTreeSearcher(X');
        num_neigh = 20;
    otherwise
        sampling = 'uniform';
        warning('unifrom sampling is adopted');
        
end

H = nan(3,m);
R = nan(n,m);


switch opts.model
    case 'line'
        cardmss = 2;
        S = nan(cardmss,m);
        % main loopp
        for j = 1:m
            % instantiate mss
            if(strcmp(sampling,'uniform'))
                inds = randsample(n, cardmss,false);
            elseif(strcmp(sampling,'nearest'))
                seed = randsample(n, 1);
                bucket = knnsearch(tree,X(:,seed)','k',num_neigh);
                inds = datasample(bucket, cardmss,'Replace',false);
            elseif(strcmp(sampling,'localized'))
                inds = nan(1,cardmss);
                inds(1) = randsample(n, 1);
                w = exp(-(D(inds(1),:).^2)/sigma.^2);
                w(inds(1))=0;
                for i=2:cardmss
                    inds(i) = randsample(n,1,true,w);
                    w(inds(i)) = 0;
                end
            end
            S(:,j) = inds;
            mss = X(:,inds);
            % create model
            h1 = fit_line(mss);
            
            % compute residuals
            d1 = abs(h1(1).*X(1,:) + h1(2)*X(2,:) + h1(3));
            
            % refit model
            if(strcmp(robust,'x84'))
                epsi_x84 = x84(d1(d1<=epsi),cardmss);
                inliers = X(:,d1<=min(epsi,epsi_x84));
            else
                inliers = X(:,d1<=epsi);
            end
            
            card_cs1 = size(inliers,2);
            assert(card_cs1~=0)
        
            
            if(card_cs1 > cardmss)
                h2 = fit_line(inliers);
                d2 = abs(h2(1).*X(1,:) + h2(2)*X(2,:) + h2(3));
                card_cs2 = sum(d2<=epsi);
            else
                card_cs2 = 0;
            end
            % store sampling result
       

            if(card_cs2 >= card_cs1)
                H(:,j) = h2;
                R(:,j) = d2;
            else
                H(:,j) = h1;
                R(:,j) = d1;
            end
        end
        
        P = double(R<=epsi);
        
        
        
    
        
        
    otherwise
        error('the model is not defined: sampler supports ''line''.')
end







Y.S = S;
Y.H = H;
Y.R = R;
Y.P = double(P);





end

%%

function [thresh,inliers] =  x84(res, n)
% n e' il numero minimo di inliers che ritorna

theta = 2.5;
% attenzione: il theta di default di X84 e' 3.5
% cosi' e' piu' restrittivo, ma in linea con la regola di selezione degli
% inliers in LMEDS

location = nanmedian(res(:));
scale = theta/0.6745 * nanmedian(abs(res(:)-location));
inliers = abs(res-location) <= scale;
thresh = scale+location;
%fprintf('x84 scale: %f \n', scale+location);

if length(inliers) < n
    % ritorna i primi n
    [~, i] = sort(res);
    inliers = i(1:min(numel(i),n));
    inliers =  sort(inliers);
    
end
end

