% This code run the min-Hashed J-Linkage on the data set "star5".
%Terms of use: 
%The code is provided for research purposes only and without any warranty.
%When using the code in your research work, please cite the paper:
%L. Magri, A. Fusiello. Reconstruction of interior walls from point cloud data with min-hashed J-linkage. 
%3D Vision Conference, 2018.
%Please contact Luca Magri (magri[Dot]luca[Dot]l[At] gmail [Dot] com) for questions or suggestions about the code.

clear; close all;
%% load data
name_db = 'star5';
load(name_db);
n = size(X,2);
G = G(1:n);


% show results
show_on = 1;

xmin = min(X(1,:)); xmax = max(X(1,:)); ymin = min(X(2,:)); ymax = max(X(2,:));
dx = 0.3*(xmax -xmin);       dy = 0.3*(ymax-ymin);
crop_x = [xmin-dx, xmax+dx]; crop_y = [ymin-dy, ymax+dy];



if(show_on)
    figure; scatter(X(1,:),X(2,:),10,'k','filled');
    set(gca,'xtick',[])
    set(gca,'ytick',[])
    xlim(crop_x); 
    ylim(crop_y);
    box on;

end



%%  sampling
epsi = 0.05;
opts_line.epsi = epsi;
opts_line.model = 'line';
opts_line.sampling ='localized';%'nearest';
opts_line.m = 15000;
opts_line.robust = 'x84';
cardmss.line = 2;
S.line = sampler(X,opts_line);

%% clustering 

kappa  = 300; % number of min-hash signatures
B   = jlnk_minhash(S.line.P,kappa);
B1 = outlier_rejection_card( B, 2 );


%% show segmentation

Mb = recover_line(X,B1);
figure;
display_lines( X, B1, Mb,epsi )
scatter(X(1,B1==0),X(2,B1==0),10,[.7,.7,.7],'filled')
axis off;
