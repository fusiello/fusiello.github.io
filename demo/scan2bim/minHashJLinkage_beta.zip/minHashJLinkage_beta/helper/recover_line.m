function M = recover_line( X,G )
n = max(G);
M = nan(3,n);
for i = 1:n
    inliers = X(:,G==i);
    if(sum(G==i)>=2)
        M(:,i) = fit_line(inliers);
    else
        fprintf('there are too few points in cluster %i to define a line\n',i)
    end

end


end

