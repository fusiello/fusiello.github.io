These datasets are distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

To use this dataset, please cite the pubblication:

- L.Magri, A.Fusiello, Fitting Multiple Heterogeneous Models by Multi-class Cascaded T-linkage, CVPR 2019

@INPROCEEDINGS{magfus2019,
  author = {L.Magri and A.Fusiello},
  title = {Fitting Multiple Heterogeneous Models by Multi-class Cascaded T-linkage},
  booktitle = {International Conference on Computer Vision and Pattern Recognition (CVPR)},
  year = {2019}
}


X is a 2xN matrix and contains per columns 2D position of points.
G is a vector containing cluster labels. The label 0 correspond to outlying point.