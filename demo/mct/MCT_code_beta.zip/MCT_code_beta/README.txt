Run demo_MCT.m to perform simultaneous estimation of fundamental matrices and homographies from sparse correspondences on a stereo pair from the Adelaide Cube FH dataset.

These code is distributed in the hope that they will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

To use this code, please cite:
L.Magri, A.Fusiello, Fitting Multiple Heterogeneous Models by Multi-class Cascaded T-linkage, CVPR 2019

 @INPROCEEDINGS{magfus2019,
  author = {L.Magri and A.Fusiello},
  title = {Fitting Multiple Heterogeneous Models by Multi-class Cascaded T-linkage},
  booktitle = {International Conference on Computer Vision and Pattern Recognition (CVPR)},
  year = {2019}
}

Thank you!