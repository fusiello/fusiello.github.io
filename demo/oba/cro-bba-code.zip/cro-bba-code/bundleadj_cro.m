function [P_out,M_out,sz] = bundleadj_cro(P,M,K,q,vis,n_rel)
    % BUNDLEADJ_CRO  Bundle Block Adjustment with Constrained Relative
    % Orientations for multi-head camera systems with known internal
    % parameters.
    % "nad" is the reference camera (in Maltese cross, it is the
    % nadir-looking camera), "ob" cameras have a fixed but unknown
    % relative orientation wrt "nad"
    % with n_rel = 0 is the classical BBA
    
    n_imm = size(P,2);
    n_nad = n_imm/(n_rel+1);
    n_ob = n_nad*n_rel;
    
    p = 6*n_nad;     % # unknowns for nadir cameras
    f = p + 6*n_rel; % # total unknowns
    
    if ~iscell(K) % if K is the same for all cameras
        tmp = K;
        K = cell(1,n_imm);
        for i = 1:n_imm
            K{i} = tmp;
        end
    end
   
    % centralize points (improve conditioning)
    C = mean(M,2) ;
    M = M - repmat(C,1,size(M,2));
    Tc = [eye(3), -C];  Tc(4,4) = 1;
   
    for i = 1:n_imm
        % K is fixed and assigned for each image
        foo = K{i}\[q{i}; ones(1, size(q{i},2))];
        q{i} = double(foo(1:2,:));  % normalized image coordinates
    end
    
    % approximate exterior orientation parameters (EOP) for nadir images
    g_nad = zeros(p,1);
    for i = 1:n_nad
        P{i} = P{i} / Tc; % pre-conditioning
        g_nad(6*i-5:6*i-3) = ieul(K{i}\P{i}(1:3,1:3));
        g_nad(6*i-2:6*i) = K{i}\P{i}(1:3,4);
    end
    
    % approximate relative EOP computed as averaged values
    if n_rel > 0
        g_rel = NaN(6*n_rel,n_nad);
        for j = 1:n_ob
            if(mod(j,n_rel))
                u = fix(j/n_rel)+1; % nadir camera index
                v = mod(j,n_rel);   % oblique camera index
            else
                u = fix(j/n_rel);
                v = n_rel;
            end
            P{n_nad+j} = P{n_nad+j} / Tc; % pre-conditioning
            R_ob = K{n_nad+j}\P{n_nad+j}(1:3,1:3);
            t_ob = K{n_nad+j}\P{n_nad+j}(1:3,4);
            R_rel = R_ob/eul(g_nad(6*u-5:6*u-3));
            g_rel(6*v-5:6*v-3,u) = ieul(R_rel);
            g_rel(6*v-2:6*v,u) = t_ob - R_rel*g_nad(6*u-2:6*u);
        end
        g_rel = nanmean(g_rel,2);
    else   % if n_rel = 0 (classical BBA)
        g_rel = [];
    end
    
    [~,J] = fobj([g_nad;g_rel;M(:)],q,logical(vis),n_rel);
    % get the size of Jacobian
    sz = size(J);
    
    % solve the nonlinear least squares problem
    % 'Reduced' means that Levenberg-Marquardt is using jacobian partitioning
    x_out = lsq_nonlin(@(x)fobj(x,q,logical(vis),n_rel),[g_nad;g_rel;M(:)],'Reduced','Verbose');
    
    P_out = cell(1,n_imm);
    g_nad_out = x_out(1:p);
    g_rel_out = x_out(p+1:f);
  
    M_out = htx(inv(Tc), reshape(x_out(f+1:end),3,[]));
    for i = 1:n_nad
        P_out{i} = K{i} * [eul(g_nad_out(6*i-5:6*i-3)) g_nad_out(6*i-2:6*i)] * Tc;
    end
    for j = 1:n_ob
        if(mod(j,n_rel))
            u = fix(j/n_rel)+1; % nadir camera index
            v = mod(j,n_rel);   % oblique camera index
        else
            u = fix(j/n_rel);
            v = n_rel;
        end
        P_out{n_nad+j} = K{n_nad+j} * [eul(g_rel_out(6*v-5:6*v-3))*eul(g_nad_out(6*u-5:6*u-3)), ...
            eul(g_rel_out(6*v-5:6*v-3))*g_nad_out(6*u-2:6*u)+g_rel_out(6*v-2:6*v)] *Tc;
    end   
end


function [res,J,f]  = fobj(x,q,vis,n_rel)
    % compute residuals and Jacobian to solve the optimization problem
    n_imm  = length(q);
    n_nad  = n_imm/(n_rel+1);
    n_ob   = n_nad*n_rel;
    n_pts  =  size(q{1},2);
    
    p = 6*n_nad;
    f = p + 6*n_rel; % end of orientation parameters
    
    gu = x(1:p);
    guv = x(p+1:f);
    M = reshape(x(f+1:end),3,[]);
    
    % initialize Jacobian and residuals
    J = zeros(2*nnz(vis), f + 3*n_pts);
    res = zeros(2*nnz(vis),1);
    
    rows = 1:2;
    % compute Jacobian and residuals for nadir images
    for i = 1:n_nad
        [R,JR] = eul(gu(6*i-5:6*i-3));  t = gu(6*i-2:6*i);
        for k = 1:n_pts
            if vis(k,i)
                % Jacobian blocks for nadir images (classical BBA blocks)
                [r,JA,JB] = reproj_err_nad([R t], M(:,k),q{i}(:,k));
                J(rows, 6*i-5:6*i-3) = JA(:,1:9) * JR; % wrt rotation
                J(rows, 6*i-2:6*i)   = JA(:,10:end);   % wrt translation
                J(rows, f+3*k-2:f+3*k) = JB; % wrt 3D point
                res(rows) = r;
                rows = rows+2;
            end
        end
    end
    
    % compute Jacobian and residuals for oblique images
    for j = 1:n_ob
        i = n_nad+j;         
        if(mod(j,n_rel))
            u = fix(j/n_rel)+1; % nadir camera index
            v = mod(j,n_rel);   % oblique camera index
        else
            u = fix(j/n_rel);
            v = n_rel;
        end
        
        [Ru,Ju]  = eul(gu(6*u-5:6*u-3));  tu  = gu(6*u-2:6*u);
        [Ruv,Juv] = eul(guv(6*v-5:6*v-3)); tuv = guv(6*v-2:6*v);
        for k = 1:n_pts
            if vis(k,i)
                % Jacobian blocks for oblique images
                [r,JC,JD,JE] = reproj_err_ob(Ru, tu, Ruv, tuv, M(:,k),q{i}(:,k));
                
                J(rows, 6*u-5:6*u-3)  =  JC(:,1:9) *Ju; % wrt rotation (nadir)
                J(rows, 6*u-2:6*u)    =  JC(:,10:end);  % wrt translation (nadir)
                J(rows, p+6*v-5:p+6*v-3) =  JD(:,1:9) *Juv; % wrt rotation (relative)
                J(rows, p+6*v-2:p+6*v)   =  JD(:,10:end); % wrt translation (relative)
                J(rows, f+3*k-2:f+3*k) = JE; % wrt 3D point
                res(rows) = r;
                rows = rows+2;
            end
        end
    end
end

