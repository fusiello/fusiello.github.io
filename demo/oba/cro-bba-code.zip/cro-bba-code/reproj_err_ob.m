function [res,JC,JD,JE]  = reproj_err_ob(Ru, tu, Ruv, tuv, M, m)
    % REPROJ_ERR_OB Optimized reprojection error and Jacobian of bundle 
    % adjustment with constrained relative orientations for oblique
    % cameras, with known internal parameters
     
    W   = (Ruv*Ru) * M + (Ruv * tu + tuv);
    Mp = W./W(3); Mp(3) = []; % project W
    Jp = [ 1/W(3), 0, -W(1)/W(3)^2; 0, 1/W(3), -W(2)/W(3)^2];
     
    res = Mp - m(:);
    
    JC = Jp * [M(1)*Ruv,  M(2)*Ruv, M(3)*Ruv, Ruv]; % wrt nadir EOP
    x = Ru*M(:) + tu;
    JD = Jp * [ [x(1)*eye(3), x(2)*eye(3), x(3)*eye(3)], eye(3)]; % wrt relative EOP
    JE = Jp * Ruv * Ru; % wrt 3D point
    
end



