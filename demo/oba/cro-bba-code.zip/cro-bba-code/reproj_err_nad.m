function [res,JA,JB]  = reproj_err_nad(G,M,m)
    % REPROJ_ERR_NAD Optimized reprojection error and jacobian for 1 point, 
    % 1 camera, known internal parameters
    
    % G = [R,t]
    
    W  = G*[M(:);1];
    Mp = W./W(3); Mp(3) =[]; % project W
    res = Mp - m(:);
    Dfp = [ 1/W(3), 0, -W(1)/W(3)^2; 0, 1/W(3), -W(2)/W(3)^2];
    JA = Dfp * [M(1)*eye(3),M(2)*eye(3),M(3)*eye(3),eye(3)]; % wrt external par.
    JB = Dfp * G(:,1:3); % wrt 3D point
    
end