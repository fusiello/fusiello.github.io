% Bundle Block Adjustment with Constrained Relative Orientations, 2020
% The CV Toolkit is required
% Authors: E. Maset (eleonora.maset@uniud.it)
%          A. Fusiello (andrea.fusiello@uniud.it)

%% Load input data
%---------------------------------------------------------------------
clear 
close all
sd = RandStream('mt19937ar','Seed',1); % for reproducibility
RandStream.setGlobalStream(sd);


fprintf('\n----------------------Loading input data...\n');
load('input_data.mat')
% The dataset was synthetically generated considering a system composed of 
% one nadir-looking camera and 4 oblique cameras, arranged in Maltese cross.
% Subscript 'nad' refers to nadir camera, subscript 'ob' to oblique cameras,
% Subscript 'rel' refers to relative orientation
% K: 3x3 matrix with interior orientation parameters
% R: cell array of 3x3 rotation matrices
% cop: 3xq centres of projection (t = - R*cop)
% M: 3xn object point coordinates
% vis: visibility matrix (vis(i,j)=1 if point i is seen in image j)
% m: cell array of 2xn image point matrices (the first n_nad cells refer
% to nadir images, cells from n_nad+1 to n_nad+n_ob refer to oblique images.
% Oblique images relative to the same nadir image are consecutive and ordered 
% consistently.)

n_nad = size(cop_nad,2); % # nadir images
n_rel = size(cop_rel,2); % # oblique cameras (=4 in Maltese cross)
n_ob = size(cop_ob,2);   % # oblique images (=n_nad*n_rel)
n_imm = n_nad+n_ob;      % # total images 


%% Data visualization
%---------------------------------------------------------------------
% plot 3D object points
figure, plot3(M(1,:),M(2,:),M(3,:),'x','Markersize',6,'Color', [0.3 0.3 0.3]); hold on

% plot nadir camera positions
P_nad = cell(1,n_nad);  % initialize Perspective Projection Matrices (PPM) 
for u = 1:n_nad    
    P_nad{u} = K*[R_nad{u}, -R_nad{u}*cop_nad(:,u)]; % P = K[R|t]
    plotcam(P_nad{u},100,'b'); hold on  
end

% plot oblique camera positions
P_ob = cell(1,n_ob);
color = ['y','g','r','c'];
for i = 1:n_ob
    % determine oblique camera index (1,...,n_rel)
    if(mod(i,n_rel))
        v = mod(i,n_rel);   
    else
        v = n_rel;
    end    
    P_ob{i} = K*[R_ob{i}, -R_ob{i}*cop_ob(:,i)];
    plotcam(P_ob{i},100,color(v)); hold on
end
axis off
title('Cameras and 3D points');

% show visibility matrix
figure, spy(vis), title('Visibility');ylabel('points'); xlabel('images')


%% Compute initial (approximate) values
%---------------------------------------------------------------------
noise_nad = 0.2;  % std dev of noise added to ground truth nadir orientation
noise_rel = 0.05; % std dev of noise added to ground truth relative orientation
noise_img = 1.5;    % std dev of noise added to image coordinates

% perturbation of ground truth values
% add noise to gt nadir camera orientations
P_nad_in = cell(1,n_nad);
G_nad_in = cell(1,n_nad); % G = [R t; 0 0 0 1]
for i = 1:n_nad
    % perturb nadir euler angles
    ang_noise = ieul(R_nad{i}) + noise_nad*pi/180*randn(3,1);
    % perturb COP
    cop_noise = cop_nad(:,i) + noise_nad*randn(3,1);
    G_nad_in{i} = [eul(ang_noise), -eul(ang_noise)*cop_noise; 0 0 0 1];
    P_nad_in{i} = K*G_nad_in{i}(1:3,:);
end

% add noise to gt relative orientations
G_rel_noise = cell(1,n_rel);    
for i = 1:n_rel
    % perturb relative euler angles
    ang_rel_noise = ieul(R_rel{i}) + noise_rel*pi/180*randn(3,1);
    % perturb relative COPs
    cop_rel_noise = cop_rel(:,i) + noise_rel*randn(3,1);
    G_rel_noise{i} = [eul(ang_rel_noise), -eul(ang_rel_noise)*cop_rel_noise; 0 0 0 1];
end

% compute approximate oblique image orientations
P_ob_in = cell(1,n_ob);
for i = 1:n_ob
    if(mod(i,n_rel))
        u = fix(i/n_rel)+1; % nadir camera index
        v = mod(i,n_rel);   % oblique camera index
    else
        u = fix(i/n_rel);
        v = n_rel;
    end
    G_ob_noise = G_rel_noise{v}*G_nad_in{u};
    P_ob_in{i} = K*G_ob_noise(1:3,:);
end
% initial values of PPMs 
P_in = [P_nad_in, P_ob_in];

% add noise to image coordinates
m_noise = cell(1,n_imm);
for i = 1:n_imm
    m_noise{i} = m{i} + noise_img*randn(size(m{i}));
end

% compute approximate 3D point coordinates
M_in = triang_lin_batch(P_in, m_noise, vis);

% initial reprojection error
sqerr = 0;
for i = 1:n_imm
    m_est = htx(P_in{i},M_in);  % project with estimated camera
    err_repr = m_noise{i}-m_est;
    sqerr = sqerr + norm(err_repr(:,vis(:,i)),'fro')^2;
end
fprintf('Initial RMS image residuals:\t %0.4f \n', sqrt(sqerr/(2*sum(sum(vis)))));


%% Ordinary Bundle Block Adjustment (BBA)
%---------------------------------------------------------------------   
fprintf('\n----------------------Performing Ordinary BBA...\n');
[P_bba,M_bba,sz] = bundleadj_cro(P_in,M_in,K,m_noise,vis,0);
% with 0 oblique cameras is equivalent to classical BBA
% if interior parameters are not the same for all cameras, K should be a 
% 1xn_imm cell array 

% compute reprojection error
sqerr = 0;
for i = 1:n_imm
    m_est = htx(P_bba{i},M_bba);  % project with estimated camera
    err_repr = m_noise{i}-m_est;
    sqerr = sqerr + norm(err_repr(:,vis(:,i)),'fro')^2;
end
fprintf('RMS image residuals:\t %0.4f \n', sqrt(sqerr/sz(1)));
fprintf('RRV:\t %0.4f \n', sqrt(sqerr/(sz(1)-sz(2))));

% compute error on 3D points
[R,t,s] = opa(M,M_bba); % align object points to control points using Procrustes Analysis
u = ones(size(M,2),1);
E_pts_bba = M - s*(R*M_bba+t*u'); % alignment residuals
fprintf('RMS on 3D Control Points:\t %0.4f \n', sqrt(mean(sum(E_pts_bba.^2,1),2)));

% compute error on Centres of Projections
cop_bba = zeros(3,n_imm);
for i = 1:n_imm
    G_bba = K\P_bba{i};
    cop_bba(:,i) = -G_bba(:,1:3)'*G_bba(:,4);
end
[R,t,s] = opa([cop_nad,cop_ob],cop_bba); % align estimated COPs to gt
u = ones(size(cop_bba,2),1);
E_cop_bba = [cop_nad,cop_ob] - s*(R*cop_bba+t*u'); % alignment residuals
fprintf('RMS on COPs:\t %0.4f \n', sqrt(mean(sum(E_cop_bba.^2,1),2)));


%% Constrained Relative Orientation Bundle Block Adjustment (CRO-BBA)
%---------------------------------------------------------------------
fprintf('\n----------------------Performing CRO-BBA...\n');
[P_cro,M_cro,sz] = bundleadj_cro(P_in,M_in,K,m_noise,vis,n_rel);
% if interior parameters are not the same for all cameras, K should be a 
% 1xn_imm cell array 

% compute reprojection error
sqerr = 0;
for i = 1:n_imm
    m_est = htx(P_cro{i},M_cro);  % project with estimated camera
    err_repr = m_noise{i}-m_est;
    sqerr = sqerr + norm(err_repr(:,vis(:,i)),'fro')^2;
end
fprintf('RMS image residuals:\t %0.4f \n', sqrt(sqerr/sz(1)));
fprintf('RRV:\t %0.5g \n', sqrt(sqerr/(sz(1)-sz(2))));

% compute error on 3D points
[R,t,s] = opa(M,M_cro); % align object points to control points using Procrustes Analysis
u = ones(size(M,2),1);
E_pts_cro = M - s*(R*M_cro+t*u'); % alignment residuals
fprintf('RMS on 3D Control Points:\t %0.4f \n',sqrt(mean(sum(E_pts_cro.^2,1),2)));

% compute error on Centres of Projections
cop_cro = zeros(3,n_imm);
for i = 1:n_imm
    G_cro = K\P_cro{i};
    cop_cro(:,i) = -G_cro(:,1:3)'*G_cro(:,4);
end
[R,t,s] = opa([cop_nad,cop_ob],cop_cro); % align estimated COPs to gt
u = ones(size(cop_cro,2),1);
E_cop_cro = [cop_nad,cop_ob] - s*(R*cop_cro+t*u'); % alignment residuals
fprintf('RMS on COPs:\t %0.4f \n',sqrt(mean(sum(E_cop_cro.^2,1),2)));

    