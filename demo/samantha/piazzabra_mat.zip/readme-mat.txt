Points(3xN): contains the N tridimensional extracted points.

Pmat(3x4xM): contains the M 3x4 projection matrices associated to each image.

Visibility (NxM): logical matrix containing the visibility information. If a point X is visible from a camera C then Visibility(X,C) = 1.



Reference paper: A. M.Farenzena, A.Fusiello, R. Gherardi. Structure-and-Motion Pipeline on a Hierarchical Cluster Tree. Proceedings of the IEEE International Workshop on 3-D Digital Imaging and Modeling, Kyoto, October 2009.
