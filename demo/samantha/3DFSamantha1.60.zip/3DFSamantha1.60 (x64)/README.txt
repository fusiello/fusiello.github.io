3DF Samantha is a structure and motion pipeline that  takes in input a set of images and produces a 3D reconstruction of the scene.

Usage: 3DFSamantha [settings file]

See manual.pdf for  more information.

The binary software is distributed for research purposes only and cannot be redistributed or used for commercial purposes. See the License.pdf  file for a detailed description.
3DF Samantha and the Ogrettha visualizer use third party libraries distributed under BSD, L-GPL or similar licenses. The relative licenses, disclaimers and acknowledgments are in the ThirdPartyLicenses folder.

Please report any bug/suggestion to: samantha@3dflow.net.
