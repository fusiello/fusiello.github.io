#Uncalibrated View Synthesis 

### Andrea Fusiello, 2018

Collection of Matlab function implementing unvcalibrated view synthesis
as described in the reference paper below.

It requires functions contained in the [Computer Vision Toolkit]
(http://www.diegm.uniud.it/fusiello/demo/toolkit/ComputerVisionToolkit.zip)
by the same author.

Type `runMe` at the MATLAB promt.

Reference paper:

	@Article{Fus07tcsvt,
	  author =	 { A. Fusiello},
	  title =	 {Specifying Virtual Cameras in Uncalibrated View Synthesis },
	  journal =	 {IEEE Transactions on Circuits and Systems for Video Technology},
	  year =	 2007,
	  volume =	 17,
	  number =	 5,
	  pages =	 {604-611},
	  issn =	 {1051-8215},
	  doi =		 {10.1109/TCSVT.2007.894049},
	  webpdf =	 {http://www.diegm.uniud.it/fusiello/papers/tcsvt07.pdf}
	}
	

---
Andrea Fusiello                
Dipartimento Politecnico di Ingegneria e Architettura (DPIA)  
Università degli Studi di Udine, Via Delle Scienze, 208 - 33100 Udine  
email: <andrea.fusiello@uniud.it>

---
