function gamma = parallax(H,e,m1,m2)
    % compute parallax wrt to a plane H
    % input: H, plane homography
    %        e, epipole
    %        m1 point coordinates view 1
    %        m2 point coordinates view 2
    % output: gamma, parallax of the points in view 1
    
    % Author: A. Fusiello, 2007, 2019 (andrea.fusiello@uniud.it)
    
    np = size(m1,2);
    m1 = [m1;ones(1,np)]; 
    m2 = [m2;ones(1,np)];
    % now m1 and m2 are homogeneous
    
    epi = repmat(e,[1 np]);
    hm = H * m1;
    gamma = dot(cross(m2,epi),cross(hm,m2))./ dot(cross(m2,epi),cross(m2,epi));