% This scipt have been used to produce the synthetic sequences shown 
% in the paper: A. Fusiello. Specifying virtual cameras in uncalibrated 
% view synthesis. IEEE TCSVT, 17(5): 604-611, 2007.
%
% It produces two sequences, one from two reference views
% and the other using three reference views. The core functions are
% 'parallax' and 'synthesis'. The trajectory generation is implemented
% inside the 'for' cycles, before the call to 'synthesis'.

% Author: A. Fusiello, 2007, 2019 (andrea.fusiello@uniud.it)

% 2019: made compatible with the new CVtoolkit


clear all
close all

load('tribuna.mat');
% load vertices and edges

% intrinsic parameters
K = [1340   0      380
    0      1340   520
    0      0      1];

% K tilde matrix (see paper)
Kt = eye(4); Kt(1:3,1:3) = K;

G1 = [camera([0 0 5]',[ -0.6, 0.5, -2.5]',[0 1000 0]'); 0 0 0 1];
G2 = [camera([2 0 5]',[ -0.6, 0.5, -2.5]',[0 1000 0]'); 0 0 0 1];
G3 = [camera([0 1 5]',[ -0.6, 0.5, -2.5]',[0 1000 0]'); 0 0 0 1];

P1 = K * G1(1:3,:);
P2 = K * G2(1:3,:);
P3 = K * G3(1:3,:);

G12=G2/(G1);
G13=G3/(G1);

% obtain corresponding points
m1 = htx(P1,vertices');
m2 = htx(P2,vertices');
m3 = htx(P3,vertices');

% obtain epipoles + random scale to simulate real measures
[F12,e21]=fund(P1,P2);
e21 = e21/norm(e21);
[F13,e31]=fund(P1,P3);
e31 = e31/norm(e31);

% obtain infinity plane homographies
H12 = P2(1:3,1:3)/P1(1:3,1:3);
H13 = P3(1:3,1:3)/P1(1:3,1:3);
% they have det=1

% The items above (corresp. points, epipoles and infinity plane
% homographies) in a real scenario must be obtained from the images.

% scale e31 such that the parallax of first point is 1
e31 = e31 * parallax(H13,e31,m1(:,1),m3(:,1));
% scale e21 such that the parallax of first point is 1
e21 = e21 * parallax(H12,e21,m1(:,1),m2(:,1));

% NOTE: this normalization is superfluous in the case of two views
% since there is only one epipole, and a global scale in the parallax 
% gets absorbed. Instead it is needed in the case of 3 views since the
% parallax 1-2 must be equal to that 1-3 and this is obtained by
% making that they are both 1 on the first point.

% compute parallax 1-2
gamma = parallax(H12,e21,m1,m2);

% uncalibrated displacement matrices
D12=[H12 , e21; 0 0 0 1];
D13=[H13 , e31; 0 0 0 1];

% make sure that axis contains the reference images
plot(m1(1,:), m1(2,:), '.k', m2(1,:), m2(2,:),'.k', m3(1,:), m3(2,:),'.k')
f = axis;

% View Synthesis from two reference views
figure
for alfa = -1.2:0.1:2.2
    
    % calibrated in red
    G1t=real(expm((alfa*logm(G12))));
    P1t = K*[eye(3), [0 0 0]'] * G1t * G1;
    mt = htx(P1t, vertices');
    wireframe(mt', edges,'r');
    axis(f), hold on, pause(0.01);
    
    
    % uncalibrated in blue
    D1t=real(expm((alfa*logm(D12))));
    H1t=D1t(1:3,1:3);
    et1=D1t(1:3,4);
    mt = synthesis(H1t,m1,gamma,et1);
    wireframe(mt', edges,'b');
    axis(f), hold off, pause(0.01);
    hold off
    
end

% View Synthesis from three reference views
figure
for t = -1.2:0.1:2.2
    % describe a circle (u and v can be arbitrary)
    u = cos((t+1.2)/3.4*2*pi)/2*3.4+0.5;
    v = sin((t+1.2)/3.4*2*pi)/2*3.4+0.5;
    
    % calibrated in red
    G1t=real(expm((u*logm(G12)+v*logm(G13))));
    P1t = K*[eye(3), [0 0 0]'] * G1t * G1;
    mt = htx(P1t, vertices');
    wireframe(mt', edges,'r');
    axis(f), hold on, pause(0.01);
    
    % uncalibrated in blue
    D1t=real(expm((u*logm(D12)+v*logm(D13))));
    H1t=D1t(1:3,1:3);
    et1=D1t(1:3,4);
    mt = synthesis(H1t,m1,gamma,et1);
    wireframe(mt', edges,'b');
    axis(f), hold off, pause(0.01);
    
end


