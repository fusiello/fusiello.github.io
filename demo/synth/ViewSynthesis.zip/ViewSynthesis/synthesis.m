function m2 = synthesis(H,m1,gamma,e)
    % point transfer function
    % input: H, plane homography
    %        m1 point coordinates
    %        gamma, parallax
    %        e, epipole
    % output: m2 transferred points
    
     % Author: A. Fusiello, 2007, 2019 (andrea.fusiello@uniud.it)
    
    np = size(m1,2);
    m1 = [m1;ones(1,np)];
    % now m is homogeneous
    
    epi = repmat(e,[1 np]);
    hm = H * m1;
    m2 = hm + (epi*diag(gamma));
    
    m2 = m2 ./ repmat(m2(3,:), [3 1]); % projective division
    m2(3,:) = []; % remove ones
    
    