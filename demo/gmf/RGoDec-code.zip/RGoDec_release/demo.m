

clear,clc,close all
addpath('./auxiliary_functions')


nviews = 100; % number of cameras
prob_out=0.3; % fraction of outliers
sigma_a=5; % noise (degrees)
fraction_missing = 0.5; % fraction of missing data


%% R-GoDec parameters

power = 10; % parameter of Bilateral Random Projections
iter_max = 100; % maximum number of iterations
rank_MC = 3; % theoretical rank of the data matrix


%% generate ground truth

R_gt = zeros(3,3,nviews); % absolute rotations
for i = 1:nviews
    R_gt(:,:,i) = eul(randn(1,3)); % random Euler angles
end

% 3 x 3*nviews matrix with absolute rotations
Y_R = reshape(permute(R_gt,[1,3,2]),[],3); 

% 3*nviews x 3*nviews matrix with relative rotations
G_gt = Y_R*Y_R'; 


%% add noise on relative rotations

G = G_gt; % noisy matrix with relative rotations
for i=1:nviews
    for j=i+1:nviews
        
        % random axis
        r = rand(3,1)-0.5;
        if norm(r)~=0
            r=r/norm(r);
        end
        
        % small angle
        angle = randn()+sigma_a;
        angle=angle*pi/180;
        noise = inv_axis_angle(angle,r);
        
        G(3*i-2:3*i,3*j-2:3*j)=G(3*i-2:3*i,3*j-2:3*j)*noise(1:3,1:3);
        G(3*j-2:3*j,3*i-2:3*i)=G(3*i-2:3*i,3*j-2:3*j)';
        
    end
end


%% generate the epipolar graph

if fraction_missing==0
    A=ones(nviews);
else
    n_conn=2;
    while n_conn~=1 % generate a new graph if the current one is not connected
        A=rand(nviews)>=fraction_missing;
        A=tril(A,-1);
        A=A+A'+eye(nviews); % symemtric Adjacency matrix
        [n_conn] = graphconncomp(sparse(A),'Directed', false);
    end
    
end

%% put missing blocks in correspondence of missing pairs

G = G.*kron(A,ones(3));


%% Generate the outlier graph

[I,J]=find(triu(A));
n_pairs=length(I);

n_conn=2;
while n_conn~=1
    
    W=rand(n_pairs,1)<prob_out;
    A_outliers=sparse(I,J,W,nviews,nviews);
    A_outliers=A_outliers+A_outliers'; % graph representing outlier rotations
    
    % graph representing inlier rotations: it must be connected
    A_inliers=not(A_outliers)&A; 
    [n_conn] = graphconncomp(sparse(A_inliers),'Directed', false);
end


%% Add outliers among relative motions

for i=1:nviews
    for j=i+1:nviews
        
        if A_outliers(i,j)==1
            
            [u,~,v]=svd(rand(3));
            Rij=u*diag([1 1 det(u*v')])*v';
            
            G(3*i-2:3*i,3*j-2:3*j)=Rij;
            G(3*j-2:3*j,3*i-2:3*i)=Rij';
            
        end
    end
end


%% compute absolute rotations with R-Godec

n_rotations=nnz(A); % number of relative rotations
lambda = 0.02* sqrt(2*log(9*n_rotations));
tic
[G_godec,S,status]=R_GoDec_mixed(G,rank_MC,lambda,power,iter_max,1e-5);
toc
% compute rotations from the low-rank term: use the first block-column
R_bgodec = RijtoRi(G_godec,nviews,1); 

% compute error
[err_godec]=error_R(R_bgodec,R_gt);

disp('Average angular error (degrees):')
mean(err_godec)




