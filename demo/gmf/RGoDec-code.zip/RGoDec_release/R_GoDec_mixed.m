

function [L,S,status]=R_GoDec_mixed(L,rank_input,tau,power,iter_max,tol)
%{
Copyright (c) 2015, STMicroelectronics
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met: 
1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer. 
2. Redistributions in binary form must reproduce the above copyright notice, 
this list of conditions and the following disclaimer in the 
documentation and/or other materials provided with the distribution.
3. Neither the name of the copyright holder nor the names of its contributors 
may be used to endorse or promote products derived from this software without 
specific prior written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
THE IMPLIED WARRANTIES OF NONINFRINGEMENT, MERCHANTABILITY AND FITNESS FOR 
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
OF THE POSSIBILITY OF SUCH DAMAGE.
%}
%
%
%
% [L,S,status]=R_GoDec_mixed(L,rank_input,tau,power,iter_max,tol)
% computes the low-rank&sparse decomposition of the data matrix, which may
% contain missing entries, by using the R-GoDec Algorithm
%
% INPUT:
% L = data matrix
% rank_input = theoretical rank of the low-rank term
% tau = weight of L1 norm regularization for entries of S
% power: >=0, power scheme modification, increasing it lead to better
% accuracy and more time cost
% iter_max = maximum number of iterations
% rank_projection = method used to compute the rank-3 projection
%
% The possible choices for rank_projection are:
% 'svd' = singular value decomposition is applied to the full matrix, all
% the singular vectors are computed and then the singular vectors
% corresponding to the 3 largest singular values are extracted; this
% solution is expensive for large datasets
% 'svds' = singular value decomposition is applied to the sparse matrix,
% the singular vectors corresponding to the 3 largest singular values are
% computed only
% 'brp' = bilateral random projections are used (RECOMMENDED)
%
% OUTPUT:
% L = low-rank part
% S = sparse part (representing the outliers in the data matrix and the
% completion of the missing entries)
% status = reason for exiting
%
% Author: Federica Arrigoni, Beatrice Rossi, 2015
%
% References: 
% "Robust absolute toration estimation via low-rank and sparse matrix
% decomposition ", F. Arrigoni, L. Magri, B. Rossi, P. Fragneto, A.
% Fusiello, 3DV 2014
% 
% "Robust Synchronization in SO(3) and SE(3) via Low-rank & Sparse
% Matrix Decomposition", F. Arrigoni, B. Rossi, P. Fragneto, A. Fusiello 
% CVIU 2018


% iteration parameters
error_bound=1e-3; % accuracy threshold

if nargin < 6
    tol = 1e-5;
end

if nargin < 5
    iter_max = 100;
end

if nargin < 4
    error('insufficient arguments')
end

[m,n]=size(L); % matrix size
if m<n
    L=L';
end

% initialization of L and S
S=sparse(zeros(size(L)));
omega=logical(spones(L)); % sampling set

ncams=n/rank_input; % number of cameras

% Modify the sampling set: the identity blocks along the diagonal are known
% even if they have zero entries
omega = (omega | logical(blockexpand( eye(ncams),rank_input)));


if rank_input==4 % SE(3)
    omega=omega|kron(ones(ncams),[0 0 0 0;0 0 0 0;0 0 0 0;1 1 1 0]);
    omega=omega|kron(eye(ncams),ones(4));
end


prev_err = inf;

for iter=1:iter_max
    
    %  --- Update of L with BRP
    
    if iter==1 && rank_input==3 
        [U,Sigma,V]=svds(L,3);
        L_new=U*Sigma*V';
    else
        Y2=randn(n,rank_input);
        for i=1:power+1
            Y1 = L * Y2;
            Y2 = L'*Y1;
        end
        [Q,~]=qr(Y2,0);
        L_new=(L*Q)*Q';    
    end


    % --- Update of S
    
    T = L - L_new + S; % residual matrix
    L = L_new;
    
    T_omega = full(T .* omega);
    
    An = tau./sqrt(blocksum(T_omega.^2,rank_input));
    
    S =  T_omega .* ( bsxfun(@max, blockexpand( 1-An, rank_input ), 0 ) -1 ) + T;
    
    % --- Error, stopping criteria
    
    
    T = T - S;
    err = norm(T, 1);
    

    if (err < error_bound) || ((abs(prev_err - err)/err < tol) && iter > 30)
        break;
    end
    
    L=L+T;
    prev_err = err;
    
    
    
end


if m<n
    L=L';
    S=S';
end


% set reason for exiting
if iter==iter_max
    status = 2;
elseif (err < error_bound)
    status = 1;
    %disp(iter);
else
    status = 0;
    %disp(iter);
end



end