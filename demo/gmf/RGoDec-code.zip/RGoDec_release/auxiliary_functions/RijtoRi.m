

function R = RijtoRi(G,ncams,k)

% Projection onto SO(3)
R = zeros(3,3,ncams);


for i=1:ncams
    
    [u, ~,v]=svd(G(3*i-2:3*i,3*k-2:3*k));
    % compute the nearest rotation matrix
    R(:,:,i)=u*diag([1,1,det(u*v')])*v';
end

end