function X = blocksum(A,sublen)

% It sums the blocks of order "sublen"
% The dimensions of the input matrix A must be multiple of sublen

X = squeeze(sum(reshape(sum(reshape(A,sublen,[])),size(A,1)/sublen,sublen,[]),2));