function B = blockexpand(A,n)

% Expand a matrix into blocks
% It is equivalet to kron(A,ones(n)), but it is faster
 
idx = cumsum(ones(n,length(A)),2); 
B = A(idx,idx);
end

