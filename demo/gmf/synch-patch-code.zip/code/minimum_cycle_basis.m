

function [basis,v_basis,index_basis] = minimum_cycle_basis(A,verbose)
%
% [basis,v_basis,index_basis] = minimum_cycle_basis(A)
% This function computes a Minimum Cycle Basis (also known as Shortest
% Cycle Basis) of an undirected graph using Horton's algorithm.
% The execution time is O(nV*nE^3), where nV is the number of vertices
% (nodes) of the graph and nE is the number of edges.
% It is assumed that the underlying graph is biconnected.
%
% Rerefence:
% J. D. Horton. A polynomial-time algorithm to find the shortest cycle
% basis of a graph. SIAM journal on computing, 16(2), pages 358-366, 1987.
%
% Authors: Federica Arrigoni, Beatrice Rossi, Andrea Fusiello, 2015
%
% INPUT:
% A is the nV x nV (symmetric) adjacency matrix associated to a biconnected
% graph: A(i,j)=1 if the edge (i,j) appears in the graph, A(i,j) = 0
% otherwise.
%
% OUTPUT:
% basis is a 1 x nE-nV+1 cell which contains a minimum cycle basis, i.e.
% basis{i} contains the i-th cycle of the basis stored as a closed path,
% e.g. the cycle {(l,j), (j,k), (k,l)} is stored as [l,j,k,l].
%
% v_basis is a nE-nV+1 x nE matrix which contains the cycle basis for the
% graph viewed as a vector space, i.e. v_basis(i,:) is the signed indicator
% vector associated to the i-th cycle.
%
% index_basis is a 1 x nE-nV+1 cell which contains the nonzero indices of
% each cycle in the basis, i.e. index_basis{i} contains the nonzero indices
% of the edges of the i-th cycle viewed as a vector in GF(2)^nE.
% To explicitly build this (unsigned) vector, use the command
% sparse(index_basis{i},1,1,nE,1).
%

if isempty(verbose)
    verbose=true;
end

% check if A is biconnected
if ~isempty(biconnected_components(sparse(A))) % if there are articulation points...
    error('The graph is not biconnected!')
end

% Consider the lower-triangular adjacency matrix, i.e. the edges (i,j) and
% (j,i) are considered as a single edge.
A = sparse(tril(A,-1));

nV=size(A,1); % number of vertices/nodes of the graph
nE=nnz(A); % number of edges

if verbose
    fprintf('\nDimension of the basis = %d\n',nE-nV+1)
end

% STEP 0: Use perturbation techniques to guarantee uniqueness of shortest
% paths.
% Note: This step is necessary if A has negative entries

% sigma=randperm(nE); % arbitrary permutation of the edges
% epsilon=2.^(sigma-nE-1); % perturbation of the edges
% [I,J,S]=find(A);
% % Increase the length of any edge by epsilon.
% A=sparse(I,J,S+epsilon',nV,nV,nE);


% STEP 1: Find the shortest path P{x,y} between each pair of vertices x,y.

if verbose
    fprintf('Computing shortest paths...\n')
end

P = cell(nV,nV); % Initialize the shortest-paths matrix.

% Compute the predecessor and distance matrices using Floyd's algorithm.
% Paths(x,y) is the node preceding y on the path from x to y.
% D(x,y) indicates the shortest path distance between vertex x and y.
[D,Paths] = floyd_warshall_all_sp(A+A');
D=floor(D);

for x=1:nV
    for y=1:x-1
        
        path=zeros(1,D(x,y)+1);
        j=y;
        for k=1:D(x,y)+1
            path(k)=j;
            j=Paths(x,j);
        end
        
        P{y,x} = path;
        P{x,y}=fliplr(path);
    end
end


% STEP 2: For each vertex v and edge (x,y) in A create the cycle
% C(v,x,y)=P{v,x}+P{v,y}+(x,y) and calculate its length. Degenerate cases
% in which P{v,x} and P{v,y} have vertices other than v in common can be
% omitted. The maximum number of cycles generated in this way is nE*nV.

if verbose
    fprintf('Computing the candidate cycles...\n')
end

A(A~=0)=1; % eliminate weights
[X,Y]=find(A);

h=1;
C=cell(1,nE*nV); % cycles
C_length=zeros(1,nE*nV); % length of cycles

for v=1:nV
    for k=1:length(X)
        
        x=X(k); y=Y(k); % consider the edge (x,y)
        
        if x~=v && y~=v
            
            % Degenerate cases in which P{v,x} and P{v,y} have vertices
            % in common other than v are omitted
            index_degenerate=ismember(P{v,x},P{y,v});
            if sum(index_degenerate)<2
                
                % Note: the vertex v is contained twice in the cycle
                cycle=[P{v,x} P{y,v}];
                C{h}=cycle;
                C_length(h)=length(cycle)-1; % length of the cycle
                h=h+1;
            end
        end
    end
end
C_length=C_length(1:h-1);
C=C(1:h-1);


% STEP 3: order the cycles by increasing lengths

[~,index_sort] = sort(C_length);
C=C(index_sort);


% STEP 4: Add to an initial empty basis the next shortest cycle if it is
% independent from the already selected ones.
% This step is implemented by applying Gaussian elimination to a
% 0,1-matrix whose rows are the vectors corresponding to the cycles
% generated in Step 3.

% Initialize the basis.
basis=cell(1,nE-nV+1);
v_basis=zeros(nE-nV+1,nE);
index_basis=cell(1,nE-nV+1);

cycle=C{1}; % current cycle
[v_cycle,v_index]=cycle2vector(cycle,A,nE); % vector representation

% Add the cycle to the basis.
basis{1}=cycle;
v_basis(1,:)=v_cycle;
index_basis{1}=v_index;

if verbose
    fprintf('Testing linear independence...\n')
end

l=2; % number of analyzed cycles
k=2; % number of cycles included in the basis
p=[];
B=false(0); % empty logical
[B,p] = gaussZ2(B,p,logical(v_cycle));

while l<=length(C) && k<=nE-nV+1
    
    cycle=C{l}; % current cycle
    [v_cycle,v_index]=cycle2vector(cycle,A,nE); % vector representation
    
    % apply Gaussian elimination
    [B,p,check] = gaussZ2(B,p,logical(v_cycle));
    %[B,p,check] = gaussZ2_mex(B,p,abs(v_cycle'));
    
    if check
        % the current cycle is independent from the already selected ones
        basis{k}=cycle;
        v_basis(k,:)=v_cycle;
        index_basis{k}=v_index;
        k=k+1;
    end
    
    l=l+1;
end

if verbose
    fprintf('Minimum cycle basis computed!\n')
end

end





function [B,p,check] = gaussZ2(B,p,r)
% This function applies Gaussian elimination in GF(2) to the matrix B and
% the row-vector r. p denotes the vector of pivot elements which
% represents the indices of the first non-zero entry in each row of B.
% It is supposed that Gaussian elimination has been already applied to the
% input matrix B, thus its rows are independent and ordered basing on
% their pivots.
%
% If r is dependent from the rows in B, then the output
% matrix B coincides with the original one, and the same holds for the
% pivot vector.
% If r is independent from the rows in B, then B is updated adding r in the
% suitable position according to its pivot. Also the pivot vector is
% updated adding the pivot of r in the suitable position.
%
% check = true if the row r is independent from the rows contained in B
% check = false otherwise
%

if isempty(B)
    B=r;
    check=true;
    p=find(r,1,'first');
    return
end

while true
    
    % calculate the new pivot
    pr=find(r,1,'first');

    if isempty(pr)
        break;
    end
    
    % find a row with the same pivot of r
    row=find(p==pr,1,'first');
        
    if isempty(row)
        break;
    end
    
    % substitute to r the sum of r and a row with the same pivot
    r=xor(r,B(:,row));
    
end


if isempty(pr)
    % after the previous linear combinations, r is the zero vector (i.e. it
    % is dependent from the other rows in B)
    check=false;
else
    % r is independent from the other rows in B
    check=true;
    
    % order the pivot elements
    p=[p pr];
    [p,index]=sort(p);
    
    % insert r to the right position according to its pivot
    B=[B,r];
    B=B(:,index);
end

end




