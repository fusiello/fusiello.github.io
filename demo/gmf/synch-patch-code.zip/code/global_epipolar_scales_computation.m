function [scales,U,F]=global_epipolar_scales_computation(U,W,C)
%
% [scales,U,F]=global_epipolar_scales_computation(U,A,C)
% This function computes the unknown norms - also referred to as epipolar
% scales - of the baselines joining the optical centres of the cameras.
% The baseline directions, contained in U as columns are already expressed
% in a common rotational reference frame, namely the absolute rotations
% have been already computed. 
% The reference structure is the epipolar graph encoded by A, where nodes 
% are the images and edges correspond to epipolar relationships between
% them.
% Let nV be the number of cameras and nE be the number of edges.
%
% INPUT:
% A is the nV x nV (symmetric) adjacency matrix associated to the epipolar
% graph: A(i,j)=1 if the relative motion between view i and j is available,
% A(i,j)=0 otherwise.
%
% U is the 3 x nE block-matrix containing the baseline directions as columns,
% in the same order as the edges in B
%
% C is a nE-nV+1 x nE matrix which contains a cycle basis for the
% epipolar graph viewed as a vector space, i.e. C(i,:) is the signed
% indicator vector associated to the i-th cycle in the basis.
%
% OUTPUT:
% scales is a nE-vector which contains the epipolar scales. The edges are
% ordered using Matlab's convention on sparse matrices.
%
% U is updated so as to contain information about the epipolar scales: the
% baseline direction b(k) in the k-th column of U is substituted with
% b(k)*scales(k).
%
% % F is a matrix with the same dimentions as A containing the scales: the
% k-th scale is placed at the entry (i,j) of if k is the index associated
% to the edge (i,j). 


% Rerefence:
% F. Arrigoni, A. Fusiello, B. Rossi. On Computing the Translations Norm in
% the Epipolar Graph. International Conference on 3D Vision, 2015.
%
% Authors: Federica Arrigoni, Beatrice Rossi, Andrea Fusiello, 2016
%

% Compute the coefficient matrix of the linear system
CU = kr(C,U);

%nC = size(C,1);
%D = kron(spdiags(1./sqrt(sum(abs(C),2)),0,nC,nC), eye(3));
% D = spones(D);

% Compute the epipolar scales (up to a global scale)

try
L = CU'*CU ; [scales,d] = eigs(L,2,eps);
scales = scales(:,2).*sign(scales(1,2));
catch
  scales  = 0;  
  disp('Epipolar scales failed because of the EIGS bug')
end


% come calcolo del rango, se  d(1,1)<tol la nullity � almeno 2
% tol = max(size(L)) * eps(eigs(L,1));
tol = max(size(L)) * eps(max(L(:))) ;
if  d(1,1) < tol  || any(abs(scales) < 1e-18  )
    % mette a nan i fattori; in uscita bisogna controllare
    scales = nan(size(scales));
end

% Update the baselines
U = kr(scales',U);

[I,J]=find(tril(W,-1));
F=sparse([I;J],[J;I],[scales;scales]);

end







