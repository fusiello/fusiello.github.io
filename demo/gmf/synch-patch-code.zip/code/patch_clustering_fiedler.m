function patches = patch_clustering_fiedler(W, opts )
% cams_cluster = patch_clustering_fieldler(W,opts) cover the graph
% represented by W with overlapping subgraphs called patches
%
% INPUT
% W = (nV x nV) Weighted adjacency matrix
% 
% OUTPUT
% patches = cell array, every cell is an arry containing the indices
% of the cameras belonging to that patch; the size is the number of patches
%

% Algorithm: fiedler partitioning with some post-processing
% Author: Federica Arrigoni and Andrea Fusiello, 2016

global debug;

ncams = size(W,1);
%[I,J]=find(tril(W,-1));

patch_size= floor(opts.max_size_coefficient*sqrt(ncams))
not_bigger_than  = floor(patch_size*1.2);

% Apply fiedler con rigidity
patches = spectral_fiedler(W,1:size(W,1),cell(0));
patches = patches';
% save A A

% i patch sono tutti parallel rigidi, di almeno 3 camere
% le camere dei patch <= opts.cut_size e non rigidi sono mancanti
if debug
    At=spones(W);
    for k=1:length(patches)
        A_patch{k}=At(patches{k},:);
        A_patch{k}=A_patch{k}(:,patches{k});
        assert(ParallelRigidityTest(A_patch{k},3) )
        assert(length(patches{k}) >=3)
    end
end

%         % remove small patchs
%         for k=1:length(cams_patch)
%             if   length(cams_patch{k}) <= 3
%                 cams_patch{k}=[];
%             end
%         end

%remove empty patchs
patches = patches(~cellfun('isempty',patches)) ;

% unpatchized nodes can be adopted by other patchs provided
% they are trilaterizable
A_patch=cell(length(patches),1);
for grado=[10,5,3,3,2,2,2] % ripete l'adozione per tot volte; deve terminare a 2
    
    for k=1:length(patches)
        
        chosen = sort(unique(cell2mat(patches)));
        left_out = setdiff(1:ncams,chosen); % quelle scartate, da riattaccare
        
        if isempty(left_out) break; end
        
        % crea un grafo come A ma togli gli edge incidenti sulle camere che
        % non sono nel patch corrente, esclusi i left-out
        At=spones(W); 
        altri = setdiff(1:ncams,  union(patches{k},left_out));
        At(altri,:) = 0;  At(:,altri) = 0;
        At(left_out,left_out) = 0;
        
        adottabili1 = intersect(left_out, find(sum(At)>=grado)) ;
        
        if length(patches{k}) < not_bigger_than
            how_many = min(length(adottabili1),  not_bigger_than - length(patches{k}));
            patches{k} = union(patches{k}, adottabili1(1:how_many));
            
        end
    end
    if debug
        fprintf('\t Adoption: %d cameras are missing \n', length(left_out))
    end
end


if opts.recovery
    % raccoglie rimasugli finche' ne rimangono abbastanza da fare un
    % patch
    
    for iter =1:5 %ci prova per un certo nunero di volte
        
        chosen = sort(unique(cell2mat(patches)));
        left_out = setdiff(1:ncams,chosen); % quelle scartate, da riattaccare
        
        if length(left_out) <=  not_bigger_than break; end
        
        if debug
            fprintf('\t Recovery: %d cameras are missing \n', length(left_out))
        end
        
        k = 1+length(patches)   ;
        
        patches{k} = left_out(1:not_bigger_than)';
        
        % extract the adjacency matrix of the k-th patch
        A_patch{k}=W(patches{k},:);
        A_patch{k}=A_patch{k}(:,patches{k});
        
        [good_ones,~] = LargestMaxParRigComp(A_patch{k},3); % images that survive
        if debug
            fprintf('\t Recovery: rigid component of patch %d has size %d\n', k, length(good_ones));
        end
        patches{k}=patches{k}(good_ones);
        
    end
    
end


% determina le camere ponte con cui espandere,
% ne prende 3 per patch perche' 3 e' la dim. minima
gradi = sum(W); % pesato
bridge_nodes = [];
for k=1:length(patches)
    % ordina per grado
    [~,ordine] = sort(gradi(patches{k}),'descend');
    patches{k} = patches{k}(ordine);
    how_many = min(5,length(patches{k}));
    bridge_nodes =  union(patches{k}(1:how_many),bridge_nodes);
end


% adozione di camere gia' presenti, per creare overlap
for grado=[5,3,2,2] %  deve terminare a 2
    
    if debug
        all_cam = cell2mat(patches);
        [freq,~]=hist(all_cam,unique(all_cam));
        fprintf('\t Augmenting: overlap = %d \n', sum(freq > 1))
    end
    
    for k=1:length(patches)
        
        % crea un grafo come A ma togli gli edge incidenti sulle camere che
        % non sono nel patch corrente, esclusi i left-out
        At=spones(W); 
        correnti = union(patches{k},bridge_nodes);
        altri = setdiff(1:ncams, correnti);
        At(altri,:) = 0;  At(:,altri) = 0;
        At(bridge_nodes,bridge_nodes) = 0;
        
        adottabili2 = intersect(bridge_nodes, find(sum(At)>=grado)) ;
        %adottabili2  = find(sum(At(correnti, correnti))  >=grado);
        
        if ~isempty(adottabili2) && length(patches{k}) < not_bigger_than
            how_many = min(length(adottabili2),  not_bigger_than - length(patches{k}));
            patches{k} = union(patches{k}, adottabili2(1:how_many));
            %fprintf('\t Augmenting patch %d to size %d\n', k,  length(cams_patch{k}));
            
        end
    end
end

if debug
    At=spones(W);
    for k=1:length(patches)
        A_patch{k}=At(patches{k},:);
        A_patch{k}=A_patch{k}(:,patches{k});
        assert(ParallelRigidityTest(A_patch{k},3) )
        assert(length(patches{k}) >=3)
    end
end


% nested  function!
    function clusters = spectral_fiedler(A,S,clusters)
        
        A(logical(eye(size(A)))) = 0;
        I0 = 1:size(A,1);
        
        if length(clusters) > 1000 % DA SISTEMARE
            %disp('abbandono patching')
            return
        end
        
        if  length(I0) < patch_size  && ParallelRigidityTest(A(I0,I0),3)
            % foglia da stampare
            clusters{end+1} = S(I0)';
            
        elseif length(I0) > opts.cut_size
            % partiziona solo se abbastanza grande; le camere nei custer
            % troppo piccoli sono perse
            
            L = diag(sum(A))-A + 100*eps*speye(size(A)); % Laplaciano
            options.v0 = ones(size(A,1),1);
            [V,~] = eigs(L,2,'sm',options); % deterministico
            w = real(V(:,1))./norm(V(:,1));
            I1 = find(w>=0 - 1e-3);
            I2 = find(w<=0 + 1e-3);
            
            if isempty(setdiff(I0,I1)) || isempty(setdiff(I0,I2))
                % median partitioning
                [~,foo] = sort(w);
                I1 =foo(1:ceil(length(w)/2));
                I2 =foo(floor(length(w)/2):end);
                
                % w = w -median(w);
                % I1 = find(w>=0) ;
                % I2 = find(w<0);
            end
            
            %             % leave one out partitioning
            %             if isempty(I1)
            %                 [~,I1] = max(w);
            %                 I2 = setdiff(1:length(w), I1);
            %             end
            %
            %             if isempty(I2)
            %                 [~,I2] = min(w);
            %                 I1 = setdiff(1:length(w), I2);
            %             end
            
            
            
            clusters = spectral_fiedler(A(I1,I1),S(I1),clusters);
            clusters = spectral_fiedler(A(I2,I2),S(I2),clusters);
        end
    end
end
