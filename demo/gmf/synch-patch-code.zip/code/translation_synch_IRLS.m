function [T,W] = translation_synch_IRLS(U,W,opts)
% [T,W] = translation_synch_IRLS(U,W,opts)
% Translation sinchrnonization.
% Resistance to outliers is obtained by IRLS.
%
% OUTPUT
% T = Translations of the cameras (3 x nV)
% W = Weighted adjacency matrix (final)
%
% INPUT
% U is the 3 x nE matrix containing the baseline (with scale) as columns,
% in the same order as the edges in the incidence matrix (see adj2inc)
% W = Weighted adjacency matrix (initial)

% Author: Federica Arrigoni and Andrea Fusiello, 2016

h=opts.ht;

ncams=size(W,1);
B = adj2inc(W);
nedges=size(B,2);

F=kron(B',speye(3));
F(:,1:3)=[];
%T=F\y;

k=1;
deltaW=2*opts.tol;

[~,~,weights]=find(tril(W,-1));
Wk=kron(spdiags(weights,0,nedges,nedges),speye(3));
W_old = Wk;

while k<=opts.max_irls_iter && deltaW>opts.tol
    T=(sqrt(Wk)*F)\(sqrt(Wk)*U(:));
    Wk=update_weights(T,F,U(:),opts.weight_function,h,nedges);
    deltaW = norm(W_old -Wk,'fro')/(norm(Wk,'fro')*ncams);
    W_old = Wk;
    k=k+1;
end

if opts.use_bisquare
    % ultimo passo con hard redescender
    Wk=update_weights(T,F,U(:),'bisquare',h,nedges);
end

[I,J]=find(tril(W,-1));
weights = min(reshape(diag(Wk),3,nedges))';
W=sparse([I;J;(1:ncams)'],[J;I;(1:ncams)'],[weights;weights;max(weights)*ones(ncams,1)],ncams,ncams);

T=[0;0;0;T];
T=reshape(T,3,ncams);
end

function  Wk = update_weights(T,F,y,weight_fun,h,nedges)

res=F*T-y;
weights = weightfun(res,mad(res(:),1)/0.6745,weight_fun,h);
Wk=spdiags(weights,0,3*nedges,3*nedges);

end





