function r = compute_angular_residual(R, G)
% r = compute_angular_residual(R, G) compute residuals of rotation synch
% 
% INPUT
% R = absolute rotation matrices of the cameras (3 x 3 x nV)
% G = block-matrix containing the relative rotations (3*nV x 3*nV)
%
% OUTPUT
% 
% r = (nV x NV) matrix containing the angular error (in rad) of the
% synchronization problem with input G and output R for each relative
% rotation in G

ncams = size(G,1)/3;

% matrice di adiacenza del grafo
% la ottengo "strizzando" la G, sommando i suoi blocchi 3x3
D = repelem(speye(ncams),1,3);
A = spones((D*G*D'));

% R_matrix=reshape(permute(R,[1,3,2]),[],3);
% temp=reshape( sparse( G-(R_matrix*R_matrix').*kron(A,ones(3)) ),3,3*ncams^2);
% temp=reshape(sum(temp.^2),ncams,3*ncams);
% temp=reshape(temp',3,ncams^2);
% temp=reshape(sqrt(sum(temp)),ncams,ncams)'; % frobenius norm of each 3x3 block
% temp= 2*asin(temp./(2*sqrt(2))); % erore angolare in radianti

R=reshape(permute(R,[1,3,2]),[],3);
T_omega = ( (G - (R*R').*repelem(A,3,3)).^2);
B0 = repelem(speye(ncams),1,3);
r = sqrt(B0*T_omega*B0');
r = 2*asin(r./(2*sqrt(2))); % erore angolare in radianti

end