
function [v_cycle,v_index]=cycle2vector(cycle,A,nE)
%
% [v_cycle,v_index]=cycle2vector(cycle,A,nE)
% This function associates to a cycle in a graph a vector in GF(2)^nE,
% where nE is the number of edges in the graph.
% 
% Authors: Federica Arrigoni, Beatrice Rossi, Andrea Fusiello, 2015
%
% INPUT:
% A is the nv x nv (symmetric) adjacency matrix associated to a graph:
% A(i,j)=1 if the edge (i,j) appears in the graph, A(i,j) = 0 otherwise.
%
% nE is the number of edges in the graph
%
% cycle is a cycle in the graph stored as a closed path, e.g. the cycle
% {(i,j), (j,k), (k,i)} is stored as [i,j,k,i]. 
%
% OUTPUT:
% v_cycle is a nE-vector representing the signed indicator vector
% associated to the cycle.  
%
% v_index is a vector containing the nonzero indices of the edges of the
% cycle viewed as a vector in GF(2)^nE. To explicitly build this (unsigned)
% vector, use the command sparse(index_basis{i},1,1,nE,1).
%


% initialization
v_cycle=zeros(nE,1);
v_index=zeros(length(cycle)-1,1);

for c=1:length(cycle)-1
%for c=1:length(cycle)-1
    
    i=cycle(c); j=cycle(c+1); % (i,j) is the c-th edge in the cycle
    k=index_edge(i,j,A);
    
    % compute the index corresponding to the edge (i,j)
    v_index(c)=k;
    
    % put 1 or -1 in the right position
    v_cycle(k) = 1.*(i>j)-1.*(i<j);
end

v_cycle=sparse(v_cycle);


end

