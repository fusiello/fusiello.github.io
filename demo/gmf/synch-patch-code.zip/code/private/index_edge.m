
function [ind] = index_edge (i,j,A)
%
% [ind] = index_edge(i,j,A)
% This function associates to the edge (i,j) in the adjacency matrix A a
% unique value from 1 to nE, where nE is the number of edges in the graph.
% Specifically, the edges are ordered using Matlab's convention on sparse
% matrices.
% 
% Authors: Federica Arrigoni, Beatrice Rossi, Andrea Fusiello, 2015
%
% INPUT:
% A is the nv x nv (symmetric) adjacency matrix associated to a graph:
% A(i,j)=1 if the edge (i,j) appears in the graph, A(i,j) = 0 otherwise.
%
% i and j are the left and right endpoints of an edge in the graph.
%
% OUTPUT:
% ind is a unique value from 1 and nE associated to the given edge.
%


% Consider the lower-triangular adjacency matrix, i.e. the edges (i,j) and
% (j,i) are considered as a single edge.
A=tril(A,-1);
[I,J]=find(A);

% Invert i and j if j>i
if j>i
    temp=j;
    j=i;
    i=temp;
end

% Find the index corresponding to the given edge
[~,ind]=ismember([i,j],[I,J],'rows');


end





