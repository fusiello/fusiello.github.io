function [R,W] = rotation_synch_IRLS(G,W,opts)
% [R,W] = rotation_synch_IRLS(G,W)
% The absolute rotations of the cameras are computed by using Eigenvalue
% Decomposition (rotation averagning in SO(3)).
% Resistance to outliers is obtained by IRLS.
%
% OUTPUT
% R = absolute rotation matrices of the cameras (3 x 3 x nV)
% W = Weighted adjacency matrix (final)
%
% INPUT
% G = block-matrix containing the relative rotations (3*nV x 3*nV)
% W = Weighted adjacency matrix (initial)

% Inspired  the "eigenvalue" approach in SO(3) by Arie-Nachimson et al.
% Reference: "Global Motion Estimation from Point Matches", 2012
% Author: Federica Arrigoni, 2013
%
% Author: Federica Arrigoni and Andrea Fusiello, 2016

n = size(W,1);
A = spones(W);
R = zeros(3,3,n);

k=1;
deltaW=2*opts.tol;
W_old = W;

while (k <= opts.max_irls_iter) && (deltaW > opts.tol)
    
    D = kron(spdiags(1./sum(W,2),0,n,n),speye(3));
    [M,~]=eigs(D*G.*repelem(W,3,3),3);
    
    % Projection onto SO(3)
    for i=1:n
        [U,~,V] = svd(M(3*i-2:3*i,:));
        R(:,:,i)=U*V'; % nearest rotation matrix
        R(:,:,i) = det(R(:,:,i)) * R(:,:,i); 
    end
    
    W=update_weights_SO3(G,R,A,opts.weight_function,opts.hr,opts.use_mex);
    deltaW = norm(W_old-W,'fro')/(norm(W,'fro')*n);
    W_old = W;
    k=k+1;
    
end
%R = rotation_synch_EIG(G,W);

if opts.use_bisquare
   % ultimo passo con hard redescender (bisquare)
    W=update_weights_SO3(G,R,A,'bisquare',opts.hr,opts.use_mex);
end

end


function W=update_weights_SO3(G,R,A,weight_fun,h,use_mex)

n=size(A,1);
[I,J]=find(triu(A,1));

if use_mex
    [res]=residuals_EIG_SO3_mex(I,J,full(G),R);
else
    R=reshape(permute(R,[1,3,2]),[],3);
    T_omega = ( (G - (R*R').*repelem(A,3,3)).^2);
    B0 = repelem(speye(n),1,3);
    blknorm = sqrt(B0*T_omega*B0');
    % blknorm contains the Frobenius norm of each block in T_omega
    [~,~,res]=find(triu(blknorm,1));
end

weights = weightfun(res,mad(res(:),1)/0.6745,weight_fun,h);

W=sparse([I;J;(1:n)'],[J;I;(1:n)'],[weights;weights;max(weights)*ones(n,1)],n,n);

end



