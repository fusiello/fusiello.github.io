function T = translation_synch_LS(U,W)
% [T,W] = translation_synch_IRLS(U,W,opts)
% Translation sinchronization as weighted LS.
%
% OUTPUT
% T = Translations of the cameras (3 x nV)
%
% INPUT
% U is the 3 x nE matrix containing the baseline (with scale) as columns,
% in the same order as the edges in the incidence matrix (see adj2inc)
% W = Weighted adjacency matrix 

% Author: Federica Arrigoni and Andrea Fusiello, 2016

ncams=size(W,1);

B = adj2inc(W);
nedges=size(B,2);

[~,~,weights]=find(tril(W,-1));
Wk=kron(spdiags(weights,0,nedges,nedges),speye(3));

F=kron(B',speye(3));
F(:,1:3)=[];
%T=F\y;
T=(sqrt(Wk)*F)\(sqrt(Wk)*U(:));

T=[0;0;0;T];
T=reshape(T,3,ncams);

end
