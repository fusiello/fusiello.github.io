
function [S,W]=scale_synch_IRLS(X,W,opts)
% [S,W] = translation_synch_IRLS(U,W,opts)
% Scale sinchrnonization.
% Resistance to outliers is obtained by IRLS.
%
% Let nV be the number of nodes and nE be the number of edges.
%
% OUTPUT
% S = Scales of the nodes (nV x 1)
% W = Weighted adjacency matrix (final)
%
% INPUT
% X = (nV x nV) measurement meatrix containing the ratios of scales (one
% for each edge)
% W = Weighted adjacency matrix (initial)

% Author: Federica Arrigoni and Andrea Fusiello, 2016

h=1; 
n=size(W,1);
A = spones(W);

k=1;
deltaW=2*opts.tol;
W_old = W;

while k<=opts.max_irls_iter && deltaW>opts.tol
    
    % Compute the leading eigenvector of D*G
    D = diag(1./sum(W,2));
    [S,~]=eigs(D*(X.*W),1);
    S=real(S);
    S=S*sign(S(1));
    
    W=update_weights(X,S,A,opts.weight_function,h);
    
    deltaW = norm(W_old -W,'fro')/(norm(W,'fro')*n);
    W_old = W;
    
    k=k+1;
    
end

end


function [D]=update_weights(X,S,A,weight_fun,h)

ncams=size(A,1);
[I,J]=find(triu(A,1));

temp=abs(X-(S*S'.^(-1)).*A);
res  = temp(triu(A,1)>0);

weights = weightfun(res,mad(res(:),1)/0.6745,weight_fun,h);
D=sparse([I;J;(1:ncams)'],[J;I;(1:ncams)'],[weights;weights;max(weights)*ones(ncams,1)],ncams,ncams);

end
