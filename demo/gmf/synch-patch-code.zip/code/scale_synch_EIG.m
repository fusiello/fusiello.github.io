function [S]=scale_synch_EIG(X,A)
% S = translation_synch_LS(U,W,opts)
% Scale sinchrnonization as an eigenvalue problem
%
% Let nV be the number of nodes and nE be the number of edges.
%
% OUTPUT
% S = Scales of the nodes (nV x 1)
%
% INPUT
% X = (nV x nV) measurement meatrix containing the ratios of scales (one
% for each edge)
% W = Weighted adjacency matrix (initial)

% Author: Federica Arrigoni and Andrea Fusiello, 2016

% D(i,i) = number of relative measurements available in the i-th row-block
D = diag(1./sum(A,2));

% Compute the leading eigenvector of D*G 
% REMARK: the eigenvalues are real since G is symmetric
[S,~]=eigs(D*X,1); 
S=real(S);
S=S*sign(S(1));

end

