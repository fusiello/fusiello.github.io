
function cams_cluster = patch_clustering_spectral(W,opts)
% cams_cluster = patch_clustering_spectral(W,opts) cover the graph
% represented by W with overlapping subgraphs called patches
%
% INPUT
% W = (nV x nV) Weighted adjacency matrix
% 
% OUTPUT
% cams_cluster = cell array, every cell is an arry containing the indices
% of the cameras belonging to that patch; the size is the number of patches
%

% Algorithm: spectral clustering with post-processing to make the clusters
% overlapping
%
% Author: Federica Arrigoni and Andrea Fusiello, 2016

% Parameters:
% min_size = average size of each cluster after spectral clustering is run
% max_size = maximum size of each cluster
% initial_datum=true -> kmean is initialized using the cameras with highest degree
% initial_datum=false -> kmeans is initialized at random, using 100 replicates
% create_cluster_removed=true -> create a cluster containing all removed cameras
% create_cluster_removed=false -> do not create a cluster containing all removed cameras
% min_legs = minimum number of legs of new cameras that are added during
% the dilation of each cluster


global debug;

initial_datum = opts.initial_datum;
min_legs = opts.min_legs;

A = spones(W);
B = adj2inc(A);

ncams=size(A,1);

max_size= floor(opts.max_size_coefficient*sqrt(ncams));
min_size= floor(max_size/2);

[I,J]=find(tril(A,-1));

ngroups=ceil(ncams/min_size); % number of clusters
groups = SpectralClustering_modified(W,ngroups,initial_datum); % Apply spectral clustering
%groups = SpectralClustering_modified(A,ngroups,initial_datum); % Apply spectral clustering


%% initialize parameters

% initialize parameters of each cluster
ncams_cluster=zeros(ngroups,1);
cams_cluster=cell(ngroups,1);
A_cluster=cell(ngroups,1);


%% Extract rigid components for each cluster
for k=1:ngroups
    
    % extract cameras of the k-th cluster
    cams_cluster{k}=find(groups==k); % images that belong to the k-th cluster
    ncams_cluster(k)=length(cams_cluster{k});
    
    % extract the adjacency matrix of the k-th cluster
    A_cluster{k}=A(cams_cluster{k},:);
    A_cluster{k}=A_cluster{k}(:,cams_cluster{k});
    
    % extract rigid components
    %rigidityDec = ParallelRigidityTest(A_cluster{k},3);
    rigidityDec=0 ; % bypass the test to speed up
    
    if rigidityDec==1
        %fprintf('Thecluster is solvable!\n')
    else
        %disp('The cluster is not solvable, the largest solvable component is extracted')
        
        [index_images_cluster,~] = LargestMaxParRigComp(A_cluster{k},3); % images that survive
        index_cluster=setdiff(1:ncams_cluster(k),index_images_cluster); % images that are eliminated
        
        % update A
        A_cluster{k}(index_cluster,:)=[];
        A_cluster{k}(:,index_cluster)=[];
        
        % update cams, ncams
        ncams_cluster(k)=length(index_images_cluster);
        cams_cluster{k}=cams_cluster{k}(index_images_cluster);
        
    end
    
    if debug
    fprintf('\t Patch %d of size %d\n', k,  length(cams_cluster{k}));
    end
    
end


%% create a new cluster which contains removed cameras

if opts.recovery
    
    ngroups=ngroups+1;
    k=ngroups;
    
    estimated_cameras=sort(unique(cell2mat(cams_cluster)));
    cams_cluster{k}=setdiff(1:ncams,estimated_cameras)'; % images that are eliminated
    ncams_cluster(k)=length(cams_cluster{k});
    
    %disp(['Removed cameras = ',num2str(ncams_cluster(k))])
    
    A_cluster{k}=A(cams_cluster{k},:);
    A_cluster{k}=A_cluster{k}(:,cams_cluster{k});
    
    [index_images_cluster,~] = LargestMaxParRigComp(A_cluster{k},3); % images that survive
    index_cluster=setdiff(1:ncams_cluster(k),index_images_cluster); % images that are eliminated
    
    % update A
    A_cluster{k}(index_cluster,:)=[];
    A_cluster{k}(:,index_cluster)=[];
    
    % update cams, ncams
    ncams_cluster(k)=length(index_images_cluster);
    cams_cluster{k}=cams_cluster{k}(index_images_cluster);
    
    %disp(['After rigid components extraction = ',num2str(ncams_cluster(k))])
    
    if debug
        fprintf('\t Recovery: rigid component of the new patch has size %d\n',  ncams_cluster(k));
    end
    
end

% non voglio cluster vuoti
cams_cluster = cams_cluster(~cellfun('isempty',cams_cluster)) ;

%% Augment the clusters

estimated_cameras=sort(unique(cell2mat(cams_cluster)));
removed_cameras=setdiff(1:ncams,estimated_cameras)'; % images that are eliminated



if debug
    all_cam = cell2mat(cams_cluster);
    [freq,~]=hist(all_cam,unique(all_cam));
    fprintf('\t Augmenting: overlap = %d \n', sum(freq > 1))
end

% augment the cameras of the k-th cluster
for k=1:length(cams_cluster)    
    
    % augment the cameras of the k-th cluster
    D_cluster=B(cams_cluster{k},:); % incidence matrix
    index_augment=find(sum(D_cluster)~=0); % edges
    new_cameras=setdiff(unique([I(index_augment);J(index_augment)]) , cams_cluster{k}); % nodes
    
    n_legs=zeros(length(new_cameras),1);
    is_removed=zeros(length(new_cameras),1);
    for l=1:length(new_cameras)
        node=new_cameras(l);
        edges=find(B(node,:));
        n_legs(l)=nnz(sum( D_cluster(:,edges) ));
        
        if find(removed_cameras==node)
            is_removed(l)=1;
        end      
    end
    
    new_cameras(n_legs<min_legs)=[];
    is_removed(n_legs<min_legs)=[];
    n_legs(n_legs<min_legs)=[];
    
    new_removed=new_cameras(find(is_removed));
    new_cameras=new_cameras(find(~is_removed));
    
    % remove some cameras if the size of the augmented cluster exceeds the
    % maximum allowed size
    if length(new_cameras)>max_size-min_size
        % select the cameras with most edges
        [~,ind]=sort(n_legs(find(~is_removed)),'descend');
        new_cameras=new_cameras(ind(1:max_size-min_size));
    end
    
    if length(new_removed)>max_size-min_size+10
        [~,ind]=sort(n_legs(find(is_removed)),'descend');
        new_removed=new_removed(ind(1:max_size-min_size));
    end
    
    new_cameras=unique([new_cameras;new_removed]); % non serve
    
    % sort cameras
    cams_cluster{k}=sort([cams_cluster{k};new_cameras]);
    
    % number of cameras in the k-th cluster
    ncams_cluster(k)=length(cams_cluster{k});
    
    % extract the adjacency matrix of the k-th cluster
    A_cluster{k}=A(cams_cluster{k},:);
    A_cluster{k}=A_cluster{k}(:,cams_cluster{k});
    
end


if debug
    all_cam = cell2mat(cams_cluster);
    [freq,~]=hist(all_cam,unique(all_cam));
    fprintf('\t Augmenting: overlap = %d \n', sum(freq > 1))
end

% non voglio cluster vuoti
cams_cluster = cams_cluster(~cellfun('isempty',cams_cluster)) ;

% Verifica post-condizioni
if debug
    for k=1:length(cams_cluster)
        assert(ParallelRigidityTest(A_cluster{k},3) )
        assert(length(cams_cluster{k}) >=3)
    end
end


end


%--------------------------------------------------------------------------
% This function takes an adjacency matrix of a graph and computes the
% clustering of the nodes using the spectral clustering algorithm of
% Ng, Jordan and Weiss.
% CMat: NxN adjacency matrix
% n: number of groups for clustering
% groups: N-dimensional vector containing the memberships of the N points
% to the n groups obtained by spectral clustering
%--------------------------------------------------------------------------
% Copyright @ Ehsan Elhamifar, 2012
%--------------------------------------------------------------------------

function groups = SpectralClustering_modified(CKSym,n,initial_datum)

%warning off;
N = size(CKSym,1);
MAXiter = 1000; % Maximum number of iterations for KMeans

% Normalized spectral clustering according to Ng & Jordan & Weiss
% using Normalized Symmetric Laplacian L = I - D^{-1/2} W D^{-1/2}

DN = diag( 1./sqrt(sum(CKSym)+eps) );
LapN = speye(N) - DN * CKSym * DN;
%LapN = speye(N) - DN.^2 * CKSym;

%[uN,sN,vN] = svd(LapN);
[~,~,kerN] = svds(LapN,n);
for i = 1:N
    kerN(i,:) = kerN(i,:) ./ norm(kerN(i,:)+eps);
end


if initial_datum
    
    %[~,ind]=sort(sum(spones(CKSym)),'descend');
    [~,ind]=sort(sum(CKSym),'descend');
    X0=kerN(ind(1:n),:);
    groups = kmeans(kerN,n,'maxiter',MAXiter,'Start',X0,'EmptyAction','singleton','Distance','cityblock');
    
else
    REPlic = 100; % Number of replications for KMeans
    %groups = kmeans(kerN,n,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
    groups = kmeans(kerN,n,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton','Distance','cityblock','Options',statset('UseParallel',1));
end

%gscatter(kerNS(:,1),kerNS(:,2), groups)


end


