function [opts,R,T,W,index_images,out] = pipeline_synch(G,U,opts)
% Risolve global motion (R,T) da grafo epipolare X
% opts.patchwork controlla se il calcolo delle scale viene fatto su patches e
% poi riassemblato oppure direttamente sul grafo piu`grande

% input: matrixe G (3n x 3n) con rotazioni pairwise (grafo epipolare)
% input: matrixe U (3 x nE)  con traslazioni relative (up to scale)
%
% output: matrixe R (3 x 3 x n)  delle rotazioni assolute
% output: matrixe T (3 x n)  delle traslazioni assolute
% output: matrixe W (n x n)  dei pesi finali del grafo epipolare
% output: index_images: vettore con indici delle camere sopravvissute
% output: struttura out con varie informazioni diagnostiche (p.es. tempi)

global debug;

if nargout ==1; opts = options(); return;
end

if nargin == 1; opts = options(); disp(opts);
end

if rem(size(G,1),3)
    error('G must have size multiple of 3')
end

ncams = size(G,1)/3;

% matrice A (n x n) di adiacenza del grafo
% la ottengo "strizzando" la X, sommando i suoi blocchi 4x4
D = repelem(speye(ncams),1,3);
W = spones((D*G*D')); % adiacenza senza pesi, all'inizio

%% this is the global image index
index_images=1:ncams;

%% %%%%%%%%%%%%%%%%%%%%% ROTATION SYNCHRONIZATION  %%%%%%%%%%%%%%%%%%%%%%%%
disp('Rotation synch...')
tic

% compute absolute rotations EIG+IRLS
[R,W_new] = rotation_synch_IRLS(G,W,opts);

% metter valori in W che inialmente contiene 1
W(W>0 & W_new >0) = W_new(W>0 & W_new >0) ;

disp('After rotation synch')

%% Prune worst rotations, update W and oter stuff
nedges_before=nnz((tril(W,-1)));

angerr = compute_angular_residual(R,G);
[W,U] = update_stuff_edges( (W_new< 1e-6 | angerr >= opts.th_deg*pi/180),W,U);

% calcola baselines o bearings applicando le R assolute ad U
[I,~]=find(tril(W,-1));
nedges=length(I);
for k=1:nedges
    i=I(k);
    U(:,k) = -R(:,:,i)'*U(:,k);
end

fprintf('\t %d%% of the edges survived\n',round(nedges/nedges_before*100))

% E' ancora connesso?
if debug
    [~,sizes] = components(W);
    fprintf('\t The eipolar graph has %d c.c. and the largest c.c. has size %d \n',...
        length(sizes), max(sizes));
end

time_R=toc;
%-------------------------------------------------------------------------%
% fine rotation synch;
clearvars -except debug opts W R U index_images time_R
% queste sono le variabili che passano al prossimo blocco
%-------------------------------------------------------------------------%
%% %%%%%%%%%%%%%%%%%%%%%% COMPUTE EPIPOLAR SCALES %%%%%%%%%%%%%%%%%%%%%%%
if opts.patchwork
    
    %% Partition the graph in overlapping patches (or patchs)
    tic
    
    disp('Clustering...')
    
    switch(opts.method)
        case 'fiedler'
            cams_patch = patch_clustering_fiedler(W,opts);
        case 'spectral'
            cams_patch = patch_clustering_spectral(W,opts);
        otherwise
            error('Unknown method.')
    end
    
    disp('After clustering')
    
    %% initialize parameters of each patch
    
    npatches = length(cams_patch);
    A_patch=cell(npatches,1);
    F_patch=cell(npatches,1);
    
    A = spones(W); % ricrea A da W (perche' non usare pesi nella scele synch?)
    
    % extract the adjacency matrix of the k-th patch
    parfor k=1:npatches
        %fprintf('\t Patch %d has size %d\n', k,  length(cams_patch{k}));
        A_patch{k}=A(cams_patch{k},:);
        A_patch{k}=A_patch{k}(:,cams_patch{k});
        if debug
            assert( ParallelRigidityTest(A_patch{k},3) );
        end
    end
    
    fprintf('\t %d patches cover  %d cameras \n',...
        npatches, length(sort(unique(cell2mat(cams_patch)))));
    
    %% Build the patch graph
    
    disp('Patch graph...')
    
    APG = build_patch_graph(cams_patch,A_patch);
    
    if debug
        figure, spy(APG)
    end
    
    index_patch=[];
    %% compute the epipolar scales for each patch
    %PAR
    parfor k=1:npatches
        
        if debug
            fprintf('\t Computing scales for patch %d of size %d\n',...
                k,  length(cams_patch{k}));
        end
        
        if strcmp(opts.type_basis,'MCB')
            
            % compute a cycle basis for the k-th cluster
            [~,basis] = minimum_cycle_basis( A_patch{k}  ,false);
            
        elseif strcmp(opts.type_basis,'FCB')
            
            % compute a fundamental cycle basis
            W_patch=W(cams_patch{k},:);
            W_patch=W_patch(:,cams_patch{k});
            [~,root]=max(sum(W_patch));
            basis  = fundamental_cycle_basis(W_patch,root);
            
        else
            error('The cycle basis can be MCB | FCB');
        end
        
        % trova gli indici degli edge del patch, per indirizzare U
        At = A;
        At(cams_patch{k},cams_patch{k}) = At(cams_patch{k},cams_patch{k}).*2;
        [~,~, v ]=find(((tril(At,-1))));  % quelli del patch hanno entry=2
        U_patch =  U(:,v>1);
         
        % compute the scale factors of the k-th patch
        [fact,~,F_patch{k}]=global_epipolar_scales_computation(U_patch,W_patch,basis);
        
        % rimuove patch difettosi
        if ~all(isfinite(fact))
            index_patch=[index_patch, k];
            %save boom U_patch W_patch basis
            %error('booom!');
        end
    end
    
    % update
    APG(index_patch,:)=[];
    APG(:,index_patch)=[];
    
    cams_patch(index_patch)=[];
    npatches=length(cams_patch);
    
    %A_patch(index_patch)=[];
    F_patch(index_patch)=[];
    
    if ~isempty(index_patch)
        fprintf('\t Discarded %d bad patches\n',length(index_patch));
    end
    
    %% Extract largest connected component of the patch graph
    
    % Using Matlab BGL:
    [C,sizes] = components(APG);
    n_conn=length(sizes);
    
    if n_conn ~=1 % if there are more than 1 connected components
        
        % consider the largest c.c.
        [big_comp_size,big_comp]=max(sizes);
        
        fprintf('\t The patch graph is not connected: the largest c.c. has size %d \n',...
            big_comp_size);
        
        index_images_patch=find(C==big_comp); % patchs that survive
        index_patch=find(C~=big_comp); % patchs that are eliminated
        
        % update A
        APG(index_patch,:)=[];
        APG(:,index_patch)=[];
        
        npatches=length(index_images_patch);
        
        % update patch information
        cams_patch(index_patch)=[];
        % A_patch(index_patch)=[];
        F_patch(index_patch)=[];
        
    else
        fprintf('\t The patch graph is  connected\n');
    end
    
    %% scale synchronization
    
    disp('Scale synch...')
    
    % build the scale matrix
    scale = build_scale_matrix(cams_patch,F_patch,APG);
    
    scale_out=scale_synch_IRLS(scale,APG,opts);
    
    % succede a volte che IRLS fornisca scale a 0
    if (any(scale_out == 0))
        scale_out=scale_synch_EIG(scale,APG);
    end
    
    assert(all(scale_out ~= 0))
    
    disp('After scale sync')
    
    %% update the scales
    
    ncams = size(W,1);
    
    F=sparse(ncams,ncams);
    Fcount=sparse(ncams,ncams);
    
    for k=1:npatches
        [I_F,J_F,factors_F]=find(1./scale_out(k)*F_patch{k});
        new_matrix=sparse(cams_patch{k}(I_F),cams_patch{k}(J_F),factors_F,ncams,ncams);
        F = F + new_matrix;
        Fcount = Fcount + ((new_matrix & F) ~= 0);
    end
    % media delle scale
    F(Fcount>0) = F(Fcount>0)./Fcount(Fcount>0);
    
    %% Update the graph
    % se patch graph non era connesso si sono perse camere
    
    missing=setdiff(1:ncams,sort(unique(cell2mat(cams_patch))));  % images that are eliminated
    
    [W,F,R,U,index_images] = update_stuff_nodes(missing,W,F,R,U,index_images);
    
    % rimuove edge con F==0
    [W,U] = update_stuff_edges(F==0,W,U);
    
    % aggiorna U con le scale
    [~,~,scales] = find(tril(F,-1));
    U = kr(scales',U);
    
    fprintf('\t Number of cameras = %d\n',length(index_images));
    
    time_S=toc;
    
else
    %% No patching
    
    tic
    
    % Compute largest rigid component and update everithing
    disp('Largest Parallel Rigid Component...');
    
    [rigid_ones,~] = LargestMaxParRigComp(W,3); % images that survive
    [W,~,R,U,index_images] = update_stuff_nodes(setdiff(1:size(W,1),rigid_ones),W,[],R,U,index_images);
    
    % Compute cycle basis
    A = spones(W);
    if strcmp(opts.type_basis,'MCB')
        
        % compute a cycle basis for the k-th cluster
        [~,basis,~] = minimum_cycle_basis(A,false);
        
    elseif strcmp(opts.type_basis,'FCB')
        
        % compute a fundamental cycle basis
        [~,root]=max(sum(W));
        basis = fundamental_cycle_basis(W,root);
        
    else
        error('The cycle basis can be MCB | FCB');
    end
    
    % compute scales and update U
    [fact,U,F]=global_epipolar_scales_computation(U,W,basis);
    
    if ~all(isfinite(fact))
        disp('Problemi con le scale')
    end
    
    % remove edges with zero scale
    [W,U] = update_stuff_edges(F==0,W,U);
    
    time_S=toc;
end

%-------------------------------------------------------------------------%
% fine calcolo scale;
clearvars -except debug opts W R U index_images time_R time_S
% queste sono le variabili che passano al prossimo blocco
%-------------------------------------------------------------------------%

%% Translation Synchronization
disp('Translation synch...')
tic

% per fare translation synchronization il grafo deve essere connesso
if debug
    [~,sizes] = components(W);
    n_conn=length(sizes);
    assert(n_conn==1);
end

% solve a linear system
[T,W_new] = translation_synch_IRLS(U,W,opts);

% prune worst translations and update A
[W,U] = update_stuff_edges( (W_new< 1e-6 ),W,U);

disp('After translation synch');

%% extract connected components
[C,sizes] = components(W);
n_conn=length(sizes);

if n_conn~=1 % if there are more than 1 connected components
    
    % consider the largest connected component
    [big_comp_size,big_comp]=max(sizes);
    
    [W,~,R,U,index_images] = update_stuff_nodes(find(C~=big_comp),W,[],R,U,index_images);
    
    fprintf('\t The epipolar graph is not connected: the largest c.c. has size %d \n',...
        big_comp_size);
    fprintf('\t Number of cameras = %d\n', length(index_images));
end

% ultimo T synch sul grafo finale
T = translation_synch_LS(U,W);

time_T=toc;

%% return absolute motions
ncams = size(T,2);
% M=zeros(4,4,ncams);
parfor i=1:ncams
    T(:,i)=-R(:,:,i)*T(:,i); % altrimenti erano locations
    %  M(:,:,i)=[R(:,:,i) T(:,i);0 0 0 1];
end

%% output
out.time =[time_R time_S time_T];
out.ncams =ncams;
disp(' ');

end

%%%%%%% Helper functions

%-------------------------------------------------------------------------%

function APG = build_patch_graph(cams_patch,A_patch)

npatches = length(cams_patch);

APG=eye(npatches);

for i=1:npatches
    for j=i+1:npatches
        
        cams_i=cams_patch{i};
        cams_j=cams_patch{j};
        
        common_cams=sort(intersect(cams_i,cams_j));
        
        if length(common_cams)>1
            
            A_i=A_patch{i};
            A_j=A_patch{j};
            
            index_i=find(ismember(cams_i,common_cams));
            index_j=find(ismember(cams_j,common_cams));
            
            A_i=A_i(index_i,:);
            A_i=A_i(:,index_i);
            
            A_j=A_j(index_j,:);
            A_j=A_j(:,index_j);
            
            [~,~,factors_i]=find(tril(A_i,-1));
            [~,~,factors_j]=find(tril(A_j,-1));
            
            if ~isempty(factors_i) && ~isempty(factors_j)
                APG(i,j)=1;
                APG(j,i)=1;
            end
            
        end
        
    end
end

APG = sparse(APG);

end

%-------------------------------------------------------------------------%

function scale = build_scale_matrix(cams_patch,F_patch,APG)

npatches = length(cams_patch);

scale=eye(npatches);

for i=1:npatches
    for j=i+1:npatches
        if APG(i,j)==1
            
            cams_i=cams_patch{i};
            cams_j=cams_patch{j};
            
            common_cams=sort(intersect(cams_i,cams_j));
            
            F_i=F_patch{i};
            F_j=F_patch{j};
            
            index_i=find(ismember(cams_i,common_cams));
            index_j=find(ismember(cams_j,common_cams));
            
            F_i=F_i(index_i,:);
            F_i=F_i(:,index_i);
            
            F_j=F_j(index_j,:);
            F_j=F_j(:,index_j);
            
            [~,~,factors_i]=find(tril(F_i,-1));
            [~,~,factors_j]=find(tril(F_j,-1));
            
            scale(i,j)=abs( factors_j\factors_i );
            scale(j,i)=1/scale(i,j);
            
        end
    end
end

scale = sparse(scale);

end

%-------------------------------------------------------------------------%

function [W,U] = update_stuff_edges(indices,W,U)
% Azzera in W le entry specificate in indices ed aggiorna conseguentemente
% U.
% Le dimensioni di W rimangono le stesse (ma ha meno nnz), mentre le
% dumensioni di U si riducono, essendo le sue colonne pari alle nnz di W

W_before=W;
W(indices)=0;

D = W_before + spones(W);
% le enrtry > 1 in A sono edge da tenere
[~,~, v ]=find(((tril(D,-1))));
U = U(:,v>1);

%assert(nnz(tril(W,-1)) == size(U,2))

end

%-------------------------------------------------------------------------%

function [W,F,R,U,index_images] = update_stuff_nodes(missing,W,F,R,U,index_images)
% Elimina (riducendo le dimensioni) i nodi di indice missing nelle matrici
% date in input.  Se non si vuole aggiornare qualcosa si passi [].

A = spones(W);

A(missing,:) = A(missing,:).*2;
A(:,missing) = A(:,missing).*2;
[~,~, v ]=find(((tril(A,-1))));
U = U(:,v == 1);

% update W
W(missing,:)=[];
W(:,missing)=[];

% update F
if ~isempty(F)
    F(missing,:)=[];
    F(:,missing)=[];
end

% update R
if ~isempty(R)
    R(:,:,missing)=[];
end

% update index_images
index_images(missing) = [];

end

%-------------------------------------------------------------------------%

function opts = options()

% general
opts.patchwork = true; % use patching ON/OFF
opts.use_mex = false;
opts.type_basis='FCB'; % cycle basis algorithm (FCB = spanning tree / MCB = Hortion)

% outliers rejection
opts.weight_function='cauchy'; % funzione peso in IRLS
opts.max_irls_iter = 20; % numero max iterazioni IRLS
opts.tol=1e-5; % soglia di uscita da IRLS per convergenza
opts.th_deg = 5; % soglia in gradi per le rotazioni
opts.hr = 0.6;  % fattore moltiplicativo mad per R
opts.ht = 0.85;  % fattore moltiplicativo mad per T
opts.use_bisquare = true;

% clustering
opts.method = 'spectral';  % metodo clustering per creazione dei patch
opts.recovery = false; % create a cluster containing all removed cameras
opts.max_size_coefficient=3.7; % patch_size= floor(opts.max_size_coefficient*sqrt(ncams));
%opts.max_size_coefficient=5; % con 5 fiedler parte da 92

% questi sono per il clustering 'fiedler'
opts.cut_size=5; % patch smaller than this size are not considered

% questi sotto servono per il clustering 'spectral'
opts.initial_datum=true ;
opts.min_legs=3 ;

end
