
function [check]=check_solvability(A,C)
%
% [check]=check_solvability(A,C)
% This function provides a randomized test to check if the Epipolar Scales
% Computation (ESC) Problem is solvable. Specifically, a random
% configuration of cameras is generated, and the graph is said to be
% solvable if the associated linear system has *exactly* rank maximum-1.
% Indeed - if the cameras are in a general configuration - solvability
% depends on the topology of the graph. 
% The reference structure is the epipolar graph, where nodes are
% the images and edges correspond to epipolar relationships between them.
% Let nV be the number of cameras and nE be the number of edges.
%
% Rerefence:
% F. Arrigoni, A. Fusiello, B. Rossi. On Computing the Translations Norm in
% the Epipolar Graph. International Conference on 3D Vision, 2015.
%
% Authors: Federica Arrigoni, Beatrice Rossi, Andrea Fusiello, 2015
%
% INPUT:
% A is the nV x nV (symmetric) adjacency matrix associated to the epipolar
% graph: A(i,j)=1 if the relative motion between view i and j is available,
% A(i,j)=0 otherwise.
%
% C is a nE-nV+1 x nE matrix which contains a cycle basis for the
% epipolar graph viewed as a vector space, i.e. C(i,:) is the signed
% indicator vector associated to the i-th cycle in the basis.
%
% OUTPUT:
% check = true if the ESC Problem admits a unique (up to scale) solution
% check = false otherwise
%


% Consider the lower-triangular adjacency matrix, i.e. the edges (i,j) and
% (j,i) are considered as a single edge.
A = sparse(tril(A,-1));
nV=size(A,1); % number of vertices
[I,J]=find(A);
nE=nnz(A);


% Generate random noise-free positions
centres = rand(3,nV); 

% G is the 3*nV x nV block-matrix containing the baseline directions: the
% (i,j)-block in G contains the baseline direction bij between camera i
% and j. Zero blocks in G correspond to unavailable relative motions.
G=zeros(3*nV,nV);
for k=1:nE
    i=I(k); j=J(k);
    
    G(3*i-2:3*i,j)=centres(:,i)-centres(:,j);
    G(3*j-2:3*j,i)=centres(:,j)-centres(:,i);
    
end

% Compute the baseline matrix: each column is a baseline direction
X=G(3*(1:nV)-2,:); X=X(A~=0); % x-coordinates of baseline directions
Y=G(3*(1:nV)-1,:); Y=Y(A~=0); % y-coordinates of baseline directions
Z=G(3*(1:nV),:); Z=Z(A~=0); % z-coordinates of baseline directions

B=full([X';Y';Z']);

% Check if the ESC Problem is solvable
if rank(kr(C,B))<nE-1 
    check=0;
    warning('The Epipolar Scales Computation Problem admits multiple solutions!');
else
    check=1;
    fprintf('\nThe Epipolar Scales Computation Problem is solvable!\n')
end




end







