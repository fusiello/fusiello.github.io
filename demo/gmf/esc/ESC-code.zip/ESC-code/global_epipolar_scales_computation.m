
function [factors,G]=global_epipolar_scales_computation(G,A,C)
%
% [factors,G]=epipolar_scales_computation(G,A,C)
% This function computes the unknown norms - also referred to as epipolar
% scales - of the baselines joining the optical centres of the cameras.
% The baseline directions are already expressed in a common rotational
% reference frame, namely the absolute rotations have been already
% computed. The reference structure is the epipolar graph, where nodes are
% the images and edges correspond to epipolar relationships between them.
% Let nV be the number of cameras and nE be the number of edges.
%
% Rerefence:
% F. Arrigoni, A. Fusiello, B. Rossi. On Computing the Translations Norm in
% the Epipolar Graph. International Conference on 3D Vision, 2015.
%
% Authors: Federica Arrigoni, Beatrice Rossi, Andrea Fusiello, 2015
%
% INPUT:
% A is the nV x nV (symmetric) adjacency matrix associated to the epipolar
% graph: A(i,j)=1 if the relative motion between view i and j is available,
% A(i,j)=0 otherwise.
%
% G is the 3*nV x nV block-matrix containing the baseline directions: the
% (i,j)-block in G contains the baseline direction bij between camera i
% and j. Zero blocks in G correspond to unavailable relative motions.
%
% C is a nE-nV+1 x nE matrix which contains a cycle basis for the
% epipolar graph viewed as a vector space, i.e. C(i,:) is the signed
% indicator vector associated to the i-th cycle in the basis.
%
% OUTPUT:
% factors is a nE-vector which contains the epipolar scales. The edges are
% ordered using Matlab's convention on sparse matrices.
%
% G is updated so as to contain information about the epipolar scales: the
% baseline direction bij in the (i,j)-block in G is substituted
% with bij*factors(k) if k is the index associated to the edge (i,j).


% Consider the lower-triangular adjacency matrix, i.e. the edges (i,j) and
% (j,i) are considered as a single edge.
A = sparse(tril(A,-1));
nV=size(A,1); % number of vertices
[I,J]=find(A);


fprintf('\nBuilding the linear system...\n')

% Compute the baseline matrix: each column is a baseline direction
X=G(3*(1:nV)-2,:); X=X(A~=0); % x-coordinates of baseline directions
Y=G(3*(1:nV)-1,:); Y=Y(A~=0); % y-coordinates of baseline directions
Z=G(3*(1:nV),:); Z=Z(A~=0); % z-coordinates of baseline directions

B=full([X';Y';Z']);


% Compute the coefficient matrix of the linear system
CB=sparse(kr(C,B));

fprintf('Computing the epipolar scales...\n')

% Compute the epipolar scales (up to a global scale)
[factors,~]=eigs(CB'*CB,1,'sm');
factors=factors*sign(factors(1)); % adjust the sign


% Update the baselines

F=sparse([I;J],[J;I],[factors;factors]);
F=kron(F,ones(3,1));

G=G.*F;


end







