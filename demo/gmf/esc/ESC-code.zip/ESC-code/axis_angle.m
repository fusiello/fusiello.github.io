
function [theta,u] = axis_angle(R)
%
% [theta,u] = axis_angle(R)
% This function computes the rotation axis u and angle theta corresponding
% to the orthonormal matrix R.
%
% Reference: 
% D.Q. Huynh. Metrics for 3D rotations: comparison and analysis. Journal of
% Mathematical Imaging and Vision, 2009.
%
% Authors: Federica Arrigoni, Beatrice Rossi, Andrea Fusiello, 2015
%

theta = acos((trace(R)-1)/2); 
theta=real(theta); % due to numerical errors, theta may be complex


% R-R' is the skew-symmetric matrix corresponding to the cross product 
% with u
u = [R(3,2)-R(2,3), R(1,3)-R(3,1), R(2,1)-R(1,2)]'; 

% particular cases:
if (nnz(R-R')==0) % R-R'=0
    if (nnz(R-eye(3))==0) % R = I
        theta=0;
        u=[1;1;1]; % u can be any vector (the angle is zero!)
    else %R+I=2*u*u' has rank 1
        theta=pi;
        A=R+eye(3);
        u=A(:,1); % u can be computed by normalizing any column of R+I
    end       
end

u=u/norm(u);


end
