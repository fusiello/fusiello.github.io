
function [factors,G]=epipolar_scales_computation(G,A,basis,index_basis)
%
% [factors,G]=epipolar_scales_computation(G,A,basis,index_basis)
% This function solves the Epipolar Scales Computation (ESC) problem,
% namely the problem of recovering (up to a global scale factor) the
% unknown norms - also referred to as epipolar scales - of the relative
% translation directions extracted from the essential matrices.
% The reference structure is the epipolar graph, where nodes are the images
% and edges correspond to epipolar relationships between them. Let nV be
% the number of cameras/images and nE be the number of edges.
%
% Rerefence:
% F. Arrigoni, A. Fusiello, B. Rossi. On Computing the Translations Norm in
% the Epipolar Graph. International Conference on 3D Vision, 2015.
%
% Authors: Federica Arrigoni, Beatrice Rossi, Andrea Fusiello, 2015
%
% INPUT:
% A is the nV x nV (symmetric) adjacency matrix associated to the epipolar
% graph: A(i,j)=1 if the relative motion between view i and j is available,
% A(i,j)=0 otherwise.
%
% G is the 4*nV x 4*nV block-matrix containing the relative motions: the
% (i,j)-block in G contains the relative motion Mij between camera i
% and j, where Mij=[Rij tij;0 1], Rij is the relative rotation of the pair
% (i,j) and tij denotes the direction of the relative translation of the
% pair (i,j). Zero blocks in G correspond to unavailable relative motions.
%
% basis is a 1 x nE-nV+1 cell which contains a minimum cycle basis, i.e.
% basis{i} contains the i-th cycle of the basis stored as a closed path,
% e.g. the cycle {(l,j), (j,k), (k,l)} is stored as [l,j,k,l].
%
% index_basis is a 1 x nE-nV+1 cell which contains the nonzero indices of
% each cycle in the basis, i.e. index_basis{i} contains the nonzero indices
% of the edges of the i-th cycle viewed as a vector in GF(2)^nE.
% To explicitly build this (unsigned) vector, use the command
% sparse(index_basis{i},1,1,nE,1). 
%
% OUTPUT:
% factors is a nE-vector which contains the epipolar scales. The edges are
% ordered using Matlab's convention on sparse matrices.
%
% G is updated so as to contain information about the epipolar scales: the
% relative translation direction tij in the (i,j)-block in G is substituted
% with tij*factors(k) if k is the index associated to the edge (i,j).
%


% Consider the lower-triangular adjacency matrix, i.e. the edges (i,j) and
% (j,i) are considered as a single edge.
A = sparse(tril(A,-1));
[I,J]=find(A);
nE=nnz(A); % number of edges


% Initialize the coefficient matrix of the linear system
B=sparse(3*length(basis),nE);

fprintf('\nBuilding the linear system...\n')

for c=1:length(basis)
    
    cycle=basis{c}; % current cycle
    ind_vec=index_basis{c}; % vector representation
    N=length(ind_vec); % length of the cycle
    

    
    B(3*c-2:3*c,ind_vec(1))=-G(4*cycle(1)-3:4*cycle(1)-1,4*cycle(2)); % t_{1,2}
    
    
    for k=2:N-1
        % Multiply the relative rotations along the path from node 1 to k
        R_product=eye(3);
        for i=1:k-1
            R_product=R_product*G(4*cycle(i)-3:4*cycle(i)-1,4*cycle(i+1)-3:4*cycle(i+1)-1); % R_product*R_{i,i+1}
        end
        B(3*c-2:3*c,ind_vec(k))=-R_product*G(4*cycle(k)-3:4*cycle(k)-1,4*cycle(k+1)); % -R_{1,2}*R_{2,3}*...*R_{k-1,k}*t_{k,k+1}
    end
    
    B(3*c-2:3*c,ind_vec(N))=G(4*cycle(1)-3:4*cycle(1)-1,4*cycle(N)); % t_{1,N}
    
end


fprintf('Computing the epipolar scales...\n')



% Compute the epipolar scales (up to a global scale).
[factors,~]=eigs(B'*B,1,'sm');

% Adjust the sign
factors=factors*sign(factors(1)); 


% Update relative translations

F=sparse([I;J],[J;I],[factors;factors]);
F=kron(F,[zeros(3) ones(3,1);zeros(1,4)]);

G=G.*F+G.*kron(A,[ones(3) zeros(3,1);ones(1,4)]);

end







