
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% This is a file for testing the *global* version of the method in [1] 
%% for solving the Epipolar Scales Computation (ESC) Problem, 
%% namely the problem of recovering (up to a global scale factor) the 
%% unknown norms - also referred to as epipolar scales - of the relative 
%% translation directions extracted from the essential matrices. 
%% The term "global" means that such directions are expressed in a common 
%% rotational reference frame, i.e. they are the baseline directions, thus 
%% the absolute rotations have to be computed beforehand.
%% 
%% [1] F. Arrigoni, A. Fusiello, B. Rossi. On Computing the Translations 
%% Norm in the Epipolar Graph. International Conference on 3D Vision, 2015.
%%
%% Authors: Federica Arrigoni, Beatrice Rossi, Andrea Fusiello, 2015
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear,clc,close all

%% Parameters

ncams = 50; % number of cameras

sigma=2*pi/180; % noise (radiants)

ndiags=10; % average degree of nodes in the epipolar graph

%% Define the Epipolar Graph

% Build the adjacency matrix as a band matrix
A = diag(ones(1,ncams));
for i = 2:ndiags+1
    diag_i = ones(1,ncams-i+1);
    A = A + diag(diag_i,i-1) + diag(diag_i,-i+1);
end

% A=ones(ncams); % complete graph

A=sparse(A);

fprintf('Percentage of missing pairs = %.2f %%\n',(1-nnz(tril(A,-1))/nchoosek(ncams,2))*100)

%% Generate ground-truth motion

% Initialization
M_gt = zeros(4,4,ncams); % motions -> SE(3) matrices
R_gt = zeros(3,3,ncams); % rotations -> SO(3) matrices
T_gt = zeros(3,ncams); % translations -> 3-vectors
C_gt = zeros(3,ncams); % positions (centres) -> 3-vectors

for i = 1:ncams
    
    Ri=eul(rand(1,3)*pi); % Random Euler angles
    ti = randn(3,1); % Gaussian distribution
    ci = -Ri'*ti;
    
    M_gt(:,:,i) = [Ri, ti; 0 0 0 1];
    R_gt(:,:,i) = Ri;
    T_gt(:,i) = ti;
    C_gt(:,i) = ci;
    
end

%% Compute the baseline matrix

G_gt=zeros(3*ncams,ncams);
for i=1:ncams
    for j=i+1:ncams
        G_gt(3*i-2:3*i,j)=C_gt(:,i)-C_gt(:,j);
        G_gt(3*j-2:3*j,i)=C_gt(:,j)-C_gt(:,i);
    end
end


%% Compute ground-truth scale factors

[I,J] = find(tril(A,-1));
nedges = length(I);
factors_gt = zeros(nedges,1);

for k=1:nedges
    
    i=I(k); j=J(k);
    % extract the relative translation of the pair (i,j) and compute its
    % norm
    factors_gt(k) = norm( G_gt(3*i-2:3*i,j) );
    
end


%% Add noise on relative motions

G = zeros(3*ncams,ncams); % noisy baselines

for i=1:ncams
    for j=i+1:ncams
        
        % Perturb baseline directions on the unit sphere
        bij=G_gt(3*i-2:3*i,j);
        [theta,phi] = cart2sph(bij(1),bij(2),bij(3));
        [bij_x,bij_y,bij_z] = sph2cart(theta + sigma * randn(),phi + sigma * randn(),1);
        bij=[bij_x;bij_y;bij_z];     
              
        G(3*i-2:3*i,j)=bij;
        G(3*j-2:3*j,i)=-bij;
    end
end


%% Put missing blocks in correspondence of missing pairs

G = G.*kron(A,ones(3,1));

%% Compute a Minimum Cycle Basis

fprintf('\n%%%% MCB %%%%')
tic
[cycles_MCB,basis_MCB,index_MCB] = minimum_cycle_basis(A);
toc


%% Compute a Fundamental Cycle Basis

fprintf('\n%%%% FCB %%%%')

tic
[cycles_FCB,basis_FCB,index_FCB] = fundamental_cycle_basis(A,[],[]);
toc


%% Check solvability

[check]=check_solvability(A,basis_MCB);
% Equivalently: [check]=check_solvability(A,basis_FCB);


%% Compute the epipolar scales

% Minimum Cycle Basis
fprintf('\n%%%% MCB %%%%')
tic
[factors_MCB,G_MCB]=global_epipolar_scales_computation(G,A,basis_MCB);
toc

% Evaluate the relative error
global_scale_MCB = factors_MCB\factors_gt;
res_MCB = mean( abs(factors_gt - factors_MCB*global_scale_MCB)/mean(factors_gt) );

fprintf('\nMCB - mean relative error on the epipolar scales = %f\n',mean(res_MCB))

% Fundamental Cycle Basis
fprintf('\n%%%% FCB %%%%')
tic
[factors_FCB,G_FCB]=global_epipolar_scales_computation(G,A,basis_FCB);
toc

% Evaluate the relative error
global_scale_FCB = factors_FCB\factors_gt;
res_FCB = mean( abs(factors_gt - factors_FCB*global_scale_FCB)/mean(factors_gt) );

fprintf('\nFCB - mean relative error on the epipolar scales = %f\n',mean(res_FCB))

%%


