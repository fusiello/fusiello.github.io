
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% This is a file for testing the method in [1] for solving the Epipolar
%% Scales Computation (ESC) Problem, namely the problem of recovering
%% (up to a global scale factor) the unknown norms - also referred to as
%% epipolar scales - of the relative translation directions extracted
%% from the essential matrices. These directions are expressed with
%% respect to independent local frames.
%%
%% [1] F. Arrigoni, A. Fusiello, B. Rossi. On Computing the Translations
%% Norm in the Epipolar Graph. International Conference on 3D Vision, 2015.
%%
%% Authors: Federica Arrigoni, Beatrice Rossi, Andrea Fusiello, 2015
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear,clc, close all


%% Parameters

ncams = 50; % number of cameras

sigma=2*pi/180; % noise (radiants)

ndiags=10; % average degree of nodes in the epipolar graph

thresh=5; % angular threshold (degrees) to discriminate outliers

prob_out = 0.05; % probability that a given edge is an outlier

%% Define the Epipolar Graph

% Build the adjacency matrix as a band matrix
A = diag(ones(1,ncams));
for i = 2:ndiags+1
    diag_i = ones(1,ncams-i+1);
    A = A + diag(diag_i,i-1) + diag(diag_i,-i+1);
end

% A=ones(ncams); % complete graph

A=sparse(A);

fprintf('Percentage of missing pairs = %.2f %%\n',(1-nnz(tril(A,-1))/nchoosek(ncams,2))*100)

%% Generate ground-truth motion

% Initialization
M_gt = zeros(4,4,ncams); % motions -> SE(3) matrices
R_gt = zeros(3,3,ncams); % rotations -> SO(3) matrices
T_gt = zeros(3,ncams); % translations -> 3-vectors
C_gt = zeros(3,ncams); % positions (centres) -> 3-vectors

for i = 1:ncams
    
    Ri=eul(rand(1,3)*pi); % Random Euler angles
    ti = randn(3,1); % Gaussian distribution
    ci = -Ri'*ti;
    
    M_gt(:,:,i) = [Ri, ti; 0 0 0 1];
    R_gt(:,:,i) = Ri;
    T_gt(:,i) = ti;
    C_gt(:,i) = ci;
    
end


%% Compute the block-matrix containing the relative motions

Y=zeros(4*ncams,4); % stack of the absolute motions
Yt=zeros(4,4*ncams); % concatenation of the inverse of absolute motions

for i=1:ncams
    Y(4*i-3:4*i,:)=M_gt(:,:,i);
    Yt(:,4*i-3:4*i)=inv(M_gt(:,:,i));
end

X_gt = Y*Yt; % relative motions


%% Compute ground-truth scale factors

[I,J] = find(tril(A,-1));
nedges = length(I);
factors_gt = zeros(nedges,1);

for k=1:nedges
    
    i=I(k); j=J(k);
    % extract the relative translation of the pair (i,j) and compute its
    % norm
    factors_gt(k) = norm( X_gt(4*i-3:4*i-1,4*j) );
    
end


%% Add noise on relative motions

X = X_gt; % noisy relative motions

for i=1:ncams
    for j=i+1:ncams
        
        % Perturb relative rotations on the angle-axis space
        Rij=X_gt(4*i-3:4*i-1,4*j-3:4*j-1);
        [theta,ax] = axis_angle(Rij);
        Rij = inv_axis_angle(theta + sigma*randn(), ax);
        
        % Perturb relative translation directions on the unit sphere
        tij = X_gt(4*i-3:4*i-1,4*j);
        [theta,phi] = cart2sph(tij(1),tij(2),tij(3));
        [tij_x,tij_y,tij_z] = sph2cart(theta + sigma * randn(),phi + sigma * randn(),1);
        tij=[tij_x;tij_y;tij_z];
        
        X(4*i-3:4*i,4*j-3:4*j) = [Rij tij;0 0 0 1];
        X(4*j-3:4*j,4*i-3:4*i) = inv([Rij tij;0 0 0 1]);
        
    end
end


%% Put missing blocks in correspondence of missing pairs

X = X.*kron(A,ones(4));


%% Compute a Minimum Cycle Basis

fprintf('\n%%%% MCB %%%%')
tic
[cycles_MCB,basis_MCB,index_MCB] = minimum_cycle_basis(A);
toc


%% Compute a Fundamental Cycle Basis

fprintf('\n%%%% FCB %%%%')

tic
[cycles_FCB,basis_FCB,index_FCB] = fundamental_cycle_basis(A,[],[]);
toc


%% Check solvability

[check]=check_solvability(A,basis_MCB);
% Equivalently: [check]=check_solvability(A,basis_FCB);


%% Compute the epipolar scales

% Minimum Cycle Basis
fprintf('\n%%%% MCB %%%%')
tic
[factors_MCB,X_MCB]=epipolar_scales_computation(X,A,cycles_MCB,index_MCB);
toc

% Evaluate the relative error
global_scale_MCB = factors_MCB\factors_gt;
res_MCB = mean( abs(factors_gt - factors_MCB*global_scale_MCB)/mean(factors_gt) );

fprintf('\nMCB - mean relative error on the epipolar scales = %f\n',mean(res_MCB))

% Fundamental Cycle Basis
fprintf('\n%%%% FCB %%%%')
tic
[factors_FCB,X_FCB]=epipolar_scales_computation(X,A,cycles_FCB,index_FCB);
toc

% Evaluate the relative error
global_scale_FCB = factors_FCB\factors_gt;
res_FCB = mean( abs(factors_gt - factors_FCB*global_scale_FCB)/mean(factors_gt) );

fprintf('\nFCB - mean relative error on the epipolar scales = %f\n',mean(res_FCB))


%% Add outliers among the relative motions

A_outliers=not(A).*(rand(ncams)<prob_out);
A_outliers=A_outliers+A_outliers';
A_outliers(A_outliers~=0)=1;

A_hat=sparse(A_outliers+A);

X_hat=X;

for i=1:ncams
    for j=i+1:ncams
        
        if A_outliers(i,j)==1
            
            % generate random rotations and translations to simulate
            % outliers
            
            [u,~,v]=svd(rand(3));
            Rij=u*diag([1 1 det(u*v')])*v';
            tij=rand(3,1);
            if norm(tij)~=0
                tij=tij/norm(tij);
            end
            Mij=[Rij tij;0 0 0 1];
            
            X_hat(4*i-3:4*i,4*j-3:4*j)=Mij;
            X_hat(4*j-3:4*j,4*i-3:4*i)=inv(Mij);
            
        end
    end
end

fprintf('\nPercentage of effective outliers = %.2f %%\n',nnz(A_outliers)/nnz(A_hat)*100)
fprintf('Percentage of missing pairs = %.2f %%\n',(1-nnz(tril(A_hat,-1))/nchoosek(ncams,2))*100)


%% Compute a Null-Minimum Cycle Basis


fprintf('\n%%%% N-MCB %%%%')
tic
[cycles_NMCB,basis_NMCB,index_NMCB,A_NMCB] = null_minimum_cycle_basis(A_hat,X_hat,thresh);
toc

% Check solvability
[check_NMCB]=check_solvability(A_NMCB,basis_NMCB);


% Update the adjiacency matrix by considering only null cycles
X_hat = X_hat.*kron(A_NMCB,ones(4));


% Compute the Epipolar Scales
fprintf('\n%%%% N-MCB %%%%')
tic
[factors_NMCB,X_NMCB]=epipolar_scales_computation(X_hat,A_NMCB,cycles_NMCB,index_NMCB);
toc

% Compute ground-truth scales
[I_NMCB,J_NMCB] = find(tril(A_NMCB,-1));
nedges_NMCB = length(I_NMCB);
factors_gt_NMCB = zeros(nedges_NMCB,1);

for k=1:nedges_NMCB
    
    i=I_NMCB(k); j=J_NMCB(k);
    % extract the relative translation of the pair (i,j) and compute its
    % norm
    factors_gt_NMCB(k) = norm( X_gt(4*i-3:4*i-1,4*j) );
    
end

% Evaluate the relative error on the epipolar scales
global_scale_NMCB = factors_NMCB\factors_gt_NMCB;
res_NMCB = mean( abs(factors_gt_NMCB - factors_NMCB*global_scale_NMCB)/mean(factors_gt_NMCB) );

fprintf('\nN-MCB - mean relative error on the epipolar scales = %f\n',mean(res_NMCB))

% Compute the mis-classification error, i.e. the fraction of effective
% outliers that are not removed
ME = nnz(A_outliers&A_NMCB)/nnz(A_outliers);

fprintf('N-MCB - misclassification error = %.2f %%\n',ME*100)



