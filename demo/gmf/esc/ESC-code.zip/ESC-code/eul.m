
function R = eul(a)
%
% R = eul(a)
% This function computes the orthonormal matrix R associated to the Euler
% angles in a, where a=[Yaw,Pitch,Roll]
%
% Authors: Federica Arrigoni, Beatrice Rossi, Andrea Fusiello, 2015.
%

phi   = a(3);
theta = a(2);
psi   = a(1);

R = [ cos(phi)*cos(theta) cos(phi)*sin(theta)*sin(psi)-sin(phi)*cos(psi) cos(phi)*sin(theta)*cos(psi)+sin(phi)*sin(psi)
    sin(phi)*cos(theta) sin(phi)*sin(theta)*sin(psi)+cos(phi)*cos(psi) sin(phi)*sin(theta)*cos(psi)-cos(phi)*sin(psi)
    -sin(theta)                    cos(theta)*sin(psi)                              cos(theta)*cos(psi)];

end
