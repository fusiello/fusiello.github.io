
function R = inv_axis_angle(theta,u)
%
% R = inv_axis_angle(theta,u)
% This function computes the orthonormal matrix R corresponding to the 
% rotation through the angle theta about the axis u.
%
% Authors: Federica Arrigoni, Beatrice Rossi, Andrea Fusiello, 2015

if theta==0 % The rotation is the identity matrix, so any axis is possible
    u=[1;1;1];
end

u=u/norm(u); % unit vector
u=u(:); % column vector 

% Apply Rodrigues formula.
R=cos(theta)*eye(3)+sin(theta)*star(u)+(1-cos(theta))*(u*u');

end



function  X = star(x)
%
% This function returns the skew-symmetric matrix X s.t. cross(x,y) = X*y
%

X=[   0    -x(3)  x(2)
     x(3)    0   -x(1)
    -x(2)  x(1)   0   ];

end

