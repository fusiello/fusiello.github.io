

function [basis,v_basis,index_basis,A_basis] = null_minimum_cycle_basis(A,G,thresh)
%
% [basis,v_basis,index_basis] = null_minimum_cycle_basis(A,G,thresh)
% This function computes a Minimum Cycle Basis (also known as Shortest
% Cycle Basis) of an undirected graph containing only null cycles, i.e.
% cycles whose relative rotations compose to identity.
% A modified version of Horton's algorithm is used, whose execution time is
% O(nV*nE^3), where nV is the number of vertices (nodes) of the graph and
% nE is the number of edges. 
% It is assumed that the underlying graph is biconnected.
%
% Rerefences:
% J. D. Horton. A polynomial-time algorithm to find the shortest cycle
% basis of a graph. SIAM journal on computing, 16(2), pages 358-366, 1987.
%
% F. Arrigoni, A. Fusiello, B. Rossi. On Computing the Translations Norm in
% the Epipolar Graph. International Conference on 3D Vision, 2015.
%
% Authors: Federica Arrigoni, Beatrice Rossi, Andrea Fusiello, 2015
%
% INPUT:
% A is the nV x nV (symmetric) adjacency matrix associated to a biconnected
% graph: A(i,j)=1 if the edge (i,j) appears in the graph, A(i,j) = 0
% otherwise.
%
% G is the 4*nV x 4*nV block-matrix containing the relative motions: the
% (i,j)-block in G contains the relative motion Mij between camera i
% and j, where Mij=[Rij tij;0 1], Rij is the relative rotation of the pair
% (i,j) and tij denotes the direction of the relative translation of the
% pair (i,j). Zero blocks in G correspond to unavailable relative motions.
%
% thresh is a threshold (expressed in degrees) that discriminates whether a
% given rotation can be approximated with the identity.
%
% OUTPUT:
% basis is a 1 x nE-nV+1 cell which contains a minimum cycle basis, i.e.
% basis{i} contains the i-th cycle of the basis stored as a closed path,
% e.g. the cycle {(l,j), (j,k), (k,l)} is stored as [l,j,k,l].
%
% v_basis is a nE-nV+1 x nE matrix which contains the cycle basis for the
% graph viewed as a vector space, i.e. v_basis(i,:) is the signed indicator
% vector associated to the i-th cycle. 
%
% index_basis is a 1 x nE-nV+1 cell which contains the nonzero indices of
% each cycle in the basis, i.e. index_basis{i} contains the nonzero indices
% of the edges of the i-th cycle viewed as a vector in GF(2)^nE.
% To explicitly build this (unsigned) vector, use the command
% sparse(index_basis{i},1,1,nE,1). 
%
% A_basis is the nV x nV (symmetric) adjacency matrix corresponding to the
% null-cycles in the graph.
%

% check if A is biconnected
if ~isempty(biconnected_components(sparse(A))) % if there are articulation points...
    error('The epipolar graph is not biconnected!')
end

% Consider the lower-triangular adjacency matrix, i.e. the edges (i,j) and
% (j,i) are considered as a single edge.
A = sparse(tril(A,-1));

nV=size(A,1); % number of vertices/nodes of the graph
nE=nnz(A); % number of edges

fprintf('\nDimension of the basis = %d\n',nE-nV+1)


% STEP 0: Use perturbation techniques to guarantee uniqueness of shortest
% paths.

sigma=randperm(nE); % arbitrary permutation of the edges
epsilon=2.^(sigma-nE-1); % perturbation of the edges
[I,J,S]=find(A);
% Increase the length of any edge by epsilon.
A=sparse(I,J,S+epsilon',nV,nV,nE);


% STEP 1: Find the shortest path P{x,y} between each pair of vertices x,y.

fprintf('Computing shortest paths...\n')

P = cell(nV,nV); % Initialize the shortest-paths matrix.

% Compute the predecessor and distance matrices using Floyd's algorithm. 
% Paths(x,y) is the node preceding y on the path from x to y.
% D(x,y) indicates the shortest path distance between vertex x and y.
[D,Paths] = floyd_warshall_all_sp(A+A');
D=floor(D);

for x=1:nV
    for y=1:x-1
        
        path=zeros(1,D(x,y)+1);
        j=y;
        for k=1:D(x,y)+1
            path(k)=j;
            j=Paths(x,j);
        end

        P{y,x} = path;
        P{x,y}=fliplr(path);
    end
end


% STEP 2: For each vertex v and edge (x,y) in A create the cycle
% C(v,x,y)=P{v,x}+P{v,y}+(x,y) and calculate its length. Degenerate cases
% in which P{v,x} and P{v,y} have vertices other than v in common can be
% omitted. The maximum number of cycles generated in this way is nE*nV.

fprintf('Computing the candidate cycles...\n')

A(A~=0)=1; % eliminate weights
[X,Y]=find(A);
A_basis=sparse(eye(nV));

h=1;
C=cell(1,nE*nV); % cycles
C_length=zeros(1,nE*nV); % length of cycles

for v=1:nV
    for k=1:length(X)
        
        x=X(k); y=Y(k); % consider the edge (x,y)
        
        if x~=v && y~=v
            
            % Degenerate cases in which P{v,x} and P{v,y} have vertices
            % in common other than v are omitted
            index_degenerate=ismember(P{v,x},P{y,v});
            if sum(index_degenerate)<2
                
                % Note: the vertex v is contained twice in the cycle
                cycle=[P{v,x} P{y,v}];
                l_cycle=length(cycle)-1; % length of the cycle
                
                
                if error_cycle(cycle,G)/sqrt(l_cycle) <= thresh
                    % the cycle is null: the composition of the relative
                    % rotations along it returns the identity
                    % transformation (up to a threshold)
                    
                    C{h}=cycle;
                    C_length(h)=l_cycle; 
                    A_basis=A_basis+sparse(cycle(1:end-1),cycle(2:end),1,nV,nV,length(cycle));
                    
                    h=h+1;
                end
                
                
            end
        end
    end
end
C_length=C_length(1:h-1);
C=C(1:h-1);

A_basis=A_basis+A_basis';
A_basis(A_basis~=0)=1;
A_basis=sparse(tril(A_basis,-1));
nE=nnz(A_basis);

% STEP 3: order the cycles by increasing lengths

[~,index_sort] = sort(C_length);
C=C(index_sort);



% STEP 4: Add to an initial empty basis the next shortest cycle if it is
% independent from the already selected ones.
% This step is implemented by applying Gaussian elimination to a
% 0,1-matrix whose rows are the vectors corresponding to the cycles
% generated in Step 3.

% Initialize the basis.
basis=cell(1,nE-nV+1); 
v_basis=zeros(nE-nV+1,nE);
index_basis=cell(1,nE-nV+1);

cycle=C{1}; % current cycle
[v_cycle,v_index]=cycle2vector(cycle,A_basis,nE); % vector representation

% Add the cycle to the basis.
basis{1}=cycle; 
v_basis(1,:)=v_cycle;
index_basis{1}=v_index;

fprintf('Testing linear independence...\n')

l=2; % number of analyzed cycles
k=2; % number of cycles included in the basis
p=[];
B=[];
[B,p] = gaussZ2(B,p,abs(v_cycle'));

while l<=length(C) && k<=nE-nV+1
    
    cycle=C{l}; % current cycle
    [v_cycle,v_index]=cycle2vector(cycle,A_basis,nE); % vector representation
    
    % apply Gaussian elimination
    [B,p,check] = gaussZ2(B,p,abs(v_cycle'));
    
    if check
        % the current cycle is independent from the already selected ones
        basis{k}=cycle;
        v_basis(k,:)=v_cycle;
        index_basis{k}=v_index;
        k=k+1;
    end
    
    l=l+1;
    
end

% the number of cycles returned may be lower than nE-nV+1 since only a
% subset of Horton's cycles are considered
basis=basis(1:k-1);
index_basis=index_basis(1:k-1);
v_basis=v_basis(1:k-1,:);

fprintf('Null-Minimum cycle basis computed!\n')

A_basis=A_basis+A_basis'+eye(nV);
% check if A_basis is biconnected
if ~isempty(biconnected_components(sparse(A_basis))) % if there are articulation points...
    warning('The epipolar graph corresponding to null-cycles is not biconnected!')
end


end




function [B,p,check] = gaussZ2(B,p,r)
% This function applies Gaussian elimination in GF(2) to the matrix B and
% the row-vector r. p denotes the vector of pivot elements which
% represents the indices of the first non-zero entry in each row of B.
% It is supposed that Gaussian elimination has been already applied to the
% input matrix B, thus its rows are independent and ordered basing on
% their pivots.
%
% If r is dependent from the rows in B, then the output
% matrix B coincides with the original one, and the same holds for the
% pivot vector.
% If r is independent from the rows in B, then B is updated adding r in the
% suitable position according to its pivot. Also the pivot vector is
% updated adding the pivot of r in the suitable position. 
%
% check = true if the row r is independent from the rows contained in B
% check = false otherwise
%

if isempty(B)
    B=r;
    check=true;
    p=find(r~=0);
    p=p(1);
    return
end

% calculate the pivot element of the row r
pr=find(r~=0);
pr=pr(1);

% find a row with the same pivot of r
row=find(p==pr);

while ~isempty(row)
    
    % substitute to r the sum of r and a row with the same pivot
    r=xor(r,B(row,:));
    
    % calculate the new pivot
    pr=find(r~=0);
    if isempty(pr)
        break;
    end
    pr=pr(1);
    
    % find a row with the same pivot of r
    row=find(p==pr);
    
end


if isempty(pr)
    % after the previous linear combinations, r is the zero vector (i.e. it
    % is dependent from the other rows in B)
    check=false;
else
    % r is independent from the other rows in B
    check=true;
    
    % order the pivot elements
    p=[p pr];
    [p,index]=sort(p);
    
    % insert r to the right position according to its pivot
    B=[B;r];
    B=B(index,:);
end



end




function err=error_cycle(cycle,G)
% This function composes the relative rotations along a given cycle and
% calculates the deviation from the identity (degrees).

R=eye(3); % Initialize the product

% Extract the relative rotations in the cycle and compose them
for p=1:length(cycle)-1
    h=cycle(p);
    k=cycle(p+1);
    Rhk=G(4*h-3:4*h-1,4*k-3:4*k-1); % relative rotation associated to the edge (h,k)
    R=R*Rhk;
end

% Compute the error (degrees) in the cycle (deviation from the identity) by
% using the angular (geodesic) distance

err = acos((trace(R)-1)/2);
err = real(err)*180/pi;


end

