This folder contains the code related to the paper "Global Registration of 3D point sets
via LRS Decomposition", whose main function is "SE3_LRS". Note that this function does
not provide a complete registration pipeline, but it only computes absolute
transformations from pairwise ones. More precisely, it requires as input a block-matrix
containing pairwise transformations (which in practice can be derived via ICP) as well as
the view-graph (which must be connected) describing which pairwise transformations have
been computed (meaning that the corresponding point sets have sufficient overlap). Please
refer to the paper for the notation we used for relative/absolute transformations.

In order to use the SE3_LRS function, you need to download the codes of R-Godec, Grasta
and L1-Alm: http://www.diegm.uniud.it/fusiello/demo/gmf/RGoDec-code.zip
https://sites.google.com/site/hejunzz/grasta https://sites.google.com/site/yinqiangzheng/

In the zip code you will find a modified version of 2 functions from Grasta. Indeed we
observed that sometimes Grasta fails to converge, thus we improved it by providing an
initial guess (given by the propagation of the pairwise transformations along a spanning
tree) and fixing the order in which columns are processed based on the number of observed
entries per column (the original Grasta algorithm processes one column at a time, and the
order in which columns are processed is random). You can use the original Grasta
algorithm if you prefer, which is commented in the SE3_LRS function. Providing an initial
guess to Grasta requires some graph functions from the MatlabBGL
toolbox:https://it.mathworks.com/matlabcentral/fileexchange/10922-matlabbgl

The details of the method can be found in:

Federica Arrigoni, Andrea Fusiello, and Beatrice Rossi. Global registration of 3d point
sets via LRS decomposition. In Proceedings of the 14th European Conference on Computer
Vision (ECCV), 2016.

Arrigoni, F.; Rossi, B.; Fragneto, P. and Fusiello, A. Robust Synchronization in SO(3)
and SE(3) via Low-rank and Sparse Matrix Decomposition. In Computer Vision and Image
Understanding, 2018.

If you use the code, please cite these papers. In case of questions, please contact:
federica.arrigoni.1989@gmail.com beatrice.rossi@st.com andrea.fusiello@uniud.it
