


function [M,R,T,Y] = initialization_ST(X,A)


% Check if the measurement graph is connected
[~,comp]=components(sparse(A));
if length(comp)>1 % if there are multiple connected components
    error('The graph is not connected!')
end

D=sum(A);

% Consider the lower-triangular adjacency matrix, i.e. the edges (i,j) and
% (j,i) are considered as a single edge.
A = sparse(tril(A,-1));
[I,J]=find(A);
nV=size(A,1); % number of vertices/nodes of the graph
nE=nnz(A); % number of edges


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute a Spanning Tree

[~,cam]=max(D);
%cam=randi(nV); % random root
%cam=1;

weights=ones(nE,1); % weights to maximize
%weights=rand(nE,1); 

treeweights=max(weights)-weights+1; % weights to minimize

% Compute a spanning tree by Kruskal's algorithm (the input must be a
% symmetric matrix).
options.root=cam;
T = kruskal_mst( sparse([I;J],[J;I],[treeweights;treeweights],nV,nV,2*nE),options);
T(T~=0)=1; % remove weights

% Compute the predecessor and distance matrices using Floyd's algorithm.
% Paths(x,y) is the node preceding y on the path from x to y.
% D(x,y) indicates the shortest path distance between vertex x and y.
[D,Paths] = floyd_warshall_all_sp(T);
D=floor(D);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute absolute motions along a spanning tree

R=zeros(3,3,nV);
M=zeros(4,4,nV);
T=zeros(3,nV);

M(:,:,1)=eye(4);
R(:,:,1)=eye(3);
T(:,1)=zeros(3,1);

Y=zeros(4*nV,4);
Y(1:4,:)=eye(4);

for i=2:nV
    
    % Find the shortest path in T between 1 and i
    path=zeros(1,D(1,i)+1);
    j=i;
    for k=1:D(1,i)+1
        path(k)=j;
        j=Paths(1,j);
    end
    
    M(:,:,i)=composition_cycle(path,X);
    R(:,:,i)=M(1:3,1:3,i);
    T(:,i)=M(1:3,4,i);
    
    Y(4*i-3:4*i,:)=M(:,:,i);
end


end



function M=composition_cycle(cycle,X)
% This function composes the relative rotations along a given cycle/path

M=eye(4); % Initialize the product

% Extract the relative rotations in the cycle and compose them
for p=1:length(cycle)-1
    h=cycle(p);
    k=cycle(p+1);
    M=M*X(4*h-3:4*h,4*k-3:4*k); % relative rotation associated to the edge (h,k)
end


end






