#include <stdio.h>
#include <hipspub.h>
#include "array2.h"

main(int argc, char **argv)
{ 
  int format,rows,cols,frames,colors,ncmap,i,j,sizeimage; 
  unsigned char *r,*g,*b;
  FILE *fp;
  char *filename;
  float *d_b, **d;
  float scale, max;
  u_char *mat_b,**mat;

  filename=argv[1];
  fp = fopen(filename,"r");
  hpub_frdhdr(fp,&format,&rows,&cols,&frames,&colors);
  if (format!=PFFLOAT) exit(0);
  sizeimage = rows*cols;
  
  d_b=(float*) calloc(sizeimage,sizeof(float));  
  d=farray(d_b, rows, cols);  
  mat_b=(u_char *) calloc(sizeimage,sizeof(u_char));
  mat=barray(mat_b, rows, cols);
  fread(d_b,sizeimage*sizeof(float),1,fp);
  fclose(fp);

  max = -1.0;
  for (i=0; i < rows; i++)
    for (j=0; j< cols; j++) 
      if (d[i][j] > max) max = (double)d[i][j];
  scale = 255.0/max;
  
  for (i=0; i < rows; i++)
    for (j=0; j< cols; j++) 
      mat[i][j] = (u_char)(d[i][j]*scale); 
  
  hpub_fwrthdr(stdout,PFBYTE,rows,cols,frames,colors); 
  fwrite(mat_b,sizeimage*sizeof(u_char),1,stdout);
  fprintf(stderr,"scale factor: %lf\n",scale);
    
}

