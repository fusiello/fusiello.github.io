#ifndef MEMORY_H
#define MEMORY_H

#ifndef EXTERN
#define EXTERN extern
#endif

/**************************** exported constants  ***************************************/

#ifndef u_char
#define u_char unsigned char
#endif

/************************** exported GLOBAL variables  **********************************/


/************************* exported functions ********************************************/

EXTERN  u_char **barray(u_char * image, int rows, int cols);
EXTERN  int   **iarray(int  * image, int rows, int cols);
EXTERN  float **farray(float * image, int rows, int cols);

#endif
