
/*
 * symmetric multi-window stereo 
 *
 * usage:  smw_stereo imagefile0 imagefile1 disp_min<integer> disp_max<integer>
 *
 *
 * Computes disparity between two images (a stereo pair) applying a SSD
 * correlation algorithm. Input is a two frame hips image -- pixel must be
 * PFBYTE. Output is a two frame hips image of PFFLOATS: the first frame is 
 * the computed disparity map and the second is the measurement uncertainty.
 *
 *
 *
 * MVL -  A . Fusiello 1997
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <hipspub.h>

#include "array2.h"
#include "smwp.h"   

    
static void merr(char msg[80])
{
  fprintf(stderr,"%s\n", msg);
  fflush(stderr);
  exit(0);
}

/********************************************************************************
 *										*
 *										*
 * function: main								*
 *										*
 *										*
 *******************************************************************************/
  
void main(short argc,char **argv)
 {
   u_char
     *mat1_b,			
     *mat2_b,
     **mat1,
     **mat2;
   int
     dmin,	
     dmax;
   float 
     *d_b,			
     *R_b, 
     **R,
     **d;

   char *filename0, *filename1; 
   FILE *fp0, *fp1;
   
   int format,rows,cols,frames,colors,sizeimage,foo1,foo2,foo3,foo4;
   
   if (argc!=5) 
     merr("usage: smw_stereo imagefile0 imagefile1 disp_min<integer> disp_max<integer>"); 
   filename0=argv[1];
   filename1=argv[2];
   dmin = atoi(argv[3]);
   dmax = atoi(argv[4]);

   /* read header of img 0 from file */
   fp0 = fopen(filename0,"r");
   hpub_frdhdr(fp0,&format,&rows,&cols,&frames,&colors);
   if (format!=PFBYTE) 
     merr("pixel format should be PFBYTE");
   if (frames!=1) 
     merr("images should be single frame");
   sizeimage = rows*cols;

   /* read header of img 1 from file */
   fp1 = fopen(filename1,"r");
   hpub_frdhdr(fp1,&format,&rows,&cols,&frames,&colors);
   if (format!=PFBYTE) 
     merr("pixel format should be PFBYTE");
   if (frames!=1) 
     merr("images should be single frame");
   sizeimage = rows*cols;   

   /* frames memory allocation  */
   mat1_b=(u_char *) calloc(sizeimage,sizeof(u_char));
   mat1=barray(mat1_b, rows, cols);
   mat2_b=(u_char *) calloc(sizeimage,sizeof(u_char)); 
   mat2=barray(mat2_b, rows, cols);
  
   /* allocation of d,R; */
   d_b=(float*) calloc(sizeimage,sizeof(float));  
   d=farray(d_b, rows, cols);  
   R_b=(float*) calloc(sizeimage,sizeof(float)); 
   R =farray(R_b, rows, cols);
  
   /*  ----------------------------- Main stuff ------------------- */ 
  
   /* read img 0 ; */   
   if (fread(mat1_b,sizeimage,1,fp0)!=1) 
     merr("error while reading image 0");
   
   /* read img 1 ; */
   if (fread(mat2_b,sizeimage,1,fp1) != 1)  
     merr("error while reading image 1");
	
   /* compute disparity  (and set ROI) */
   smw_stereo(mat1,mat2,rows,cols,dmin,dmax,d,R,&foo1, &foo2, &foo3, &foo4);
   fprintf(stderr,"Disparity clipped in [%d,%d]\n",dmin,dmax); 
   
   fclose(fp0);
   fclose(fp1);
   fp0 = fopen("out0.hps","w");
   fp1 = fopen("out1.hps","w");

   /* write image headers on stdout */ 
   hpub_fwrthdr(fp0,PFFLOAT,rows,cols,frames,colors);
   hpub_fwrthdr(fp1,PFFLOAT,rows,cols,frames,colors);
   
   /* write iamges on stdout */ 
   if (fwrite(d_b,sizeimage * sizeof(float),1,fp0) != 1) 
     merr("error while writing image 0");
   if (fwrite(R_b,sizeimage * sizeof(float),1,fp1) != 1) 
     merr("error while writing image 1"); 

   fflush(stderr);   
 }
 




