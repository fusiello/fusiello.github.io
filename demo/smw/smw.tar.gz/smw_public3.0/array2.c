/*
 *
 * MVL -  A . Fusiello 1996
 * 
*/


#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#ifdef EXTERN
#undef EXTERN
#endif

#define EXTERN

#include "array2.h"   


/********************************************************************************
*										*
*										*
* function: barray								*
* inputs:									*
*	 *ifr1 		image pointer						*
*	 rows, cols 	image dimension 					*
* outputs: 									*
*	 returns an array of pointers to the first pixel 			*
*	 in each row of the image 						*
*										*
* pixel format must be unsigned char (alias byte)				*
*										*
********************************************************************************/
 
u_char **barray(u_char * image, int rows, int cols)
 {
   int i;
   u_char ** mat;
   
   
   if ((mat=(u_char **) calloc(rows,sizeof(u_char *)))==(u_char **)NULL)
      {
	fprintf(stderr,"cannot allocate memory\n");
	exit(1);
      }

   for ( i=0; i<rows; i++ )
     mat[i] = &(image[i*cols]);
  
   return(mat);
    
 }

/********************************************************************************
*										*
*										*
* function: iarray								*
* inputs:									*
*	 *ifr1 		image pointer						*
*	 rows, cols 	image dimension 					*
* outputs: 									*
*	 returns an array of pointers to the first pixel 			*
*	 in each row of the image 						*
*										*
* pixel format must be int							*
*										*
********************************************************************************/
 
int **iarray(int * image, int rows, int cols)
 {
   int i;
   int ** mat;
   
   
   if (   (mat = (int **) calloc(rows,sizeof(int *))) == (int **)NULL  )
      {
	fprintf(stderr,"cannot allocate memory\n");
	exit(1);
      }
   
   for ( i=0; i<rows; i++ )
     mat[i] = &(image[i*cols]);
  
   return(mat);
    
 }

/********************************************************************************
*										*
*										*
* function: farray								*
* inputs:									*
*	 *ifr1 		image pointer						*
*	 rows, cols 	image dimension 					*
* outputs: 									*
*	 returns an array of pointers to the first pixel 			*
* 	 in each row of the image 						*
*										*
* pixel format must be float							*
*										*
********************************************************************************/

float **farray(float * image, int rows, int cols)
 {
   int i;
   float ** mat;
   
   
   if (   (mat = (float **) calloc(rows,sizeof(float *))) == (float **)NULL  )
      {
	fprintf(stderr,"cannot allocate memory\n");
	exit(1);
      }
 
   for ( i=0; i<rows; i++ )
     mat[i] = &(image[i*cols]);
  
   return(mat);
    
 }
