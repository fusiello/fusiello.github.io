/* the functions of this module implements the ssd computation and other tools.
 *
 * MVL -  A . Fusiello 1997
 * 
 */

/********** include files for iterface and  private functions ****************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include <nr.h>
#include "array2.h"

#ifdef EXTERN
#undef EXTERN
#endif
#define EXTERN

/************************** public and private headers *************************/
#include "smwp.h"   
#include "smwpP.h"


/********************************************************************************
 *										*
 *										*
 * function:	smw_stereo (symmetric multi-window stereo)			*
 * inputs:	**mat1,**mat2,rows,cols,dxmin,dxmax				*
 * outputs: 	**d,**R,*frow_p,*fcol_p,*nr_p,*nc_p				*
 *										*
 * Take two images (mat1 and mat2) of dimension rows by cols as inputs 		*
 * and produce a disparity map (d) with its uncertainty (R) as output,		*
 * with a region of interest  specified by frow_p, fcol_p, nr_p, nc_p.		*
 * dxmin and dxmax bound  the disparity search range.				*
 *										*
 * Modified 28/06/97 by A. Fusiello to avoid recomputing SSD for all the windows*
 * In this version SSD is computed only once with asquare symmetric window      *
 *										*
 ********************************************************************************/

void smw_stereo(u_char **mat1,
		u_char **mat2, 
		int const rows,
		int const cols, 
		int const dxmin,
		int const dxmax, 
		float **d, 
		float **R,
		int *frow_p,
		int *fcol_p,
		int *nr_p,
		int *nc_p)
 {  
   int 
     i,
     j,
     k, 
     up_col, 
     low_col, 
     frow, 
     fcol, 
     nr, 
     nc,
     *p1_b, 
     *p2_b,
     **p1,
     **p2,
     *iaux_b,
     *l_disp,
     *r_disp,  
     *winner,	 
     **disparity[2*NUM_OF_WIN+2];

   float 
     *faux_b,
     *r_resd, *r_sub,
     *l_resd,
     **residual[2*NUM_OF_WIN+2],
     **subpixel[2*NUM_OF_WIN+2];
   

   l_disp =(int *) calloc(cols,sizeof(int) );  
   r_disp =(int *) calloc(cols,sizeof(int) );  
   winner =(int *) calloc(cols,sizeof(int) ); 
   r_sub=(float *) calloc(cols,sizeof(float) );  
   r_resd =(float *) calloc(cols,sizeof(float) );   
   l_resd =(float *) calloc(cols,sizeof(float) );  

   p1_b =(int *) calloc(rows*cols,sizeof(int) ); 
   p1 	= iarray(p1_b, rows, cols);
   p2_b =(int *) calloc(rows*cols,sizeof(int) ); 
   p2	= iarray(p2_b, rows, cols);

   /* array of matrices */  
   for (k=0; k<2; k++) 
      {
	iaux_b =(int *) calloc(rows*cols,sizeof(int)); 
	disparity[k] = iarray(iaux_b, rows, cols);
      }
   for (k=0; k<2; k++)
      {
	faux_b =(float *) calloc(rows*cols,sizeof(float)); 
	residual[k] = farray(faux_b, rows, cols);
      }

   for (k=0; k<2; k++)
      {
	faux_b =(float *) calloc(rows*cols,sizeof(float)); 
	subpixel[k] = farray(faux_b, rows, cols);
      }

   /* lookup tables for fast ssd */
   for (j=0; j <cols; j++) 
     for (i = 0; i <  rows ; i++)
       p2[i][j] = ISQR(mat2[i][j]);
    
   for (j=0; j <cols; j++) 
     for (i = 0; i < rows; i++)
       p1[i][j] =  ISQR(mat1[i][j]);	

   /* initilizations */
   for (j=0; j <cols; j++) 
     for (i = 0; i < rows; i++)
	{
	  d[i][j]=DCCDISP;
	  R[i][j]=HUGEVAR;
	}	
   
   if (dxmax >0 )
      {
	low_col = dxmax;
	up_col = cols-dxmax; 
      }
   else
      {
	low_col = -dxmin;
	up_col =  cols + dxmin;
      }

   frow=WHS;
   fcol=low_col+WHS;
   nr=rows-2*WHS;
   nc=up_col-low_col-2*WHS;
  
   /* compute SSD from left to right and from  right to left */
   fast_ssd(mat1,mat2,p1,p2,rows,cols, dxmin, dxmax,wstable[0],residual[0],disparity[0],subpixel[0]);
   fast_ssd(mat2,mat1,p2,p1,rows,cols,-dxmax,-dxmin,wstable[0],residual[1],disparity[1],subpixel[1]);

 
   for (i=frow; i<frow+nr; i++)
      {	
	for (j=fcol; j<fcol+nc; j++) 
	   {    
	     int np,med,ii,jj;
	     static float 
	       dis_point[NUM_OF_WIN+1],
	       res_point[NUM_OF_WIN+1],
	       win_point[NUM_OF_WIN+1]; 
	   
	     /* RIGHT DISPARITY */

	     /* compute point disparity */
	     for (k=0; k<NUM_OF_WIN; k++)
		{ 
		  ii = i+ (-wstable[k][0]+wstable[k][1])/2;
		  jj = j+ (-wstable[k][2]+wstable[k][3])/2;
		  dis_point[k+1]=(float)disparity[0][ii][jj];    
		  res_point[k+1]=(float)residual[0][ii][jj];   
		  win_point[k+1]=(float)k;
		}

	     sort3(NUM_OF_WIN,res_point,dis_point,win_point); 

	     /* the minimun residual could be achieved by more then one windows, 
		giving different disparities; in that case we use a majotity voting
		to assign disparity */
	     np=1;
	     while(res_point[1]==res_point[np+1] && np < NUM_OF_WIN)
	       np++;
	     /* sort first np elements by disparity value */
	     sort3(np,dis_point,res_point,win_point); 
	     /* take the median */
	     med = (np+1)/2;
	     assert(med >=1 && med <=np); /* ASSERT */ 
	     r_disp[j]=	(int)dis_point[med];
	     r_resd[j]= res_point[med];
	     
	     /* assign subpixel adjustment */
	     winner[j]=(int)win_point[med]; 
	     ii = i+ (-wstable[winner[j]][0]+wstable[winner[j]][1])/2;
	     jj = j+ (-wstable[winner[j]][2]+wstable[winner[j]][3])/2;
	     r_sub[j]= subpixel[0][ii][jj];
	      	 

	     /* compute variance */
	      {
		float ave;	/* unused variable */
		variance(dis_point,NUM_OF_WIN,&ave,&R[i][j]);
		R[i][j]+= ACCURACY;
	      }	     

	     /* LEFT DISPARITY */

	     /* compute point disparity */
	     for (k=0; k<NUM_OF_WIN; k++)
		{	 
		  ii = i+ (-wstable[k][0]+wstable[k][1])/2;
		  jj = j+ (-wstable[k][2]+wstable[k][3])/2;
		  dis_point[k+1]=(float) disparity[1][ii][jj];    
		  res_point[k+1]=(float)residual[1][ii][jj];   
		  win_point[k+1]=(float)k;
		}

	     sort3(NUM_OF_WIN,res_point,dis_point,win_point); 
	     
	     /* the minimun residual could be achieved by more then one windows, 
		giving different disparities; in that case we use a majotity voting
		to assign disparity */
	     np=1;
	     while(res_point[1]==res_point[np+1] && np < NUM_OF_WIN)
	       np++;
	     /* sort first np elements by disparity value */
	     sort3(np,dis_point,res_point,win_point); 
	     /* take the median */
	     med = (np+1)/2;
	     assert(med >=1 && med <=np); /* ASSERT */ 
	     l_disp[j]=(int)dis_point[med];
	     l_resd[j]= res_point[med];   

	   } /* next j */

	
	/* HERE IS THE CORE OF THE ALGORITHM */
	
	for (j=fcol; j<fcol+nc; j++) 
	   {  
	     int jj=(int)j+r_disp[j]; /* left image abscissa */
	     assert (jj >= 0 && jj< cols); /* ASSERT */ 

	     if (jj >= fcol+nc) 
	       l_disp[jj] =- r_disp[j];
	 
	     /* check left-right consistency */
	     if (r_disp[j]==-l_disp[jj]) 
		{   
		  /* OK */
		  d[i][j]=(float)r_disp[j] +r_sub[j];
		  assert( fabs(r_sub[j]) < 0.5); /* ASSERT */ 
		}
	     else
		{
		  /* occlusion */ 
		  d[i][j]=(float)dxmin; /* it's a bad guess */
		  R[i][j]=HUGEVAR; 	  
		}  
	   } /* next  j */

	/* assigning a disparity to occlusions */
	for (j=fcol+nc-2; j>=fcol; j--) 
	   {
	     if (d[i][j]==dxmin && R[i][j]==HUGEVAR)
	       d[i][j]=d[i][j+1];
	   } /* next  j */

      }	/* next i */

   /* ... finally, clip disparity within boundaries */
   for (i=frow; i<frow+nr; i++)
     for (j=fcol; j<fcol+nc; j++) 
	{ 
	  if (d[i][j] > dxmax) 
	     {
	       d[i][j] = dxmax;
	       R[i][j] = HUGEVAR; 
	     }
	  if (d[i][j] < dxmin) 
	     {
	       d[i][j] = dxmin; 
	       R[i][j] = HUGEVAR; 
	     }
	  assert(R[i][j] > 0);	/* ASSERT */ 
	} /* next j */ /* next i */
   
   /* set reference parameters (ROI) */
   *frow_p = frow;
   *fcol_p = fcol;
   *nr_p   = nr;
   *nc_p   = nc;
  
   /* clear memory */
   free(p1_b);
   free(p1);
   free(p2_b);
   free(p2);
   for (k=0; k<2; k++) 
      {
	free (disparity[k][0]);
	free (disparity[k]);
      }
   for (k=0; k<2; k++)
      {
	free(residual[k][0]);
	free(residual[k]);
      }   
   for (k=0; k<2; k++)
      {
	free(subpixel[k][0]);
	free(subpixel[k]);
      }   
 } 

 
/***************************************************************************************
 *											*
 *											*
 * function: fast_ssd 									*
 * input:  **mat1,**mat2,**p1,**p2,rows,cols,dxmin,dxmax, ws[]				*
 * output: **c_min,**d,**subd								*
 *											*
 * Compute disparity with optimised ssd correlation.  					*
 * mat1 and mat2 are the input images, and **p1,**p2 are the precomputed		*
 * square values of mat1 and mat2.  rows and cols are the image				*
 * dimensions and dxmin,dxmax are the disparity boundaries.  				*
 * ws[ y_min, y_plus, x_min, x_plus ] specifies the window shape.			*
 * c_min is the matrix holding the minimun of ssd for each point;			*
 * d is the integer disparity map, while subd holds the subpixel corrections.		*
 *											*
 * firts row and column bug fixed 15/07/97 - Andrea Fusiello	   			*
 *	 										*
 ***************************************************************************************/
   
static void fast_ssd(u_char **mat1, 
		     u_char  **mat2,
		     int **p1, 
		     int **p2,
		     int const rows,
		     int const cols, 
		     int const dxmin,
		     int const dxmax, 
		     int const ws[],
		     float **c_min,
		     int **d,
		     float **subd)	

 {  

   int wym = ws[0];
   int wyp = ws[1];
   int wxm = ws[2];
   int wxp = ws[3];
   int *p_b, **p,  *q, *q2, *q1;
   int i,j,n,m,o,dx,xsi,eta,low_col,up_col;
   float  *k1_b, **k1, *faux_b;
   float **cm[2*MAXDISP+2];

   q = (int *) calloc(cols,sizeof(int));
   q2 =(int *) calloc(cols,sizeof(int)); 
   q1= (int *) calloc(cols,sizeof(int)); 
  
   p_b =(int *) calloc(rows*cols,sizeof(int) );
   p = iarray(p_b, rows, cols);

   k1_b =(float *) calloc(rows*cols,sizeof(float) );
   k1 = farray(k1_b, rows, cols); 

   for (dx=dxmin; dx<=dxmax; dx++) 
      {
	faux_b =(float *) calloc(rows*cols,sizeof(float)); 
	cm[ind(dx)] = farray(faux_b, rows, cols);
      }
   
   /* step  y=0 */
   i = wym;
   for (j= 0; j <  cols ; j++) 
      { 
	q1[j] =0;
	for (eta = - wym;  eta <=  wyp; eta++)
	  q1[j]  += p1[i+eta][j]; 
      } 
   /* iteration for all y >0  */
   for (i = wym+1; i <  rows - wyp; i++)
      {
	for (j= 0; j <  cols; j++) 
	  q1[j] =q1[j] + p1[i+wyp][j]-p1[i-1-wym][j];
	/* step  x=0 */
	j = wxm;
	 {
	   o=0; 
	   for (xsi = - wxm;  xsi <= wxp; xsi++)
	     o += q1[j+xsi];
	 }
	k1[i][j]=sqrt(o); 
	/* iteration for all x >0  */
	for (j= wxm+1; j <  cols - wxp; j++) 
	   {
	     o += q1[j+wxp]-q1[j-1-wxm];  	
	     k1[i][j]=sqrt(o);
	   }
      } 
   
   /* iteration over disparity  */
   for (dx=dxmin; dx<=dxmax; dx++) 
      {	 
	low_col = 0-IMIN(0,dxmin); /* =0 if dmin >0 */
	up_col 	= cols-IMAX(0,dxmax); /* =dxmax if  dmax >0 */
	/* compute p[j][j]  */ 
	for (j=low_col; j<up_col; j++) 
	  for (i =0; i <  rows ; i++)
	     {  
	       p[i][j] =  ISQR(mat1[i][j] - mat2[i][j+dx]); 
	       assert (j+dx >=0 && j+dx <cols); /* ASSERT */
	     }

	/* step  y=0 */
	i = wym;
	for (j=low_col; j<up_col;j++) 
	   { 
	     q[j] =0; q2[j] =0;
	     for (eta = - wym;  eta <=  wyp; eta++)
		{
		  q[j] += p[i+eta][j]; 
		  q2[j] += p2[i+eta][j+dx];
		  assert (j+dx >=0 && j+dx <cols); /* ASSERT */
		  assert (i+eta >=0 && i+eta <rows); /* ASSERT */
		}	
	   }
        /* iteration for all y >0  */
        for (i = wym+1; i <  rows - wyp; i++)
           {
	     for (j=low_col; j<up_col; j++) 
		{
		  q[j] = q[j]+p[i+wyp][j]-p[i-1-wym][j]; 
		  q2[j] = q2[j]+ p2[i+wyp][j+dx]-p2[i-1-wym][j+dx];
		  assert (i+wyp >=0 && i+wyp <rows); /* ASSERT */
		  assert (i-1-wym >=0 && i-1-wym <rows); /* ASSERT */
		}
	     /* step  x=0 */
	     j = low_col+wxm;
	      {
		n=0;  m=0;
		for (xsi = - wxm;  xsi <=  wxp; xsi++)
		   { 
		     n += q[j+xsi]; 
		     m += q2[j+xsi]; 
		     assert (j+xsi >=0 && j+xsi <cols); /* ASSERT */
		   }
		cm[ind(dx)][i][j] = (float) n / (1+sqrt(m)*k1[i][j]);
	      }
	     /* iteration for all x >0  */
	     for (j= low_col+wxm+1; j<up_col-wxp; j++) 
		{	
		  n += q[j+wxp]-q[j-1-wxm]; 
		  m += q2[j+wxp]-q2[j-1-wxm]; 
		  assert (j+wxp >=0 && j+wxp <cols); /* ASSERT */ 
		  assert (j-1-wxm >=0 && j-1-wxm <cols); /* ASSERT */
		  cm[ind(dx)][i][j] = (float) n / (1+sqrt(m)*k1[i][j]);
		 		}
	   } /* next i */ 
      } /* next dx */


   /* compute subpixel correction */
   for (j=0; j <cols; j++) 
     for (i = 0; i <  rows ; i++)
       c_min[i][j] = HUGE;

   for (i = wym+1; i <rows - wyp; i++)
     for (j= low_col+wxm; j<up_col-wxp; j++) 
	{
	  for (dx=dxmin; dx<=dxmax; dx++) 
	    if (cm[ind(dx)][i][j] <  c_min[i][j])
	       {
		 c_min[i][j]= cm[ind(dx)][i][j];
		 d[i][j]=dx;
	       }
	  /* d[i][j] is the minum error integer disparity */

	  if (d[i][j]>dxmin && d[i][j]<dxmax)
	     {  
	       /* compute parameters a,b,c of the interpolating parabola */
	       float a,b,c,p,y;
	       y = cm[ind(d[i][j])][i][j];
	       a = (cm[ind(d[i][j])-1][i][j]-2.0*y +cm[ind(d[i][j])+1][i][j])/2.0;
	       p = (cm[ind(d[i][j])-1][i][j]-cm[ind(d[i][j])+1][i][j])/2.0;
	       b = -(2.0*a*d[i][j]+p);
	       c = a*SQR((float)d[i][j])+p*d[i][j]+y ;
	       if (a!=0)
		  {
		    assert(fabs(p/(2.0*a))< 1.0); /* ASSERT */  
		    subd[i][j] = p/(2.0*a);  /* abscissa of the parabola minimum */ 
		  }
	       else 
		 subd[i][j]=0.0;
	     }
	  else 
	    subd[i][j]=0.0;

	} /* next i,j */
    
   free(q);
   free(q1);
   free(q2);
   free(p_b);
   free(k1_b);
   free(p);
   free(k1);
   for (dx=dxmin; dx<=dxmax; dx++) 
      { 
	free(cm[ind(dx)][0]);
	free(cm[ind(dx)]);
      }
   
 }


/***************************************************************************************
 *											*
 *											*
 * function: void variance 								*
 * inputs:   vec[],n									*
 * outputs:  *ave, *var									*
 *											*
 *  compute mean (ave) and variance (var) of an array (arr) of n elements 		*
 *											*
 *	 										*
 ***************************************************************************************/
   
static void variance(float vec[],int n,float *ave,float *var)
 {
   int i;
   float s,r;
	
   s=0.0;
   for (i=1;i<=n;i++) s += vec[i];
   *ave=s/n;

   s=0.0;
   for (i=1;i<=n;i++) 
      {
	r=vec[i]-(*ave);
	s += r*r;
      }
   *var=s/(n-1);	
 }
