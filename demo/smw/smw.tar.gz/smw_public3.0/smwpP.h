#ifndef SSDP_H
#define SSDP_H

/* NR style square of integers */

static int isqrarg;
#define ISQR(a) ((isqrarg=(a)) == 0.0 ? 0.0 : isqrarg*isqrarg)

static float sqrarg;
#define SQR(a) ((sqrarg=(a)) == 0.0 ? 0.0 : sqrarg*sqrarg)

static int imaxarg1,imaxarg2;
#define IMAX(a,b) (imaxarg1=(a),imaxarg2=(b),(imaxarg1) > (imaxarg2) ?\
        (imaxarg1) : (imaxarg2))

static int iminarg1,iminarg2;
#define IMIN(a,b) (iminarg1=(a),iminarg2=(b),(iminarg1) < (iminarg2) ?\
        (iminarg1) : (iminarg2))

#define MAXDISP 30             /* max allowable disparity (absolute) value */ 
#define ind(a)  ((int) (MAXDISP) + (a))   /* disparity may be negative ... */


#define NUM_OF_WIN      9	/* number of different windows */
#define WHS 	4		/* window half-dimension */

static int const wstable[NUM_OF_WIN][4] = { /* definition of windows shapes */
   {WHS,WHS,WHS,WHS},
   {2*WHS,0,WHS,WHS},
   {0,2*WHS,WHS,WHS},
   {WHS,WHS,2*WHS,0},
   {WHS,WHS,0,2*WHS},
   {2*WHS,0,0,2*WHS},
   {0,2*WHS,0,2*WHS},
   {2*WHS,0,2*WHS,0},
   {0,2*WHS,2*WHS,0}
}; /* values are:  y_min, y_plus, x_min, x_plus */ 
 





static void fast_ssd(u_char **mat1, 
		     u_char **mat2,
		     int **p1, 
		     int **p2,
		     int const rows,
		     int const cols, 
		     int const dxmin,
		     int const dxmax, 
		     int const ws[],
		     float **c_min,
		     int **d, float **subd);

static void variance(float vec[],
		     int n,
		     float *ave,
		     float *var);

#endif
