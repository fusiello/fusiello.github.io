#ifndef SSD_H
#define SSD_H

#ifndef EXTERN
#define EXTERN extern
#endif

/**************************** exported constants  ***************************************/

#define ACCURACY 0.25 	/* min. uncertainty of measured disparity */
#define HUGEVAR 1e10 	/* huge value i.e. no disparity information */
#define DCCDISP  0.0 	/* don't care disparity */

/************************* exported functions ********************************************/

EXTERN void smw_stereo(u_char **mat1,
		       u_char **mat2, 
		       int const rows,
		       int const cols, 
		       int const dxmin,
		       int const dxmax, 
		       float **d, 
		       float **R,
		       int *frow_p,
		       int *fcol_p,
		       int *nr_p,
		       int *nc_p);

#endif

