
% Demo script for local stero matching. Thre cost function are
% implemented: NCC, SSC and SCH (Census). Left-right consistency check
% can be enabled and occlusion filling as well.
% The results of SMW algorithm (Fusiello, Roberto, Trucco 1996) can be
% approximately reproduced with specific settings:
% 
% ws = 11; 
% cost_type           ='ssd';
% multiple_windows    = true;
% left_right          = true;
% fill_holes          = true;
% 
% disparity ranges:
% castle            20-28
% parkmeter         1-11
% trees             3-26 
% shrub			    1-9  
% rds               1-6
% ror			    1-6

% This script needs 'nlfilter' from the Image Processing Toolbox

close all
clear all

ws = 11;                         % support (window) size
hole_size = 95;                  % hole filling neighborhood

%% Settings
cost_type           ='ssd';
normalize           = false;   % use it only to cure serios distortions
multiple_windows    = true;
left_right          = true;
fill_holes          = true;    % heuristic, not always accurate

% disparity ranges 
% head (scene1)     0-16
% teddy (im2, im6)  1-100

% -------------------------------------------------
 im1=double(rgb2gray(imread('images/im6.png')));  
 im2=double(rgb2gray(imread('images/im2.png')));  
 dmin = 0; dmax = 100;               

% 
% im1=double((imread('legacy_images/parkmeter_L.pgm')));  
% im2=double((imread('legacy_images/parkmeter_R.pgm')));  
% dmin = 1; dmax = 6;

figure,imshow(im1,[]);title('I1');
figure,imshow(im2,[]);title('I2');


%% Photometric normalization 
if normalize
    disp('Photometric normalization')
    [im2,p] = normpair(im1,im2);
end

%% Block matching
switch cost_type
    case 'ncc'
        disp('Block matching with NCC')
        [dmap1,cost]=imstereo_ncc(im1,im2,[dmin,dmax],[ws,ws]);
    case 'ssd'
        disp('Block matching with SSD')
        [dmap1,cost]=imstereo_ssd(im1,im2,[dmin,dmax],[ws,ws]);
    case 'sch'
        disp('Block matching with SCH')
        [dmap1,cost]=imstereo_sch(im1,im2,[dmin,dmax],[ws,ws]);
end

% replace Inf with max+1 in cost
m = max(cost(isfinite(cost(:))));
cost(~isfinite(cost)) = m+1;

%% Multiple windows: relax disparity in a neigborhood 
if multiple_windows
    disp('Multiple windows relaxation')
    % encode score (real) and dmap (int) in a single value
    combo = floor(dmap1) + abs(cost./(1+max(cost(:))));
    % relax disparity in a neighborhood
    dmap1 = nlfilter(combo,[ws ws],@relax);
end


%%  Left-right consistency check
if left_right
     disp('Left-right consistency check')
    % Block matching the reverse way
    switch cost_type
        case 'ncc'
            disp('    Block matching with NCC')
            [dmap2,cost]=imstereo_ncc(im2,im1,[-dmax,-dmin],[ws,ws]);
        case 'ssd'
            disp('    Block matching with SSD')
            [dmap2,cost]=imstereo_ssd(im2,im1,[-dmax,-dmin],[ws,ws]);
        case 'sch'
            disp('    Block matching with SCH')
            [dmap2,cost]=imstereo_sch(im2,im1,[-dmax,-dmin],[ws,ws]);
    end
  
    
    % Multiple windows: relax disparity in a neigborhood 
    if multiple_windows
        disp('    Multiple windows relaxation')
        % encode score (real) and dmap (int) in a single value
        combo = floor(dmap2) + abs(cost./(1+max(cost(:))));
        % relax disparity in a neighborhood
        dmap2 = nlfilter(combo,[ws ws],@relax);
    end
   
    % replace Inf with max+1 in cost
    m = max(cost(isfinite(cost(:))));
    cost(~isfinite(cost)) = m+1;

    % test
    % abs(dmap1(r,c)  + dmap2(r, c + dmap1(r,c))) > 1
    [c,r] = meshgrid(1:size(im1,2),1:size(im1,1)); % coordinate
    dest = c + dmap1; % warping
    dest (dest>size(im1,2)) = size(im1,2); % clamp disp outside the image
    
    occ = abs( dmap1  + dmap2( sub2ind(size(dmap1), r,dest) )) > 1;
    dmap1(occ) = nan;
    
end

%% Fill occlusions with background disp (first finite value on the right)
if fill_holes
    disp('Filling occlusions')
    dmap1 = nlfilter(dmap1,[1 hole_size],@(x) fillholes(x,floor(hole_size/2)));
end

figure, imshow(dmap1,[]), 
saveas(gcf, 'teddy', 'png')
colorbar


%%

function d = relax(x)
    % return the diapsrity with the lowest cost exists in a neigborhood
    dmap=floor(x); % integer part
    score=x-dmap;  % fractional part
    [~,index]  = min(score(:));
    d  = dmap(index);
end


function y = fillholes(x,centre)
   % return first finite value to the right of centre
    if  ~all(isnan(x(centre:end)))
        y =  x(centre-1+find(isfinite(x(centre:end)),1));
    else
        y = nan;
    end
end



% % violation of uniqueness constraint
% [y,x] = meshgrid(1:size(ims,2),1:size(ims,1)); % coordinate
% y = y + dmap; % warping
% %figure,imshow(Ygrid,[]);
% [~, IA, ~] = unique([x(:),y(:)],'rows');
% indexToDupes = not(ismember(1:numel(x(:)),IA));
% y(indexToDupes) = NaN;
% y(y>size(ims,2)) = NaN;
% dmap(isnan(y)) = NaN;



