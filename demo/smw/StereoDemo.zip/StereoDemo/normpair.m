function [imR_out,p] = normpair(imL,imR)
    %  normpair: normalise a streo pair
    %
    % normpair takes two images as input and returns the normalised
    % second image as output.
    
    x = prctile(imL,[10 20 30 40 50 60 70 80 90]);
    y = prctile(imR,[10 20 30 40 50 60 70 80 90]);
    p = polyfit(x,y,1);
    
    imR_out = (imR - p(2))/p(1);
    
    % clamp
    imR_out(imR_out<0) = 0;
    imR_out(imR_out>255) = 255;
    
end

% A major assumption of any area based  stereo algorithm is that the two
% image intensities from the same corresponding  point in the scene have
% approxiamtely the same values.  More precisely, it is assumed that the
% left and right values are  normally distributed about their true value.
%
% For  various reasons, this  may not always be the case.  To correct for
% constant additive and multiplicative factors, a histogram normalization
% procedureis  invoked.
%
%
% A. Fusiello 1996, 2020  based on  a previous  work  by Ingemar
% J. Cox, Bruce Maggs, Satish Rao and  George  V. Paul  at  NEC  Research
% Institute.
%
