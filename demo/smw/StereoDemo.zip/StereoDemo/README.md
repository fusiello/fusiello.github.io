#Stereo Demo

### Andrea Fusiello, 2020


This demo calls three basic stereo matching algprithm, using
NCC, SSC and SCH (Census) matching costs. They are available 
in the [Computer Vision Toolkit]
(http://www.diegm.uniud.it/fusiello/demo/toolkit/ComputerVisionToolkit.zip)
by the same author.

It also performs disparity relaxation, left-right consistency check
and occlusion filling. All these stages, togerhet wity the cost
function can be selected in the preamble of the script by setting 
suitable flags. In particular, a settings configuration can approximately 
reproduce the results of the SMW algorithm (Fusiello, Roberto, Trucco (2007))

After installing the Computer Vision Toolkit, cd to the
demo main directory and type stereo_demo.

The images of the experiments reported in (Fusiello, Roberto, 
Trucco (2007)) are in the `legacy_images` folder. 
Two pairs from the [Middlebury 2001 Stereo datasets] 
(http://vision.middlebury.edu/stereo/data/scenes2001/)
are contained in the  `images` folder.


Reference paper:
	
	@InProceedings{FusRobTru97,
	  entrysubtype = {selected},
	  author =	 { A. Fusiello and V. Roberto and E. Trucco},
	  title =	 {Efficient Stereo with Multiple Windowing},
	  booktitle =	 {IEEE Conference on Computer Vision and Pattern Recognition},
	  year =	 1997,
	  pages =	 {858-863},
	  publisher =	 {IEEE Computer Society Press},
	  doi =		 {10.1109/CVPR.1997.609428}
	}

---
Andrea Fusiello                
Dipartimento Politecnico di Ingegneria e Architettura (DPIA)  
Università degli Studi di Udine, Via Delle Scienze, 208 - 33100 Udine  
email: <andrea.fusiello@uniud.it>

---
