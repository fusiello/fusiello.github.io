
%restoredefaultpath;

root  = pwd;
addpath(fullfile(root,'m-files'             ));
addpath(fullfile(root,'m-files','aux_fun'       ));
addpath(fullfile(root,'thirdparty'          ),'-end');

savepath;

help m-files


