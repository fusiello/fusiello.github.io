nameFM  = 'biscuitbookbox';



model = 'fundamental';

[ distFun, hpFun, fit_model, cardmss, idegen, d] = set_model( model );

sequencename = nameFM;
out = 1;
[y,G,img] = load_data_FM(sequencename,out);

% normalization
[dat_img_1 T1] = normalise2dpts(y(1:3,:));
[dat_img_2 T2] = normalise2dpts(y(4:6,:));
X = [ dat_img_1 ; dat_img_2 ];


N = numel(G);
k = max(G); % number of models


sigma_gt = 0.0054;


%% Preference Trick


% guided sampling

w = 0.5;
blk = 3*N;
S  = mssWeighted( X, 6*N, blk, 'cauchy', model, w, sigma_gt);
S=S(blk+1:end,:);



H = hpFun(X,S); %hypotheses

R = res( X, H, distFun ); disp('Residuals computed')

P = prefMat(R, sigma_gt, 6); % preference matrix

K = exp(- (squareform(pdist(P,@tanimoto))).^2);  % similarity matrix

%% Robust PCA

lambda = 1/sqrt(size(K,1));
[K_rpca, E_hat, ~] = inexact_alm_rpca(K, lambda);   


%% symmetric matrix factorization

[Uinit, mekmeans]  = guess_init( K_rpca, k , G);


params.Hinit=Uinit; params.maxiter = 100000;
[U, iter, obj] = symnmf_anls(K_rpca, k,  params);
indU = indMax(U);


% segmentations obtained from snmf

F = seg_from_binaryU(U);

softIndU= U;    softIndU(indU==0)=0; % mlsac like


%% Model extraction

niter = 1000;

[Phi, Z] =  rinforzino(X, S, P, F, softIndU , model, sigma_gt, niter);

[~,I] = max(Phi'*softIndU,[],1);
mss = Z(I,:);


%% refinement using robust statistic

cost = 1.5271;

C = segmentation( mss, X, model, U , sigma_gt, cost ,'nearest');


%% visualization

figure; imshow(img); hold on; gscatter(y(1,:),y(2,:), G)








