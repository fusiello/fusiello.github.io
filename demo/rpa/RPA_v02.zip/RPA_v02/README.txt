 This code implement the RPA algorithm presented in:
 L. Magri, A. Fusiello. Robust Multiple Model Fitting with Preference Analysis and Low-rank Approximation. BMVC, 2015.
 run demo.m for an example of multiple fundamental matrix fitting.
 See: http://www.diegm.uniud.it/fusiello/demo/rpa/
 Changelog:
 - 25 august 2020: added Trifocal Tensor in model_spec thanks to Federica Arrigoni
   if you use trifocal tensor, please cite also: 
   F. Arrigoni, L. Magri, and T. Padja. On the Usage of the Trifocal Tensor in Motion Segmentation. ECCV 2020

