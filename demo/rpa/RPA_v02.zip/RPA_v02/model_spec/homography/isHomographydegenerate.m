function y= isHomographydegenerate( X,theta ,cardmss)
%

y=islinedegenerate(X,theta,cardmss)|| (~validateTheta_homography( theta));