function [ output_args ] = fitSeg( input_args )
%FITSEG Summary of this function goes here
%   Detailed explanation goes here


end

