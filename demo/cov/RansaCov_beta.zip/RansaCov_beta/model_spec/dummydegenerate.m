function y= dummydegenerate( X,theta ,cardmss)
%DUMMYDEGENERATE Summary of this function goes here
%   Detailed explanation goes here
y=false;

end

