function b = isdummy_degen(X)
    b=0;
end