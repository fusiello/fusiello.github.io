function [ ] = drawLines( M ,c)
%DRAWLINES Summary of this function goes here
%   c color
  
if(nargin==1 || isempty(c))
    c=[0.9, 0.9 ,0.9];
end
for j=1:size(M,2)
    p=[-M(1,j)/M(2,j),-M(3,j)/M(2,j)];
        xx=linspace(-1,1);
        yy=polyval(p,xx);
        hold on
        xlim([-1 1]);
        ylim([-1 1]);
        plot(xx,yy,'-','Markersize',5, 'Color',c);
        
        axis equal
        hold all
       
end
hold off;
end

