% This script just simply run the RansaCov algorithm on 3 example data set
% "star5".
% Reference:
% When using the code in your research work, please cite the following paper:
% Luca Magri, Andrea Fusiello,  Multiple Models Fitting as a Set Coverage Problem, CVPR, 2016.
%
% For any comments, questions or suggestions about the code please contact
% magrilucal (at) gmail (dot) com


% line fitting example
model = 'line';
[distFun, hpFun, fit_model, cardmss] = set_model(model);

%% 1) Set cover

load 'Star5outfree' % load otulier-free data

epsilon = .4e-1; % inlier threshold


% sampling hypotheses
n = size(Y,2); %number of points
m = 3*n; %number of hypotheses
S = mssWeighted(Y, m, 1*n,'loc', model, 0.6, nan );
H = hpFun( Y, S );


% residual computation
R = res( Y, H, distFun );
% define consensus sets
P = zeros(size(R));
P(R<epsilon) = 1;
% preprocessing step (optional)
[Q, ~] = refit_consensus( Y, P, H, epsilon, model );
F = pruning_consensus(Q);

%select the minimum number of subsets from F that covers the data
V = ransacov(F);

%% 2)  maximum coverage 

load 'Star5out'  % load data corrupted by outliers

% sampling hypotheses
n = size(X,2); % number of points
m = 3*n; % number of hypotheses
S = mssWeighted( X, m, 1*n,'loc', model, 0.6, nan );
H = hpFun( X, S );

% residual computation
R = res( X, H, distFun );
% define consensus sets
P = zeros(size(R));
P(R<epsilon) = 1;
% preprocessing step (optional)
[Q, ~] = refit_consensus( X, P, H, epsilon, model );
F = pruning_consensus(Q);

%select the k structures covering more points
W = ransacov(F,5);




%% display result

figure;
subplot(2,2,1)
scatter(Y(1,:),Y(2,:),120,'k.');
title('input data'); axis off; axis equal;
subplot(2,2,2)
display_coverage( X, V, [] ); 
title('set cover')
subplot(2,2,3)
scatter(X(1,:),X(2,:),120,'k.');
title('input data'); axis off; axis equal;
subplot(2,2,4)
display_coverage( X, W, [] ); 
title('maximum coverage')


