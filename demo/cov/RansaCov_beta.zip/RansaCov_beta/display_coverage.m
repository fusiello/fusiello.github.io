function [ ] = display_coverage( X, V, img )
%DISPLAY_COVERAGE Summary of this function goes here
%   Detailed explanation goes here


imshow(img);
hold on;
mrk='os+*d';
cm=[172, 92, 255;129, 255, 131 ;255 215, 61; 253,58,53; 12, 102, 204; 255, 138,216]./255;
cm=repmat(cm,1e4,1);
for i=1:size(V,2)
    scatter(X(1,V(:,i)>0),X(2,V(:,i)>0),25, mrk(mod(i,numel(mrk))+1), 'MarkerEdgeColor', cm(i,:));
end


end

